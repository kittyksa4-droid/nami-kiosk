# Nami direct TCP build

This project removes the stale ExperimentalNamiSocket/ExperimentalEcrPage code that caused the Flutter build failure.

Payment flow used in live mode:
1. TCP connect to configured terminal IP + ECR port.
2. Terminal Registration: txnType 17, payload `DDMMYYHHMMSS;TerminalID!`.
3. Session Start: txnType 18, same payload format.
4. Purchase: txnType 0, payload `DDMMYYHHMMSS;AmountMinor;0;TerminalIDEcrRef!`.
5. SHA-256 signature for Purchase.
6. Wait for terminal response; the observed Nami response terminates with EOT 0x04, so the client now treats 0x04 as a complete packet.
7. A purchase is never automatically retried after send, to avoid accidental duplicate charging.

Important: Nami publicly documents transaction payloads and the SDK calls, but not the SDK's low-level TCP framing. This project retains the same framing that previously caused this exact terminal to return `Terminal Is Busy, Try Later`, so it is a compatibility implementation rather than an official replacement for SkyBandSDK-release.aar.

Use the admin settings page -> `اختبار بروتوكول ECR التجريبي` (now opens the direct TCP test) -> REGISTER first -> then 1 SAR.
For normal checkout, disable `وضع الدفع التجريبي`. The cart total will then be sent to the terminal.
