package com.example.kitty_here_pos

import android.app.PendingIntent
import android.content.Context
import android.graphics.*
import android.hardware.usb.*
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random
import com.skyband.ecr.sdk.api.ECRImpl

class MainActivity: FlutterActivity() {
    private val PRINTER_CHANNEL = "kittyhere/printer"
    private val NAMI_CHANNEL = "kittyhere/nami"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, NAMI_CHANNEL).setMethodCallHandler { call, result ->
            if (call.method != "purchase") { result.notImplemented(); return@setMethodCallHandler }
            val ip = call.argument<String>("ip") ?: "172.20.10.4"
            val port = call.argument<Int>("port") ?: 1024
            val tid = call.argument<String>("terminalId") ?: "11232541"
            val crn = call.argument<String>("crn") ?: "73154354"
            val amount = call.argument<Int>("amountMinor") ?: 100
            if (tid.length != 8 || crn.length != 8 || amount <= 0) {
                result.success(mapOf("ok" to false, "stage" to "VALIDATION", "message" to "TID/CRN must be 8 digits and amount > 0")); return@setMethodCallHandler
            }
            Thread {
                try {
                    val ecr = ECRImpl.getConnectInstance()
                    val stamp = SimpleDateFormat("ddMMyyhhmmss", Locale.US).format(Date())
                    val zeros = "0".repeat(64)
                    // Official SDK transaction types: REGISTER=17, START_SESSION=18, PURCHASE=0.
                    val register = ecr.doTCPIPTransaction(ip, port, "$stamp;$crn!", 17, zeros)
                    val session = ecr.doTCPIPTransaction(ip, port, "$stamp;$crn!", 18, zeros)
                    val ref6 = String.format(Locale.US, "%06d", Random.nextInt(0, 1_000_000))
                    val ecrRef = crn + ref6
                    val signature = ecr.computeSha256Hash(ref6 + tid)
                    val req = "$stamp;$amount;0;$ecrRef!"
                    val purchase = ecr.doTCPIPTransaction(ip, port, req, 0, signature)
                    val fields = purchase.split(';')
                    val approved = purchase.contains("APPROVED", ignoreCase = true) || fields.getOrNull(1) in listOf("000", "00", "0")
                    runOnUiThread { result.success(mapOf(
                        "ok" to approved, "stage" to "PURCHASE", "message" to if (approved) "APPROVED" else purchase,
                        "ecrRef" to ecrRef, "registerResponse" to register, "sessionResponse" to session,
                        "purchaseResponse" to purchase, "requestData" to req
                    )) }
                } catch (e: Exception) {
                    runOnUiThread { result.success(mapOf("ok" to false, "stage" to "NAMI_SDK", "message" to (e.message ?: e.javaClass.simpleName))) }
                }
            }.start()
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, PRINTER_CHANNEL).setMethodCallHandler { call, result ->
            val manager = getSystemService(Context.USB_SERVICE) as UsbManager
            when (call.method) {
                "listUsbDevices" -> result.success(manager.deviceList.values.map { d -> mapOf("name" to (d.productName ?: d.deviceName), "vendorId" to d.vendorId, "productId" to d.productId) })
                "printReceipt" -> {
                    val text = call.argument<String>("text") ?: ""; val device = findPrinter(manager)
                    if (device == null) { result.success("no_printer"); return@setMethodCallHandler }
                    if (!manager.hasPermission(device)) {
                        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
                        manager.requestPermission(device, PendingIntent.getBroadcast(this, 0, android.content.Intent("KITTY_USB_PERMISSION"), flags)); result.success("permission_requested"); return@setMethodCallHandler
                    }
                    try { result.success(if (printBitmap(manager, device, renderReceipt(text))) "printed" else "failed") } catch (e: Exception) { result.error("PRINT", e.message, null) }
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun findPrinter(manager: UsbManager): UsbDevice? { for (d in manager.deviceList.values) for (i in 0 until d.interfaceCount) { val intf=d.getInterface(i); if(intf.interfaceClass==UsbConstants.USB_CLASS_PRINTER)return d; for(j in 0 until intf.endpointCount){val ep=intf.getEndpoint(j);if(ep.type==UsbConstants.USB_ENDPOINT_XFER_BULK&&ep.direction==UsbConstants.USB_DIR_OUT)return d}}; return null }
    private fun renderReceipt(text:String):Bitmap { val w=576; val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;textSize=26f;typeface=Typeface.create(Typeface.DEFAULT,Typeface.NORMAL)}; val lines=text.split("\n"); val h=(lines.size*42+80).coerceAtLeast(300); val b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); val c=Canvas(b);c.drawColor(Color.WHITE);var y=42f;for(line in lines){val rtl=line.any{it.code in 0x0600..0x06FF};paint.textAlign=if(rtl)Paint.Align.RIGHT else Paint.Align.LEFT;c.drawText(line,if(rtl)w-24f else 24f,y,paint);y+=42};return b }
    private fun printBitmap(manager:UsbManager,device:UsbDevice,bmp:Bitmap):Boolean { var target:UsbInterface?=null;var out:UsbEndpoint?=null;for(i in 0 until device.interfaceCount){val intf=device.getInterface(i);for(j in 0 until intf.endpointCount){val ep=intf.getEndpoint(j);if(ep.type==UsbConstants.USB_ENDPOINT_XFER_BULK&&ep.direction==UsbConstants.USB_DIR_OUT){target=intf;out=ep;break}};if(out!=null)break};if(target==null||out==null)return false;val conn=manager.openDevice(device)?:return false;if(!conn.claimInterface(target,true)){conn.close();return false};val bytes=escPosRaster(bmp);conn.bulkTransfer(out,byteArrayOf(0x1B,0x40),2,2000);var off=0;while(off<bytes.size){val n=minOf(4096,bytes.size-off);val chunk=bytes.copyOfRange(off,off+n);val sent=conn.bulkTransfer(out,chunk,chunk.size,4000);if(sent<=0)break;off+=sent};val cut=byteArrayOf(0x1D,0x56,0x41,0x10);conn.bulkTransfer(out,cut,cut.size,2000);conn.releaseInterface(target);conn.close();return off>=bytes.size }
    private fun escPosRaster(bitmap:Bitmap):ByteArray { val w=bitmap.width;val h=bitmap.height;val wb=(w+7)/8;val out=ByteArrayOutputStream();out.write(byteArrayOf(0x1D,0x76,0x30,0x00,(wb and 0xFF).toByte(),((wb shr 8) and 0xFF).toByte(),(h and 0xFF).toByte(),((h shr 8) and 0xFF).toByte()));for(y in 0 until h)for(xb in 0 until wb){var b=0;for(bit in 0..7){val x=xb*8+bit;if(x<w){val p=bitmap.getPixel(x,y);val gray=(Color.red(p)*30+Color.green(p)*59+Color.blue(p)*11)/100;if(gray<160)b=b or(1 shl(7-bit))}};out.write(b)};return out.toByteArray() }
}
