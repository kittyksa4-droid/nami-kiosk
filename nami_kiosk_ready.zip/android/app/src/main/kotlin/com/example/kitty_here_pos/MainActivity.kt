package com.example.kitty_here_pos

import android.app.PendingIntent
import android.content.Context
import android.graphics.*
import android.hardware.usb.*
import android.os.Build
import android.provider.MediaStore
import android.content.ContentValues
import android.os.Environment
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random
import java.net.Socket
import java.net.InetSocketAddress
import com.skyband.ecr.sdk.api.ECRImpl

class MainActivity: FlutterActivity() {
    private val PRINTER_CHANNEL = "kittyhere/printer"
    private val NAMI_CHANNEL = "kittyhere/nami"
    private val FILES_CHANNEL = "kittyhere/files"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, FILES_CHANNEL).setMethodCallHandler { call, result ->
            if (call.method != "saveCsv") { result.notImplemented(); return@setMethodCallHandler }
            try {
                val filename = call.argument<String>("filename") ?: "kitty_here_customers.csv"
                val content = call.argument<String>("content") ?: ""
                val values = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, filename); put(MediaStore.Downloads.MIME_TYPE, "text/csv"); if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS) }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri == null) result.error("SAVE", "تعذر إنشاء الملف", null) else { contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }; result.success("Downloads/$filename") }
            } catch (e: Exception) { result.error("SAVE", e.message, null) }
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, NAMI_CHANNEL).setMethodCallHandler { call, result ->
            val ip = call.argument<String>("ip") ?: "172.20.10.4"
            val port = call.argument<Int>("port") ?: 1024
            val tid = call.argument<String>("terminalId") ?: "11232541"
            val crn = call.argument<String>("crn") ?: "73154354"
            if (call.method == "keepAlive") {
                Thread {
                    var ok=false
                    try { val sock=Socket(); sock.connect(InetSocketAddress(ip,port),2500); ok=sock.isConnected; sock.close() } catch (_:Exception) {}
                    runOnUiThread { result.success(ok) }
                }.start()
                return@setMethodCallHandler
            }
            if (tid.length != 8 || crn.length != 8) {
                result.success(mapOf("ok" to false, "stage" to "VALIDATION", "message" to "TID/CRN must be 8 digits")); return@setMethodCallHandler
            }
            Thread {
                try {
                    val ecr = ECRImpl.getConnectInstance()
                    val zeros = "0".repeat(64)
                    fun stamp() = SimpleDateFormat("ddMMyyhhmmss", Locale.US).format(Date())
                    var register = ""
                    var registeredTerminalId = ""
                    var lastRegisterError = ""
                    for (attempt in 1..4) {
                        try {
                            if (attempt > 1) { try { ecr.doDisconnection() } catch (_:Exception) {}; Thread.sleep((700L * attempt)) }
                            register = ecr.doTCPIPTransaction(ip, port, "${stamp()};$crn!", 17, zeros)
                            registeredTerminalId = register.split(';').getOrNull(3)?.trim().orEmpty()
                            if (registeredTerminalId.isNotEmpty()) break
                            lastRegisterError = "REGISTER missing TerminalID"
                        } catch (rx:Exception) { lastRegisterError = rx.message ?: rx.javaClass.simpleName }
                    }
                    if (registeredTerminalId.isEmpty()) {
                        runOnUiThread { result.success(mapOf("ok" to false, "stage" to "WAKE_RETRY", "message" to "تعذر تجهيز جهاز مدى بعد المحاولة التلقائية: $lastRegisterError", "registerResponse" to register)) }
                        return@Thread
                    }
                    ecr.doTCPIPTransaction(ip, port, "${stamp()};$crn!", 18, zeros)
                    val requestedRef = call.argument<String>("ecrRef")?.trim().orEmpty()
                    val ecrRef = if (requestedRef.length >= 6) requestedRef else crn + String.format(Locale.US, "%06d", Random.nextInt(0, 1_000_000))
                    val ref6 = ecrRef.takeLast(6)
                    val signature = ecr.computeSha256Hash(ref6 + registeredTerminalId)

                    if (call.method == "suspectReversal") {
                        val req = "${stamp()};0;$ecrRef!"
                        var lastResponse = ""
                        var success = false
                        var terminalBusy = false

                        for (attempt in 1..5) {
                            try {
                                lastResponse = ecr.doTCPIPTransaction(ip, port, req, 28, signature)
                                val whole = lastResponse.uppercase()
                                val code = Regex("(?:^|[;,])\\s*(\\d{2,3})(?:[;,]|$)")
                                    .find(lastResponse)?.groupValues?.getOrNull(1).orEmpty()
                                success = whole.contains("APPROVED") &&
                                    (code.isEmpty() || code in listOf("000","00","0"))
                                terminalBusy = code == "995" ||
                                    whole.contains("TERMINAL IS BUSY") ||
                                    whole.contains("TERMINAL BUSY")
                                if (success || !terminalBusy) break
                            } catch (_: Exception) {}
                            try { Thread.sleep(2000L) } catch (_: Exception) {}
                        }

                        runOnUiThread { result.success(mapOf(
                            "ok" to success,
                            "pending" to (!success),
                            "stage" to if(success) "SUSPECT_REVERSAL" else if(terminalBusy) "TERMINAL_BUSY" else "REVERSAL_PENDING",
                            "message" to if(success) "APPROVED" else lastResponse,
                            "ecrRef" to ecrRef,
                            "response" to lastResponse
                        )) }
                        return@Thread
                    }

                    if (call.method == "checkStatus") {
                        val statusReq = "${stamp()};$ecrRef!"
                        try {
                            val statusResponse = ecr.doTCPIPTransaction(ip, port, statusReq, 24, signature)
                            val whole = statusResponse.uppercase()
                            val code = Regex("(?:^|[;,])\\s*(\\d{2,3})(?:[;,]|$)").find(statusResponse)?.groupValues?.getOrNull(1).orEmpty()
                            val approved = whole.contains("APPROVED") && (code.isEmpty() || code in listOf("000","00","0"))
                            val terminalBusy = code == "995" || whole.contains("TERMINAL IS BUSY") || whole.contains("TERMINAL BUSY")
                            val declined = !terminalBusy && (whole.contains("DECLIN") || whole.contains("رفض") || code in listOf("001","05","51","54","55","57","58","61","62","65","75"))
                            runOnUiThread { result.success(mapOf(
                                "ok" to approved,
                                "declined" to declined,
                                "pending" to (!approved && !declined),
                                "stage" to if (approved) "CHECK_STATUS" else if (declined) "DECLINED" else if (terminalBusy) "TERMINAL_BUSY" else "PENDING",
                                "message" to if (approved) "APPROVED" else statusResponse,
                                "ecrRef" to ecrRef,
                                "statusResponse" to statusResponse
                            )) }
                        } catch (ex: Exception) {
                            runOnUiThread { result.success(mapOf(
                                "ok" to false, "pending" to true, "stage" to "PENDING",
                                "message" to (ex.message ?: "تعذر التحقق الآن"), "ecrRef" to ecrRef
                            )) }
                        }
                        return@Thread
                    }

                    if (call.method == "reconciliation") {
                        val req = "${stamp()};0;$ecrRef!"
                        val response = ecr.doTCPIPTransaction(ip, port, req, 10, signature)
                        val f = response.split(';')
                        val msg = f.getOrNull(3)?.trim().orEmpty()
                        val ok = msg.equals("APPROVED", true) || response.contains("APPROVED", true)
                        runOnUiThread { result.success(mapOf("ok" to ok, "stage" to "RECONCILIATION", "message" to if(ok) "APPROVED" else response, "response" to response, "ecrRef" to ecrRef)) }
                        return@Thread
                    }
                    if (call.method != "purchase") { runOnUiThread { result.notImplemented() }; return@Thread }
                    val amount = call.argument<Int>("amountMinor") ?: 100
                    if (amount <= 0) {
                        runOnUiThread { result.success(mapOf("ok" to false, "stage" to "VALIDATION", "message" to "amount must be > 0")) }
                        return@Thread
                    }

                    // Same request + same ECR reference is preserved for the whole payment attempt.
                    // IMPORTANT: 995 Terminal Busy means the terminal has NOT accepted this purchase yet,
                    // so retrying the SAME request/reference is safe. We never generate a second payment ref.
                    val req = "${stamp()};$amount;0;$ecrRef!"
                    var purchase = ""
                    var busyAttempts = 0
                    while (true) {
                        try {
                            purchase = ecr.doTCPIPTransaction(ip, port, req, 0, signature)
                        } catch (ex: Exception) {
                            // The request may have reached the terminal but the response was lost.
                            // Do NOT submit another purchase. Ask the terminal about this SAME ECR ref.
                            var statusResponse = ""
                            var approved = false
                            var declined = false
                            for (checkAttempt in 1..40) {
                                try {
                                    val statusReq = "${stamp()};$ecrRef!"
                                    statusResponse = ecr.doTCPIPTransaction(ip, port, statusReq, 24, signature)
                                    val whole = statusResponse.uppercase()
                                    val code = Regex("(?:^|[;,])\\s*(\\d{2,3})(?:[;,]|$)").find(statusResponse)?.groupValues?.getOrNull(1).orEmpty()
                                    approved = whole.contains("APPROVED") && (code.isEmpty() || code in listOf("000","00","0"))
                                    val terminalBusy = code == "995" || whole.contains("TERMINAL IS BUSY") || whole.contains("TERMINAL BUSY")
                                    declined = !terminalBusy && (whole.contains("DECLIN") || whole.contains("رفض") || code in listOf("001","05","51","54","55","57","58","61","62","65","75"))
                                    if (approved || declined) break
                                } catch (_: Exception) {}
                                try { Thread.sleep(if (checkAttempt <= 3) 5000L else 3000L) } catch (_: Exception) {}
                            }
                            runOnUiThread {
                                result.success(mapOf(
                                    "ok" to approved,
                                    "declined" to declined,
                                    "pending" to (!approved && !declined),
                                    "stage" to if (approved) "CHECK_STATUS" else if (declined) "DECLINED" else "PENDING",
                                    "message" to if (approved) "APPROVED" else if (statusResponse.isNotBlank()) statusResponse else (ex.message ?: "لم يصل رد نهائي من جهاز مدى"),
                                    "ecrRef" to ecrRef,
                                    "purchaseResponse" to purchase,
                                    "statusResponse" to statusResponse
                                ))
                            }
                            return@Thread
                        }

                        val whole = purchase.uppercase()
                        val fields = purchase.split(';', ',')
                        val responseCode = fields.firstOrNull { it.trim().matches(Regex("\\d{2,3}")) }?.trim().orEmpty()
                        val terminalBusy = responseCode == "995" || whole.contains("TERMINAL IS BUSY") || whole.contains("TERMINAL BUSY")

                        if (terminalBusy) {
                            busyAttempts++
                            // Terminal explicitly says it is busy and has not accepted this purchase.
                            // Wait and retry the SAME purchase/reference. Customer remains on waiting screen.
                            if (busyAttempts <= 100) {
                                try { Thread.sleep(if (busyAttempts <= 5) 3000L else 5000L) } catch (_: Exception) {}
                                continue
                            }
                            runOnUiThread { result.success(mapOf(
                                "ok" to false,
                                "pending" to true,
                                "stage" to "TERMINAL_BUSY",
                                "message" to "Terminal Is Busy, Try Later",
                                "ecrRef" to ecrRef,
                                "purchaseResponse" to purchase
                            )) }
                            return@Thread
                        }

                        val approved = whole.contains("APPROVED") && (responseCode.isEmpty() || responseCode in listOf("000","00","0"))
                        val declined = whole.contains("DECLIN") || whole.contains("رفض") || responseCode in listOf("001","05","51","54","55","57","58","61","62","65","75")

                        if (approved) {
                            runOnUiThread { result.success(mapOf("ok" to true, "stage" to "PURCHASE", "message" to "APPROVED", "ecrRef" to ecrRef, "purchaseResponse" to purchase)) }
                            return@Thread
                        }
                        if (declined) {
                            runOnUiThread { result.success(mapOf("ok" to false, "declined" to true, "stage" to "DECLINED", "message" to purchase, "ecrRef" to ecrRef, "purchaseResponse" to purchase)) }
                            return@Thread
                        }

                        // Unknown response after purchase submission: never call it failed and never submit again.
                        // Verify this same ECR reference until the terminal gives a final answer.
                        var statusResponse = ""
                        var statusApproved = false
                        var statusDeclined = false
                        for (checkAttempt in 1..40) {
                            try {
                                val statusReq = "${stamp()};$ecrRef!"
                                statusResponse = ecr.doTCPIPTransaction(ip, port, statusReq, 24, signature)
                                val sw = statusResponse.uppercase()
                                val code = Regex("(?:^|[;,])\\s*(\\d{2,3})(?:[;,]|$)").find(statusResponse)?.groupValues?.getOrNull(1).orEmpty()
                                statusApproved = sw.contains("APPROVED") && (code.isEmpty() || code in listOf("000","00","0"))
                                val sbusy = code == "995" || sw.contains("TERMINAL IS BUSY") || sw.contains("TERMINAL BUSY")
                                statusDeclined = !sbusy && (sw.contains("DECLIN") || sw.contains("رفض") || code in listOf("001","05","51","54","55","57","58","61","62","65","75"))
                                if (statusApproved || statusDeclined) break
                            } catch (_: Exception) {}
                            try { Thread.sleep(if (checkAttempt <= 3) 5000L else 3000L) } catch (_: Exception) {}
                        }
                        runOnUiThread { result.success(mapOf(
                            "ok" to statusApproved,
                            "declined" to statusDeclined,
                            "pending" to (!statusApproved && !statusDeclined),
                            "stage" to if (statusApproved) "CHECK_STATUS" else if (statusDeclined) "DECLINED" else "PENDING",
                            "message" to if (statusApproved) "APPROVED" else if (statusResponse.isNotBlank()) statusResponse else purchase,
                            "ecrRef" to ecrRef,
                            "purchaseResponse" to purchase,
                            "statusResponse" to statusResponse
                        )) }
                        return@Thread
                    }
                } catch (e: Exception) {
                    runOnUiThread { result.success(mapOf("ok" to false, "stage" to "NAMI_SDK", "message" to (e.message ?: e.javaClass.simpleName))) }
                }
            }.start()
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, PRINTER_CHANNEL).setMethodCallHandler { call, result ->
            val manager = getSystemService(Context.USB_SERVICE) as UsbManager
            when (call.method) {
                "listUsbDevices" -> result.success(manager.deviceList.values.map { d -> mapOf("name" to (d.productName ?: d.deviceName), "vendorId" to d.vendorId, "productId" to d.productId) })
                "printReceipt" -> {
                    val text = call.argument<String>("text") ?: ""; val logoPath = call.argument<String>("logoPath") ?: ""; val device = findPrinter(manager)
                    if (device == null) { result.success("no_printer"); return@setMethodCallHandler }
                    if (!manager.hasPermission(device)) {
                        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
                        manager.requestPermission(device, PendingIntent.getBroadcast(this, 0, android.content.Intent("KITTY_USB_PERMISSION"), flags)); result.success("permission_requested"); return@setMethodCallHandler
                    }
                    try { result.success(if (printBitmap(manager, device, renderReceipt(text, logoPath))) "printed" else "failed") } catch (e: Exception) { result.error("PRINT", e.message, null) }
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun findPrinter(manager: UsbManager): UsbDevice? { for (d in manager.deviceList.values) for (i in 0 until d.interfaceCount) { val intf=d.getInterface(i); if(intf.interfaceClass==UsbConstants.USB_CLASS_PRINTER)return d; for(j in 0 until intf.endpointCount){val ep=intf.getEndpoint(j);if(ep.type==UsbConstants.USB_ENDPOINT_XFER_BULK&&ep.direction==UsbConstants.USB_DIR_OUT)return d}}; return null }
    private fun renderReceipt(text:String, logoPath:String):Bitmap {
        if (!text.startsWith("KH_RECEIPT_V2")) {
            val w=576; val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;textSize=26f;typeface=Typeface.create(Typeface.DEFAULT,Typeface.NORMAL)}
            val lines=text.split("\n"); val logo=if(logoPath.isNotBlank()) BitmapFactory.decodeFile(logoPath) else null
            val logoH=if(logo!=null) 170 else 0; val h=(lines.size*42+80+logoH).coerceAtLeast(300)
            val b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); val c=Canvas(b);c.drawColor(Color.WHITE); var y=42f
            if(logo!=null){ val scale=minOf(500f/logo.width,150f/logo.height); val dw=(logo.width*scale).toInt(); val dh=(logo.height*scale).toInt(); val dst=Rect((w-dw)/2,15,(w+dw)/2,15+dh); c.drawBitmap(logo,null,dst,paint); y=(30+dh).toFloat() }
            for(line in lines){val rtl=line.any{it.code in 0x0600..0x06FF};paint.textAlign=if(rtl)Paint.Align.RIGHT else Paint.Align.LEFT;c.drawText(line,if(rtl)w-24f else 24f,y,paint);y+=42};return b
        }
        val rows=text.lines().drop(1).filter{it.isNotBlank()}.map{it.split('|')}
        fun one(k:String)=rows.firstOrNull{it.firstOrNull()==k}?.drop(1)?.joinToString("|") ?: ""
        val items=rows.filter{it.firstOrNull()=="ITEM"}
        val footer=one("FOOTER").split('|').filter{it.isNotBlank()}
        val w=576; val h=760 + items.size*64 + footer.size*34
        val bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); val c=Canvas(bmp); c.drawColor(Color.WHITE)
        val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;typeface=Typeface.create(Typeface.DEFAULT,Typeface.NORMAL)}
        fun center(t:String,y:Float,size:Float,bold:Boolean=false){p.textSize=size;p.typeface=Typeface.create(Typeface.DEFAULT,if(bold)Typeface.BOLD else Typeface.NORMAL);p.textAlign=Paint.Align.CENTER;c.drawText(t,w/2f,y,p)}
        fun right(t:String,y:Float,size:Float=23f,bold:Boolean=false){p.textSize=size;p.typeface=Typeface.create(Typeface.DEFAULT,if(bold)Typeface.BOLD else Typeface.NORMAL);p.textAlign=Paint.Align.RIGHT;c.drawText(t,w-30f,y,p)}
        fun left(t:String,y:Float,size:Float=23f,bold:Boolean=false){p.textSize=size;p.typeface=Typeface.create(Typeface.DEFAULT,if(bold)Typeface.BOLD else Typeface.NORMAL);p.textAlign=Paint.Align.LEFT;c.drawText(t,30f,y,p)}
        fun line(y:Float){p.strokeWidth=2f;c.drawLine(28f,y,w-28f,y,p)}
        var y=32f
        val logo=if(logoPath.isNotBlank()) BitmapFactory.decodeFile(logoPath) else null
        if(logo!=null){val scale=minOf(350f/logo.width,120f/logo.height);val dw=(logo.width*scale).toInt();val dh=(logo.height*scale).toInt();c.drawBitmap(logo,null,Rect((w-dw)/2,y.toInt(),(w+dw)/2,y.toInt()+dh),p);y+=dh+18}
        else { center("kitty",y+58,58f,true); center("HERE",y+92,31f,true); y+=118 }
        line(y); y+=34
        right("رقم الفاتورة: ${one("INVOICE")}",y,22f,true); y+=34
        right("التاريخ: ${one("DATE").take(19)}",y,21f); y+=34
        if(one("PHONE").isNotBlank()){right("رقم الجوال: ${one("PHONE")}",y,21f);y+=34}
        line(y); y+=38
        right("المنتج / الخدمة",y,23f,true); left("الإجمالي",y,23f,true); y+=20; line(y); y+=34
        for(r in items){val name=r.getOrNull(1)?:"";val qty=r.getOrNull(2)?:"1";val unit=r.getOrNull(3)?:"0";val total=r.getOrNull(4)?:"0";right(name,y,21f,true);left("$total ر.س",y,21f,true);y+=29;right("الكمية $qty × $unit ر.س",y,18f);y+=34;line(y);y+=25}
        val total=one("TOTAL"); right("الإجمالي",y,25f,true); left("$total ر.س",y,27f,true); y+=42
        line(y); y+=38
        center("✓ تمت العملية بنجاح - مدى",y,23f,true); y+=34
        if(one("REF").isNotBlank()){center("مرجع العملية: ${one("REF")}",y,17f);y+=30}
        line(y); y+=42
        center("شكراً لزيارتكم ♥",y,30f,true); y+=36
        for(f in footer){center(f,y,20f);y+=30}
        center("@kitty_ksa1",y+8,22f,true); y+=44
        center("KITTY HERE",y,25f,true); y+=28
        center("♥  🐾  ♥",y,20f)
        return Bitmap.createBitmap(bmp,0,0,w,(y+32).toInt().coerceAtMost(h))
    }
    private fun printBitmap(manager:UsbManager,device:UsbDevice,bmp:Bitmap):Boolean { var target:UsbInterface?=null;var out:UsbEndpoint?=null;for(i in 0 until device.interfaceCount){val intf=device.getInterface(i);for(j in 0 until intf.endpointCount){val ep=intf.getEndpoint(j);if(ep.type==UsbConstants.USB_ENDPOINT_XFER_BULK&&ep.direction==UsbConstants.USB_DIR_OUT){target=intf;out=ep;break}};if(out!=null)break};if(target==null||out==null)return false;val conn=manager.openDevice(device)?:return false;if(!conn.claimInterface(target,true)){conn.close();return false};val bytes=escPosRaster(bmp);conn.bulkTransfer(out,byteArrayOf(0x1B,0x40),2,2000);var off=0;while(off<bytes.size){val n=minOf(4096,bytes.size-off);val chunk=bytes.copyOfRange(off,off+n);val sent=conn.bulkTransfer(out,chunk,chunk.size,4000);if(sent<=0)break;off+=sent};val cut=byteArrayOf(0x1D,0x56,0x41,0x10);conn.bulkTransfer(out,cut,cut.size,2000);conn.releaseInterface(target);conn.close();return off>=bytes.size }
    private fun escPosRaster(bitmap:Bitmap):ByteArray { val w=bitmap.width;val h=bitmap.height;val wb=(w+7)/8;val out=ByteArrayOutputStream();out.write(byteArrayOf(0x1D,0x76,0x30,0x00,(wb and 0xFF).toByte(),((wb shr 8) and 0xFF).toByte(),(h and 0xFF).toByte(),((h shr 8) and 0xFF).toByte()));for(y in 0 until h)for(xb in 0 until wb){var b=0;for(bit in 0..7){val x=xb*8+bit;if(x<w){val p=bitmap.getPixel(x,y);val gray=(Color.red(p)*30+Color.green(p)*59+Color.blue(p)*11)/100;if(gray<160)b=b or(1 shl(7-bit))}};out.write(b)};return out.toByteArray() }
}
