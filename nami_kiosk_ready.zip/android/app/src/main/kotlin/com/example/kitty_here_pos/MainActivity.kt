package com.example.kitty_here_pos

import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.net.Socket
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity: FlutterActivity() {
    private val NAMI_CHANNEL = "kittyhere/nami"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            NAMI_CHANNEL
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "sdkStatus" -> {
                    val available = findCLibraryClass() != null
                    result.success(mapOf(
                        "available" to available,
                        "message" to if (available) "SkyBand SDK found" else "SkyBandSDK-release.aar not found"
                    ))
                }

                "purchase" -> {
                    val ip = call.argument<String>("ip") ?: ""
                    val port = call.argument<Int>("port") ?: 8888
                    val terminalId = call.argument<String>("terminalId") ?: ""
                    val crn = call.argument<String>("crn") ?: ""
                    val amount12 = call.argument<String>("amount12") ?: ""
                    val printFlag = call.argument<Int>("printFlag") ?: 0

                    if (!Regex("^\\d{8}$").matches(crn)) {
                        result.success(mapOf("ok" to false, "message" to "Invalid CRN"))
                        return@setMethodCallHandler
                    }
                    if (!Regex("^\\d{12}$").matches(amount12)) {
                        result.success(mapOf("ok" to false, "message" to "Amount must be 12 digits"))
                        return@setMethodCallHandler
                    }

                    thread {
                        val response = runPurchase(
                            ip = ip,
                            port = port,
                            terminalId = terminalId,
                            crn = crn,
                            amount12 = amount12,
                            printFlag = printFlag
                        )
                        runOnUiThread { result.success(response) }
                    }
                }

                else -> result.notImplemented()
            }
        }
    }

    private fun findCLibraryClass(): Class<*>? {
        val candidates = listOf(
            "com.skyband.ecr.CLibraryLoad",
            "com.skyband.sdk.CLibraryLoad",
            "CLibraryLoad"
        )
        for (name in candidates) {
            try {
                return Class.forName(name)
            } catch (_: Throwable) {}
        }
        return null
    }

    private fun getInstance(clazz: Class<*>): Any? {
        return try {
            clazz.getMethod("getInstance").invoke(null)
        } catch (_: Throwable) {
            null
        }
    }

    private fun sha256(value: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(value.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun timestamp(): String {
        return SimpleDateFormat("ddMMyyHHmmss", Locale.US).format(Date())
    }

    private fun nextRef(crn: String): Pair<String, String> {
        val unique = ((System.currentTimeMillis() / 1000L) % 1_000_000L)
            .toString()
            .padStart(6, '0')
        return Pair(crn + unique, unique)
    }

    private fun callPack(
        lib: Any,
        reqData: String,
        txnType: Int,
        signature: String
    ): ByteArray? {
        val methods = lib.javaClass.methods.filter { it.name == "getPackData" }
        for (m in methods) {
            try {
                val params = m.parameterTypes
                if (params.size == 3) {
                    val args = arrayOfNulls<Any>(3)
                    args[0] = reqData
                    args[1] = when {
                        params[1] == Int::class.javaPrimitiveType || params[1] == Int::class.javaObjectType -> txnType
                        params[1] == String::class.java -> txnType.toString()
                        else -> txnType
                    }
                    args[2] = signature
                    val packed = m.invoke(lib, *args)
                    if (packed is ByteArray) return packed
                }
            } catch (_: Throwable) {}
        }
        return null
    }

    private fun callParse(lib: Any, data: ByteArray): String {
        val methods = lib.javaClass.methods.filter { it.name == "getParseData" }
        for (m in methods) {
            try {
                val out = m.invoke(lib, data)
                if (out != null) return out.toString()
            } catch (_: Throwable) {}
        }
        return ""
    }

    private fun runPurchase(
        ip: String,
        port: Int,
        terminalId: String,
        crn: String,
        amount12: String,
        printFlag: Int
    ): Map<String, Any?> {
        val clazz = findCLibraryClass()
            ?: return mapOf(
                "ok" to false,
                "message" to "SkyBandSDK-release.aar not found in APK"
            )

        val lib = getInstance(clazz)
            ?: return mapOf("ok" to false, "message" to "Could not initialize Nami SDK")

        val (ecrRef, unique6) = nextRef(crn)
        val reqData = "${timestamp()};$amount12;$printFlag;$ecrRef!"
        val signature = sha256(crn + terminalId)

        // Nami docs state Purchase request is packed by the SDK.
        // The exact numeric enum differs between SDK revisions, so we try the common documented values.
        val txnCandidates = listOf(0, 6)

        var packed: ByteArray? = null
        var txnUsed: Int? = null
        for (txn in txnCandidates) {
            packed = callPack(lib, reqData, txn, signature)
            if (packed != null && packed.isNotEmpty()) {
                txnUsed = txn
                break
            }
        }

        if (packed == null || packed.isEmpty()) {
            return mapOf(
                "ok" to false,
                "message" to "Nami SDK could not pack Purchase request"
            )
        }

        return try {
            Socket(ip, port).use { socket ->
                socket.soTimeout = 90_000
                socket.getOutputStream().write(packed)
                socket.getOutputStream().flush()

                val buffer = ByteArray(4096)
                val read = socket.getInputStream().read(buffer)
                if (read <= 0) {
                    return@use mapOf(
                        "ok" to false,
                        "message" to "No response from terminal",
                        "ecrRef" to ecrRef,
                        "txnType" to txnUsed
                    )
                }

                val raw = buffer.copyOf(read)
                val parsed = callParse(lib, raw)
                val fields = parsed.split(",")
                val responseCode = fields.getOrNull(0)?.trim() ?: ""
                val approvalCode = fields.getOrNull(1)?.trim() ?: ""

                mapOf(
                    "ok" to (responseCode == "00"),
                    "message" to parsed,
                    "responseCode" to responseCode,
                    "approvalCode" to approvalCode,
                    "ecrRef" to ecrRef,
                    "txnType" to txnUsed,
                    "amount12" to amount12
                )
            }
        } catch (e: Throwable) {
            mapOf(
                "ok" to false,
                "message" to (e.message ?: e.toString()),
                "ecrRef" to ecrRef
            )
        }
    }
}
