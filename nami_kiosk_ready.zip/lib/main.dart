import 'dart:io';
import 'package:flutter/material.dart';

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const Home(),
    );
  }
}

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final ip = TextEditingController(text: '172.20.10.3');
  final port = TextEditingController(text: '8888');
  String status = 'جاهز للاختبار';

  Future<void> testConnection() async {
    FocusScope.of(context).unfocus();
    final p = int.tryParse(port.text.trim());

    if (p == null) {
      setState(() => status = '❌ المنفذ غير صحيح');
      return;
    }

    setState(() => status = 'جاري الاتصال...');

    try {
      final socket = await Socket.connect(
        ip.text.trim(),
        p,
        timeout: const Duration(seconds: 8),
      );

      final remote = '${socket.remoteAddress.address}:${socket.remotePort}';
      socket.destroy();

      if (!mounted) return;
      setState(() => status = '✅ تم الاتصال بنجاح\n$remote');
    } on SocketException catch (e) {
      if (!mounted) return;
      setState(() => status = '❌ فشل الاتصال\n${e.message}\n${e.osError ?? ''}');
    } catch (e) {
      if (!mounted) return;
      setState(() => status = '❌ خطأ: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Nami Kiosk - ECR Test')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: ip,
              decoration: const InputDecoration(
                labelText: 'IP جهاز مدى',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: port,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'ECR Port',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton(
                onPressed: testConnection,
                child: const Text('اختبار الاتصال'),
              ),
            ),
            const SizedBox(height: 18),
            SelectableText(
              status,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
