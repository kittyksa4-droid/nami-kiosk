import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

const pink = Color(0xFFE66AA0);
const deepPink = Color(0xFFD94B84);
const cream = Color(0xFFFFFBF6);
const gridPink = Color(0xFFF5C3D6);
const ink = Color(0xFF4C353C);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Store.instance.load();
  runApp(const KittyHereApp());
  unawaited(CloudSync.syncEverything());
  unawaited(PendingPaymentJournal.finalizeFromJournal());
  Timer.periodic(const Duration(seconds: 30), (_) { unawaited(CloudSync.pullProducts()); unawaited(CloudSync.recoverManualSales()); unawaited(CloudSync.retryPendingSales()); unawaited(PendingPaymentJournal.finalizeFromJournal()); unawaited(NamiOfficialSdk.keepAlive(Store.instance.settings)); });
  unawaited(NamiOfficialSdk.keepAlive(Store.instance.settings));
}

class KittyHereApp extends StatelessWidget {
  const KittyHereApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kitty Here',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: pink),
        scaffoldBackgroundColor: cream,
        fontFamily: 'sans',
        useMaterial3: true,
      ),
      home: const WelcomeScreen(),
    );
  }
}

class ProductAddonRule {
  String productId;
  int maxQty;
  ProductAddonRule({required this.productId, this.maxQty = 1});
  Map<String,dynamic> toJson()=>{'productId':productId,'maxQty':maxQty};
  factory ProductAddonRule.fromJson(Map<String,dynamic> j)=>ProductAddonRule(productId:j['productId']??'',maxQty:j['maxQty']??1);
}

class Product {
  String id;
  String nameAr;
  String nameEn;
  double price;
  String category;
  int stock; // -1 = unlimited
  bool enabled;
  String? imagePath;
  String iconName;
  String description;
  bool requiresLounge;
  bool quickHome;
  bool popularBadge;
  List<ProductAddonRule> addons;

  Product({
    required this.id,
    required this.nameAr,
    required this.nameEn,
    required this.price,
    required this.category,
    this.stock = -1,
    this.enabled = true,
    this.imagePath,
    this.iconName = 'star',
    this.description = '',
    this.requiresLounge = false,
    this.quickHome = false,
    this.popularBadge = false,
    this.addons = const [],
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'nameAr': nameAr,
        'nameEn': nameEn,
        'price': price,
        'category': category,
        'stock': stock,
        'enabled': enabled,
        'imagePath': imagePath,
        'iconName': iconName,
        'description': description,
        'requiresLounge': requiresLounge,
        'quickHome': quickHome,
        'popularBadge': popularBadge,
        'addons': addons.map((e)=>e.toJson()).toList(),
      };

  factory Product.fromJson(Map<String, dynamic> j) => Product(
        id: j['id'],
        nameAr: j['nameAr'],
        nameEn: j['nameEn'] ?? '',
        price: (j['price'] as num).toDouble(),
        category: j['category'] ?? 'منتجات',
        stock: j['stock'] ?? -1,
        enabled: j['enabled'] ?? true,
        imagePath: j['imagePath'],
        iconName: j['iconName'] ?? 'star',
        description: j['description'] ?? '',
        requiresLounge: j['requiresLounge'] ?? ((j['category'] ?? '') == 'تذاكر'),
        quickHome: j['quickHome'] ?? false,
        popularBadge: j['popularBadge'] ?? false,
        addons: ((j['addons'] as List?) ?? const []).map((e)=>ProductAddonRule.fromJson(Map<String,dynamic>.from(e))).toList(),
      );
}

class SaleItem {
  String productId;
  String name;
  int qty;
  double unitPrice;

  SaleItem(this.productId, this.name, this.qty, this.unitPrice);

  Map<String, dynamic> toJson() => {
        'productId': productId,
        'name': name,
        'qty': qty,
        'unitPrice': unitPrice,
      };

  factory SaleItem.fromJson(Map<String, dynamic> j) => SaleItem(
        j['productId'],
        j['name'],
        j['qty'],
        (j['unitPrice'] as num).toDouble(),
      );
}


String nextSaleId() {
  int maxId = 0;
  for (final s in Store.instance.sales) {
    final n = int.tryParse(s.id);
    if (n != null && n > maxId) maxId = n;
  }
  return (maxId + 1).toString().padLeft(6, '0');
}

class PendingPaymentJournal {
  static const _key = 'pending_payment_v61';

  static String createEcrRef(AppSettings settings) {
    final crn = settings.crn.trim();
    final suffix = (DateTime.now().microsecondsSinceEpoch % 1000000).toString().padLeft(6, '0');
    return '$crn$suffix';
  }

  static Future<void> save({
    required String ecrRef,
    required String customerPhone,
    required double total,
    required List<SaleItem> items,
  }) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_key, jsonEncode({
      'ecrRef': ecrRef,
      'customerPhone': customerPhone,
      'total': total,
      'createdAt': DateTime.now().toIso8601String(),
      'items': items.map((e) => e.toJson()).toList(),
    }));
  }

  static Future<Map<String,dynamic>?> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_key);
    if (raw == null || raw.isEmpty) return null;
    try { return Map<String,dynamic>.from(jsonDecode(raw)); } catch (_) { return null; }
  }

  static Future<void> clear() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(_key);
  }

  static Future<bool> finalizeFromJournal() async {
    final j = await load();
    if (j == null) return false;
    final ref = '${j['ecrRef'] ?? ''}';
    if (ref.isEmpty) return false;

    final already = Store.instance.sales.where((x) => x.paymentRef == ref).firstOrNull;
    if (already != null) {
      await clear();
      return true;
    }

    final check = await NamiOfficialSdk.checkStatus(Store.instance.settings, ref);
    if (check['ok'] == true) {
      final items = ((j['items'] as List?) ?? const [])
          .map((e) => SaleItem.fromJson(Map<String,dynamic>.from(e)))
          .toList();
      if (items.isEmpty) return false;

      final sale = Sale(
        id: nextSaleId(),
        createdAt: DateTime.tryParse('${j['createdAt'] ?? ''}') ?? DateTime.now(),
        items: items,
        total: (j['total'] as num?)?.toDouble() ?? items.fold(0.0, (a,b)=>a+b.qty*b.unitPrice),
        paymentStatus: 'APPROVED',
        paymentRef: ref,
        paymentMethod: 'mada',
        source: 'kiosk_recovered',
        customerPhone: '${j['customerPhone'] ?? ''}',
      );
      await Store.instance.addSale(sale);

      bool printed = false;
      for (int i=0; i<3 && !printed; i++) {
        printed = await UsbPrinter.printReceipt(
          ReceiptBuilder.build(sale),
          logoPath: Store.instance.settings.receiptLogoPath,
        );
        if (!printed) await Future.delayed(const Duration(seconds: 1));
      }
      sale.printed = printed;
      await Store.instance.save();
      await clear();
      return true;
    }

    if (check['declined'] == true || check['stage'] == 'DECLINED') {
      await clear();
    }
    return false;
  }
}

class Sale {
  String id;
  DateTime createdAt;
  List<SaleItem> items;
  double total;
  String paymentStatus;
  String paymentRef;
  bool printed;
  String customerPhone;
  String paymentMethod;
  String source;

  Sale({
    required this.id,
    required this.createdAt,
    required this.items,
    required this.total,
    required this.paymentStatus,
    required this.paymentRef,
    this.printed = false,
    this.customerPhone = '',
    this.paymentMethod = 'mada',
    this.source = 'kiosk',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'createdAt': createdAt.toIso8601String(),
        'items': items.map((e) => e.toJson()).toList(),
        'total': total,
        'paymentStatus': paymentStatus,
        'paymentRef': paymentRef,
        'printed': printed,
        'customerPhone': customerPhone,
        'paymentMethod': paymentMethod,
        'source': source,
      };

  factory Sale.fromJson(Map<String, dynamic> j) => Sale(
        id: j['id'],
        createdAt: DateTime.parse(j['createdAt']),
        items: (j['items'] as List).map((e) => SaleItem.fromJson(Map<String, dynamic>.from(e))).toList(),
        total: (j['total'] as num).toDouble(),
        paymentStatus: j['paymentStatus'] ?? 'APPROVED',
        paymentRef: j['paymentRef'] ?? '',
        printed: j['printed'] ?? false,
        customerPhone: j['customerPhone'] ?? '',
        paymentMethod: j['paymentMethod'] ?? ((j['paymentStatus'] ?? '') == 'MANUAL' ? 'other' : 'mada'),
        source: j['source'] ?? ((j['paymentStatus'] ?? '') == 'MANUAL' ? 'tablet_manual' : 'kiosk'),
      );
}

class AppSettings {
  String namiIp;
  int namiPort;
  String terminalId;
  String crn;
  bool demoPayment;
  String remoteApi;
  String remoteToken;
  bool kioskMode;
  String adminPin;
  String receiptLogoPath;
  String receiptTitle;
  String receiptFooter;
  String loyaltyQrPath;
  String shiftStart;

  AppSettings({
    this.namiIp = '172.20.10.2',
    this.namiPort = 1024,
    this.terminalId = '11232541',
    this.crn = '73154354',
    this.demoPayment = true,
    this.remoteApi = '',
    this.remoteToken = '',
    this.kioskMode = true,
    this.adminPin = '2468',
    this.receiptLogoPath = '',
    this.receiptTitle = 'KITTY HERE',
    this.receiptFooter = 'شكراً لزيارتكم ♥|نتمنى لكم وقتاً سعيداً مع قططنا|@kitty_ksa1',
    this.loyaltyQrPath = 'assets/loyalty_qr.png',
    this.shiftStart = '',
  });

  Map<String, dynamic> toJson() => {
        'namiIp': namiIp,
        'namiPort': namiPort,
        'terminalId': terminalId,
        'crn': crn,
        'demoPayment': demoPayment,
        'remoteApi': remoteApi,
        'remoteToken': remoteToken,
        'kioskMode': kioskMode,
        'adminPin': adminPin,
        'receiptLogoPath': receiptLogoPath,
        'receiptTitle': receiptTitle,
        'receiptFooter': receiptFooter,
        'loyaltyQrPath': loyaltyQrPath,
        'shiftStart': shiftStart,
      };

  factory AppSettings.fromJson(Map<String, dynamic> j) => AppSettings(
        namiIp: j['namiIp'] ?? '172.20.10.2',
        namiPort: j['namiPort'] ?? 1024,
        terminalId: j['terminalId'] ?? '11232541',
        crn: (j['crn'] ?? '').toString().trim().isEmpty ? '73154354' : j['crn'],
        demoPayment: j['demoPayment'] ?? true,
        remoteApi: j['remoteApi'] ?? '',
        remoteToken: j['remoteToken'] ?? '',
        kioskMode: j['kioskMode'] ?? true,
        adminPin: j['adminPin'] ?? '2468',
        receiptLogoPath: j['receiptLogoPath'] ?? '',
        receiptTitle: j['receiptTitle'] ?? 'KITTY HERE',
        receiptFooter: j['receiptFooter'] ?? 'شكراً لزيارتكم ♥|نتمنى لكم وقتاً سعيداً مع قططنا|@kitty_ksa1',
        loyaltyQrPath: j['loyaltyQrPath'] ?? 'assets/loyalty_qr.png',
        shiftStart: j['shiftStart'] ?? '',
      );
}

class Store {
  Store._();
  static final instance = Store._();

  final ValueNotifier<int> rev = ValueNotifier(0);
  List<Product> products = [];
  List<Sale> sales = [];
  AppSettings settings = AppSettings();

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final productsJson = p.getString('products');
    final salesJson = p.getString('sales');
    final settingsJson = p.getString('settings');

    if (productsJson == null) {
      products = _defaults();
      await save();
    } else {
      products = (jsonDecode(productsJson) as List)
          .map((e) => Product.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    }

    if (salesJson != null) {
      sales = (jsonDecode(salesJson) as List)
          .map((e) => Sale.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    }

    if (settingsJson != null) {
      settings = AppSettings.fromJson(Map<String, dynamic>.from(jsonDecode(settingsJson)));
    }
  }

  List<Product> _defaults() => [
        Product(id: 'shower', nameAr: 'الشاور - عرض حالياً', nameEn: 'Shower', price: 49, category: 'خدمات', iconName: 'shower'),
        Product(id: 'ticket30', nameAr: 'Ticket نص ساعة + تريت', nameEn: '30 min Ticket + Treat', price: 35, category: 'تذاكر', iconName: 'timer'),
        Product(id: 'ticketOpen', nameAr: 'Ticket وقت مفتوح', nameEn: 'Open Time Ticket', price: 65, category: 'تذاكر', iconName: 'infinity'),
        Product(id: 'mug', nameAr: 'Mug', nameEn: 'Mug', price: 25, category: 'منتجات', iconName: 'mug'),
        Product(id: 'photo', nameAr: 'فوتو بوث Photo Booth', nameEn: 'Photo Booth', price: 10, category: 'إضافات', iconName: 'camera'),
        Product(id: 'extra15', nameAr: 'وقت إضافي 15 دقيقة', nameEn: 'Extra 15 Minutes', price: 15, category: 'إضافات', iconName: 'timer'),
        Product(id: 'treat', nameAr: 'تريت إضافي', nameEn: 'Extra Treat', price: 5, category: 'إضافات', iconName: 'treat'),
        Product(id: 'companion', nameAr: 'مرافق', nameEn: 'Companion', price: 10, category: 'إضافات', iconName: 'person'),
        Product(id: 'nails', nameAr: 'قص أظافر', nameEn: 'Nail Trim', price: 25, category: 'خدمات', iconName: 'scissors'),
        Product(id: 'stickers', nameAr: 'ملصقات', nameEn: 'Stickers', price: 15, category: 'منتجات', iconName: 'sticker'),
      ];

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('products', jsonEncode(products.map((e) => e.toJson()).toList()));
    await p.setString('sales', jsonEncode(sales.map((e) => e.toJson()).toList()));
    await p.setString('settings', jsonEncode(settings.toJson()));
    rev.value++;
  }

  Future<void> addSale(Sale sale) async {
    sales.insert(0, sale);
    for (final item in sale.items) {
      final p = products.where((x) => x.id == item.productId).firstOrNull;
      if (p != null && p.stock >= 0) p.stock = (p.stock - item.qty).clamp(0, 999999);
    }
    await save();
    unawaited(CloudSync.pushSale(sale));
  }
}

class CloudSync {
  static const base='https://xlonnatisipprsscqujt.supabase.co/functions/v1/kitty-kiosk-sync';
  static const token='BouRP2iUk8DoSt1Qsqg4K3zG8xDx8wUf1Kpesr0OI-M';
  static Map<String,String> get headers=>{'content-type':'application/json','x-device-token':token};
  static const _syncedSalesKey='cloud_synced_sale_ids_v48';
  static bool _retryingSales=false;

  static Future<Set<String>> _syncedSaleIds() async {
    final p=await SharedPreferences.getInstance();
    return (p.getStringList(_syncedSalesKey)??const <String>[]).toSet();
  }
  static Future<void> _markSaleSynced(String id) async {
    final p=await SharedPreferences.getInstance();
    final ids=(p.getStringList(_syncedSalesKey)??<String>[]).toSet()..add(id);
    // Keep a generous rolling set; invoice IDs are small but this avoids unbounded prefs forever.
    final list=ids.toList();
    await p.setStringList(_syncedSalesKey,list.length>5000?list.sublist(list.length-5000):list);
  }
  static Future<void> retryPendingSales() async {
    if(_retryingSales)return;
    _retryingSales=true;
    try{
      final synced=await _syncedSaleIds();
      final pending=Store.instance.sales.where((x)=>
        (x.paymentStatus=='APPROVED'||x.paymentStatus=='MANUAL')&&!synced.contains(x.id)).toList()
        ..sort((a,b){
          // الفواتير اليدوية القديمة أولوية في الاسترجاع، ثم الأقدم فالأحدث.
          final am=a.paymentStatus=='MANUAL'?0:1;
          final bm=b.paymentStatus=='MANUAL'?0:1;
          if(am!=bm)return am.compareTo(bm);
          return a.createdAt.compareTo(b.createdAt);
        });
      for(final sale in pending){
        // مهم: فشل فاتورة قديمة واحدة لا يوقف مزامنة بقية الفواتير.
        await pushSale(sale);
      }
    }finally{_retryingSales=false;}
  }

  static Future<bool> _post(String path,Map<String,dynamic> body) async {
    try{final r=await http.post(Uri.parse('$base/$path'),headers:headers,body:jsonEncode(body)).timeout(const Duration(seconds:12));return r.statusCode>=200&&r.statusCode<300;}catch(_){return false;}
  }

  static Future<List<dynamic>?> _cloudProducts() async {
    try{
      final r=await http.get(Uri.parse('$base/products'),headers:headers).timeout(const Duration(seconds:12));
      if(r.statusCode<200||r.statusCode>=300)return null;
      final j=jsonDecode(r.body);
      if(j is List)return j;
      if(j is Map&&j['products'] is List)return j['products'] as List;
      return null;
    }catch(_){return null;}
  }

  static Product _product(Map<String,dynamic>x, Map<String,String> uuidToLocal, Map<String,int> uuidToMax)=>Product(
    id:(x['sku']??x['local_id']??x['id']).toString(),
    nameAr:(x['name']??'منتج').toString(),nameEn:'',
    price:((x['price']??0)as num).toDouble(),
    category:(x['category']??'منتجات').toString(),
    stock:x['stock']==null?-1:(x['stock']as num).toInt(),
    enabled:x['active']!=false,
    iconName:((x['metadata'] is Map?x['metadata']['icon_name']:null)??'star').toString(),
    description:(x['description']??'').toString(),
    requiresLounge:(x['metadata'] is Map && x['metadata']['requires_lounge'] != null) ? x['metadata']['requires_lounge']==true : (x['category']??'').toString()=='تذاكر',
    quickHome:(x['metadata'] is Map && x['metadata']['quick_home']==true),
    popularBadge:(x['metadata'] is Map && x['metadata']['popular_badge']==true),
    addons:(x['kh_product_addons'] is List?x['kh_product_addons'] as List:const[])
      .where((a)=>a is Map&&a['active']!=false&&(a['name']??'').toString().startsWith('PRODUCT:'))
      .map((a){
        final cloudId=(a['name']??'').toString().substring(8);
        return ProductAddonRule(productId:uuidToLocal[cloudId]??cloudId,maxQty:(uuidToMax[cloudId]??10).clamp(1,99));
      }).toList()
  );

  static Future<bool> pullProducts() async {
    final rows=await _cloudProducts();
    if(rows==null)return false; // لا نمسح المحلي عند انقطاع الشبكة
    final next=<Product>[];
    final uuidToLocal=<String,String>{};
    final uuidToMax=<String,int>{};
    for(final raw in rows){
      if(raw is! Map)continue;
      final x=Map<String,dynamic>.from(raw);
      uuidToLocal[(x['id']??'').toString()]=(x['sku']??x['local_id']??x['id']).toString();
      uuidToMax[(x['id']??'').toString()]=((x['max_quantity']??10) as num).toInt();
    }
    int orderOf(dynamic v){if(v is Map){final n=v['sort_order'];if(n is num)return n.toInt();}return 0;}
    final sortedRows=[...rows]..sort((a,b)=>orderOf(a).compareTo(orderOf(b)));
    for(final raw in sortedRows){
      if(raw is! Map)continue;
      final x=Map<String,dynamic>.from(raw);
      final np=_product(x,uuidToLocal,uuidToMax);
      final oldLocal=Store.instance.products.where((p)=>p.id==np.id).firstOrNull;
      final meta=x['metadata'];
      if(oldLocal!=null){
        if(meta is! Map || !meta.containsKey('quick_home')) np.quickHome=oldLocal.quickHome;
        if(meta is! Map || !meta.containsKey('popular_badge')) np.popularBadge=oldLocal.popularBadge;
        if(meta is! Map || !meta.containsKey('requires_lounge')) np.requiresLounge=oldLocal.requiresLounge;
      }
      next.add(np);
    }
    // السحابة هي المصدر الرئيسي: أي منتج حُذف من Back Office لن يكون في rows
    // وبالتالي يختفي من التابلت عند استبدال القائمة.
    Store.instance.products..clear()..addAll(next);
    await Store.instance.save();
    return true;
  }

  static Future<void> recoverManualSales() async {
    final manual=Store.instance.sales.where((x)=>x.paymentStatus=='MANUAL').toList()
      ..sort((a,b)=>a.createdAt.compareTo(b.createdAt));
    for(final sale in manual){ await pushSale(sale); }
  }

  static Future<void> syncEverything() async {
    await _post('heartbeat',{'device_code':'KITTY-TABLET-01','app_version':'V61'});
    final cloud=await _cloudProducts();
    // Bootstrap فقط لو قاعدة المنتجات السحابية فارغة تماماً.
    // هذا يمنع التابلت من إعادة إنشاء منتج حذفه المدير.
    if(cloud!=null&&cloud.isEmpty){
      final ps=Store.instance.products.where((p)=>!p.id.startsWith('addon_')).toList().asMap().entries.map((e)=>{
        'local_id':e.value.id,'name':e.value.nameAr,'name_en':e.value.nameEn,'category':e.value.category,
        'price':e.value.price,'stock':e.value.stock,'active':e.value.enabled,'sort_order':e.key,
        'description':e.value.description,'max_quantity':10,'icon_name':e.value.iconName,'requires_lounge':e.value.requiresLounge,'quick_home':e.value.quickHome,'popular_badge':e.value.popularBadge}).toList();
      if(ps.isNotEmpty)await _post('bootstrap',{'products':ps});
    }
    if(cloud!=null)await pullProducts();
    await recoverManualSales();
    await retryPendingSales();
  }

  static Future<bool> pushProduct(Product p,{int? sortOrder}) async => _post('product',{'local_id':p.id,'name':p.nameAr,'name_en':p.nameEn,'category':p.category,'price':p.price,'stock':p.stock,'active':p.enabled,'sort_order':sortOrder??Store.instance.products.indexOf(p),'description':p.description,'max_quantity':10,'icon_name':p.iconName,'requires_lounge':p.requiresLounge,'quick_home':p.quickHome,'popular_badge':p.popularBadge,'addon_local_ids':p.addons.map((a)=>a.productId).toList()});
  static Future<bool> deleteProduct(Product p) async => _post('product-delete',{'local_id':p.id});
  static Future<bool> closeShift(DateTime openedAt,DateTime closedAt) async => _post('shift-close',{
    'opened_at':openedAt.toUtc().toIso8601String(),
    'closed_at':closedAt.toUtc().toIso8601String(),
    'reconciliation_status':'closed'
  });


  static Future<bool> pushSale(Sale sale) async {
    if(!(sale.paymentStatus=='APPROVED'||sale.paymentStatus=='MANUAL'))return false;
    final ok=await _post('sale',{'local_id':'KITTY-TABLET-01-${sale.id}','invoice_no':sale.id,'customer_phone':sale.customerPhone,
      'total':sale.total,'payment_method':sale.paymentMethod,'source':sale.source,'nami_reference':sale.paymentRef,
      'created_at':sale.createdAt.toUtc().toIso8601String(),'shift_opened_at':Store.instance.settings.shiftStart.isEmpty?null:(DateTime.tryParse(Store.instance.settings.shiftStart)?.toUtc().toIso8601String()),
      'items':sale.items.map((x)=>{'product_local_id':x.productId,'name':x.name,'quantity':x.qty,'unit_price':x.unitPrice}).toList()});
    if(ok)await _markSaleSynced(sale.id);
    return ok;
  }
}

extension FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}

class GridPaper extends StatelessWidget {
  final Widget child;
  const GridPaper({super.key, required this.child});
  @override
  Widget build(BuildContext context) => CustomPaint(
        painter: GridPainter(),
        child: child,
      );
}

class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = gridPink.withOpacity(.45)
      ..strokeWidth = 1;
    for (double x = 0; x < size.width; x += 38) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += 38) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});
  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  @override
  void initState() {
    super.initState();
    _applyKiosk();
  }

  Future<void> _applyKiosk() async {
    if (Store.instance.settings.kioskMode) {
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
      await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
    } else {
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GridPaper(
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  const Text('kitty here', style: TextStyle(fontSize: 44, fontWeight: FontWeight.w900, color: deepPink)),
                  const Text('CAT LOUNGE', style: TextStyle(letterSpacing: 4, color: pink)),
                  const SizedBox(height: 20),
                  Image.asset('assets/kitty_mascot.jpg', height: 330, fit: BoxFit.contain),
                  const SizedBox(height: 10),
                  const Text('وش ودك اليوم؟', style: TextStyle(fontSize: 42, color: deepPink, fontWeight: FontWeight.w900)),
                  const Text('ادخل الصالة أو اطلب مباشرة', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: ink)),
                  const SizedBox(height: 20),
                  SizedBox(width:430,height:72,child:FilledButton.icon(
                    style:FilledButton.styleFrom(backgroundColor:deepPink),
                    onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const RulesScreen(loungeEntryFlow:true))),
                    icon:const Icon(Icons.pets,size:30),label:const Text('🐱 دخول صالة القطط',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)))),
                  const SizedBox(height:12),
                  SizedBox(width:430,height:64,child:OutlinedButton.icon(
                    onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const QuickShopScreen())),
                    icon:const Icon(Icons.local_cafe_outlined,size:28),label:const Text('🥤 مشروبات ومنتجات فقط',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)))),
                  const SizedBox(height:16),
                  const QuickHomePreview(),
                  const SizedBox(height: 16),
                  TextButton(
                    onPressed: () => _showAdminPin(context),
                    child: const Text('خروج الإدارة', style: TextStyle(color: Colors.black26, fontSize: 12)),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showAdminPin(BuildContext context) {
    final c = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('دخول الإدارة'),
        content: TextField(controller: c, obscureText: true, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'الرمز')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () {
              if (c.text == Store.instance.settings.adminPin) {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminHome()));
              }
            },
            child: const Text('دخول'),
          )
        ],
      ),
    );
  }
}

class RulesScreen extends StatefulWidget {
  final Map<String,int>? checkoutCart;
  final double? checkoutTotal;
  final bool loungeEntryFlow;
  const RulesScreen({super.key,this.checkoutCart,this.checkoutTotal,this.loungeEntryFlow=false});

  @override
  State<RulesScreen> createState() => _RulesScreenState();
}

class _RulesScreenState extends State<RulesScreen> {
  int waitSeconds = 3;
  Timer? _rulesTimer;

  @override
  void initState() {
    super.initState();
    _rulesTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) { timer.cancel(); return; }
      if (waitSeconds <= 1) {
        timer.cancel();
        setState(() => waitSeconds = 0);
      } else {
        setState(() => waitSeconds--);
      }
    });
  }

  @override
  void dispose() {
    _rulesTimer?.cancel();
    super.dispose();
  }

  void next(BuildContext context) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => EntryInstructionsScreen(checkoutCart:widget.checkoutCart,checkoutTotal:widget.checkoutTotal,loungeEntryFlow:widget.loungeEntryFlow)),
    );
  }

  Widget ruleCard(String icon, String title, String subtitle) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Text(icon, style: const TextStyle(fontSize: 38)),
              const SizedBox(width: 18),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        color: deepPink,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GridPaper(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(30),
            child: Column(
              children: [
                const SizedBox(height: 20),
                const Text(
                  'قبل ما تبدأ 🤍',
                  style: TextStyle(
                    fontSize: 38,
                    fontWeight: FontWeight.w900,
                    color: deepPink,
                  ),
                ),
                const SizedBox(height: 24),
                ruleCard('🎟️', 'التذكرة لشخص واحد فقط', 'لا يمكن تبديل التذكرة بين الأشخاص.'),
                ruleCard('↩️', 'التذاكر غير قابلة للاسترجاع', 'بعد إتمام عملية الشراء لا يمكن استرجاع التذكرة.'),
                ruleCard('🐱', 'سلامة القطط أولويتنا', 'إذا كان طفلك يخاف من القطط أو غير مرتاح، يفضّل التأكد قبل شراء التذكرة.'),
                ruleCard('👥', 'تغيير المرافق', 'يمكن تغيير المرافق مقابل 10 ريال.'),
                const SizedBox(height: 18),
                SizedBox(
                  width: 420,
                  height: 66,
                  child: FilledButton(
                    onPressed: waitSeconds == 0 ? () => next(context) : null,
                    child: Text(
                      waitSeconds > 0
                          ? 'يرجى قراءة الشروط ($waitSeconds)'
                          : 'استمرارك يعني موافقتك على شروط الدخول',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),

              ],
            ),
          ),
        ),
      ),
    );
  }
}

class EntryInstructionsScreen extends StatefulWidget {
  final Map<String,int>? checkoutCart;
  final double? checkoutTotal;
  final bool loungeEntryFlow;
  const EntryInstructionsScreen({super.key,this.checkoutCart,this.checkoutTotal,this.loungeEntryFlow=false});

  @override
  State<EntryInstructionsScreen> createState() => _EntryInstructionsScreenState();
}

class _EntryInstructionsScreenState extends State<EntryInstructionsScreen> {
  int step = 0;
  int waitSeconds = 3;
  Timer? _instructionTimer;

  @override
  void initState() {
    super.initState();
    _startInstructionWait();
  }

  void _startInstructionWait() {
    _instructionTimer?.cancel();
    waitSeconds = 3;
    _instructionTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) { timer.cancel(); return; }
      if (waitSeconds <= 1) {
        timer.cancel();
        setState(() => waitSeconds = 0);
      } else {
        setState(() => waitSeconds--);
      }
    });
  }

  @override
  void dispose() {
    _instructionTimer?.cancel();
    super.dispose();
  }

  static const List<List<String>> data = [
    ['👟', 'الخطوة الأولى', 'بعد إتمام طلبك، انزع الحذاء وضعه في المكان المخصص.'],
    ['🧦', 'الخطوة الثانية', 'ارتدِ الكيس المخصص لدخول صالة القطط.'],
    ['🧴', 'الخطوة الثالثة', 'عقّم يديك جيدًا قبل الدخول والتعامل مع القطط.'],
  ];

  @override
  Widget build(BuildContext context) {
    final x = data[step];
    return Scaffold(
      body: GridPaper(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(34),
            child: Column(
              children: [
                const Spacer(),
                Text(x[0], style: const TextStyle(fontSize: 110)),
                const SizedBox(height: 20),
                Text(
                  x[1],
                  style: const TextStyle(
                    fontSize: 38,
                    fontWeight: FontWeight.w900,
                    color: deepPink,
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  x[2],
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.w800,
                    height: 1.5,
                  ),
                ),
                const Spacer(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    3,
                    (i) => Container(
                      margin: const EdgeInsets.all(5),
                      width: i == step ? 34 : 12,
                      height: 12,
                      decoration: BoxDecoration(
                        color: i == step ? deepPink : gridPink,
                        borderRadius: BorderRadius.circular(9),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 25),
                SizedBox(
                  width: 430,
                  height: 72,
                  child: FilledButton(
                    onPressed: waitSeconds > 0 ? null : () {
                      if (step < 2) {
                        setState(() => step++);
                        _startInstructionWait();
                      } else {
                        if(widget.checkoutCart!=null && widget.checkoutTotal!=null){
                          Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>CheckoutScreen(cart:widget.checkoutCart!,total:widget.checkoutTotal!)));
                        }else{
                          Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>MenuScreen(loungePrecleared:widget.loungeEntryFlow)));
                        }
                      }
                    },
                    child: Text(
                      waitSeconds > 0
                          ? '${step < 2 ? 'التالي' : 'ابدأ الطلب'} ($waitSeconds)'
                          : (step < 2 ? 'التالي' : 'ابدأ الطلب'),
                      style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


class QuickHomePreview extends StatelessWidget {
  const QuickHomePreview({super.key});
  @override Widget build(BuildContext context)=>ValueListenableBuilder<int>(
    valueListenable:Store.instance.rev,builder:(_,__,___){
      final q=Store.instance.products.where((p)=>p.enabled&&p.quickHome&&!p.requiresLounge).take(4).toList();
      if(q.isEmpty)return const SizedBox.shrink();
      return SizedBox(width:620,child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        const Text('شراء سريع ⚡',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),
        const SizedBox(height:8),
        Wrap(spacing:10,runSpacing:10,children:q.map((p)=>ActionChip(
          avatar:Icon(p.popularBadge?Icons.local_fire_department:Icons.add_shopping_cart,color:deepPink),
          label:Text('${p.popularBadge?"🔥 ":""}${p.nameAr} · ${p.price.toStringAsFixed(0)} ر.س',style:const TextStyle(fontSize:17,fontWeight:FontWeight.bold)),
          onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>QuickShopScreen(initialProductId:p.id))),
        )).toList())
      ]));
    });
}


bool isSoldOut(Product p) => p.stock == 0;

Set<String> autoPopularProductIds() {
  final since = DateTime.now().subtract(const Duration(days: 7));
  final counts = <String,int>{};
  for (final sale in Store.instance.sales) {
    if ((sale.paymentStatus == 'APPROVED' || sale.paymentStatus == 'MANUAL') &&
        !sale.createdAt.isBefore(since)) {
      for (final item in sale.items) {
        counts[item.productId] = (counts[item.productId] ?? 0) + item.qty;
      }
    }
  }
  final ranked = counts.entries.toList()..sort((a,b)=>b.value.compareTo(a.value));
  return ranked.take(4).where((e)=>e.value>0).map((e)=>e.key).toSet();
}

class QuickShopScreen extends StatefulWidget {
  final String? initialProductId;
  const QuickShopScreen({super.key,this.initialProductId});
  @override State<QuickShopScreen> createState()=>_QuickShopScreenState();
}
class _QuickShopScreenState extends State<QuickShopScreen>{
  final Map<String,int> cart={};
  @override void initState(){super.initState();if(widget.initialProductId!=null)cart[widget.initialProductId!]=1;}
  double get total=>cart.entries.fold(0.0,(a,e){final p=Store.instance.products.where((x)=>x.id==e.key).firstOrNull;return a+(p?.price??0)*e.value;});
  @override Widget build(BuildContext context)=>ValueListenableBuilder<int>(valueListenable:Store.instance.rev,builder:(_,__,___){
    final items=Store.instance.products.where((p)=>p.enabled&&p.quickHome&&!p.requiresLounge).toList();
    final count=cart.values.fold(0,(a,b)=>a+b);
    return Scaffold(appBar:AppBar(title:const Text('شراء سريع ⚡'),actions:[Badge(label:Text('$count'),child:IconButton(icon:const Icon(Icons.shopping_cart),onPressed:count==0?null:()=>_cart()))]),
      body:Column(children:[
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.all(18),
            itemCount: items.length,
            separatorBuilder: (context, index) => const SizedBox(height: 12),
            itemBuilder: (context, index) {
              final Product product = items[index];
              final int quantity = cart[product.id] ?? 0;
              final bool soldOut = isSoldOut(product);
              return Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.all(14),
                  leading: SizedBox(
                    width: 80,
                    height: 70,
                    child: ProductVisual(product: product),
                  ),
                  title: Text(
                    '${(product.popularBadge || autoPopularProductIds().contains(product.id)) ? "🔥 " : ""}${product.nameAr}',
                    style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900),
                  ),
                  subtitle: Text(
                    '${product.price.toStringAsFixed(0)} ريال${soldOut ? " · نفد مؤقتًا" : ""}',
                    style: TextStyle(
                      fontSize: 19,
                      color: soldOut ? Colors.red : deepPink,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  trailing: quantity == 0
                      ? FilledButton(
                          onPressed: soldOut ? null : () async { setState(() => cart[product.id] = 1); await _quickAddons(product); },
                          child: const Text('إضافة'),
                        )
                      : Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              onPressed: () => setState(() {
                                if (quantity <= 1) {
                                  cart.remove(product.id);
                                } else {
                                  cart[product.id] = quantity - 1;
                                }
                              }),
                              icon: const Icon(Icons.remove_circle_outline),
                            ),
                            Text(
                              '$quantity',
                              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                            ),
                            IconButton(
                              onPressed: () => setState(() => cart[product.id] = quantity + 1),
                              icon: const Icon(Icons.add_circle_outline),
                            ),
                          ],
                        ),
                ),
              );
            },
          ),
        ),
        if(count>0)SafeArea(child:Container(padding:const EdgeInsets.all(14),decoration:const BoxDecoration(color:Colors.white,boxShadow:[BoxShadow(blurRadius:10,color:Color(0x22000000))]),child:SizedBox(width:double.infinity,height:64,child:FilledButton(
          style:FilledButton.styleFrom(backgroundColor:deepPink),onPressed:_cart,child:Text('🛒 $count منتجات — ${total.toStringAsFixed(0)} ريال — متابعة للدفع',style:const TextStyle(fontSize:21,fontWeight:FontWeight.w900)))))),
      ]));
  });
  Future<void> _quickAddons(Product p) async {
    if (p.addons.isEmpty || !mounted) return;
    final picked=<String,int>{};
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx)=>StatefulBuilder(builder:(ctx,setSheet)=>SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.stretch,children:[
            const Text('تبغى تضيف شيء مع طلبك؟',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900)),
            const SizedBox(height:12),
            ...p.addons.map((r){
              final a=Store.instance.products.where((x)=>x.id==r.productId&&x.enabled&&!isSoldOut(x)).firstOrNull;
              if(a==null)return const SizedBox.shrink();
              final q=picked[a.id]??0;
              return ListTile(
                title:Text(a.nameAr,style:const TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
                subtitle:Text('+ ${a.price.toStringAsFixed(0)} ريال'),
                trailing:Row(mainAxisSize:MainAxisSize.min,children:[
                  IconButton(onPressed:q>0?()=>setSheet(()=>picked[a.id]=q-1):null,icon:const Icon(Icons.remove_circle_outline)),
                  Text('$q',style:const TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
                  IconButton(onPressed:q<r.maxQty?()=>setSheet(()=>picked[a.id]=q+1):null,icon:const Icon(Icons.add_circle_outline)),
                ]),
              );
            }),
            const SizedBox(height:8),
            FilledButton(onPressed:(){
              setState((){
                for(final e in picked.entries){if(e.value>0)cart[e.key]=(cart[e.key]??0)+e.value;}
              });
              Navigator.pop(ctx);
            },child:const Text('إضافة ومتابعة',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold))),
            TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('لا، شكراً')),
          ]),
        ),
      )),
    );
  }
  Future<void> _cart() async {final done=await Navigator.push(context,MaterialPageRoute(builder:(_)=>CartScreen(cart:cart)));if(done==true&&mounted){Navigator.pop(context,true);}}
}

class MenuScreen extends StatefulWidget {
  final bool loungePrecleared;
  const MenuScreen({super.key,this.loungePrecleared=false});
  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  final Map<String, int> cart = {};
  String category = 'الكل';

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: Store.instance.rev,
      builder: (_, __, ___) {
        final all = Store.instance.products.where((p) => p.enabled).toList();
        final visible = category == 'الكل' ? all : all.where((p) => p.category == category).toList();
        final categories = ['الكل', 'تذاكر', 'إضافات', 'خدمات', 'منتجات'];
        final count = cart.values.fold<int>(0, (a, b) => a + b);
        return Scaffold(
          appBar: AppBar(
            title: const Text('kitty here', style: TextStyle(color: deepPink, fontWeight: FontWeight.w900)),
            centerTitle: true,
            actions: [
              Badge(label: Text('$count'), child: IconButton(icon: const Icon(Icons.shopping_cart_outlined), onPressed: () => _openCart(context))),
              const SizedBox(width: 12),
            ],
          ),
          body: Row(
            children: [
              Container(
                width: 190,
                color: const Color(0xFFFFF3F7),
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    for (final c in categories)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 5),
                        child: ListTile(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          tileColor: category == c ? pink : Colors.transparent,
                          textColor: category == c ? Colors.white : ink,
                          leading: Icon(_categoryIcon(c)),
                          title: Text(c),
                          onTap: () => setState(() => category = c),
                        ),
                      ),
                    const Spacer(),
                    Image.asset('assets/kitty_mascot.jpg', height: 145),
                  ],
                ),
              ),
              Expanded(
                child: GridPaper(
                  child: ListView.separated(
                    padding: const EdgeInsets.all(18),
                    itemCount: visible.length,
                    separatorBuilder: (_,__)=>const SizedBox(height:14),
                    itemBuilder: (_, i) {
                      final p=visible[i]; final soldOut=p.stock==0; final selected=(cart[p.id]??0)>0;
                      return Card(elevation:0,color:selected?const Color(0xFFFFE4EF):Colors.white.withOpacity(.95),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(22),side:BorderSide(color:selected?deepPink:gridPink,width:selected?2:1)),child:InkWell(borderRadius:BorderRadius.circular(22),onTap:soldOut?null:()=>_selectProduct(p),child:Padding(padding:const EdgeInsets.all(18),child:Row(children:[
                        SizedBox(width:125,height:105,child:ProductVisual(product:p)),const SizedBox(width:20),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                          Text(p.nameAr,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:27)),const SizedBox(height:6),Text('${p.price.toStringAsFixed(0)} ريال',style:const TextStyle(color:deepPink,fontSize:25,fontWeight:FontWeight.w900)),
                          if(selected && p.description.trim().isNotEmpty)...[const SizedBox(height:8),Text('الخدمة تتضمن: ${p.description}',style:const TextStyle(fontSize:15,color:Colors.black54,fontWeight:FontWeight.w600))],
                          if(soldOut)const Text('نفد المخزون',style:TextStyle(color:Colors.red,fontWeight:FontWeight.bold))
                        ])),if(selected)Container(
                          padding:const EdgeInsets.symmetric(horizontal:8,vertical:4),
                          decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(18),border:Border.all(color:gridPink)),
                          child:Row(mainAxisSize:MainAxisSize.min,children:[
                            IconButton(tooltip:'حذف',onPressed:(){setState((){cart.remove(p.id);for(final rule in p.addons){cart.remove(rule.productId);}});},icon:const Icon(Icons.delete_outline,color:Colors.redAccent)),
                            IconButton(onPressed:()=>setState((){final q=(cart[p.id]??1)-1;if(q<=0){cart.remove(p.id);for(final rule in p.addons){cart.remove(rule.productId);}}else{cart[p.id]=q;}}),icon:const Icon(Icons.remove_circle_outline,color:deepPink)),
                            Text('${cart[p.id]??0}',style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900)),
                            IconButton(onPressed:()=>setState((){final q=cart[p.id]??0;final max=p.stock>=0?p.stock:99;if(q<max)cart[p.id]=q+1;}),icon:const Icon(Icons.add_circle_outline,color:deepPink)),
                          ]),
                        )
                      ]))));
                    },
                  ),
                ),
              )            ],
          ),
          floatingActionButton: count == 0
              ? null
              : FloatingActionButton.extended(
                  backgroundColor: deepPink,
                  foregroundColor: Colors.white,
                  onPressed: () => _openCart(context),
                  icon: const Icon(Icons.shopping_cart_checkout),
                  label: Text('السلة ($count)'),
                ),
        );
      },
    );
  }

  IconData _categoryIcon(String c) => switch (c) {
        'تذاكر' => Icons.confirmation_num_outlined,
        'إضافات' => Icons.add_circle_outline,
        'خدمات' => Icons.content_cut,
        'منتجات' => Icons.local_mall_outlined,
        _ => Icons.grid_view_rounded,
      };

  Future<void> _selectProduct(Product p) async {
    // المنتج المحدد تتم إدارة كميته من أزرار + / - / حذف بجانبه.
    if ((cart[p.id] ?? 0) > 0) return;
    setState(() => cart[p.id] = 1);
    if(p.addons.isEmpty)return;
    final picked=<String,int>{};
    await showModalBottomSheet(context:context,isScrollControlled:true,builder:(ctx)=>StatefulBuilder(builder:(ctx,setSheet)=>SafeArea(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Text('إضافات ${p.nameAr}',textAlign:TextAlign.center,style:const TextStyle(fontSize:27,fontWeight:FontWeight.w900)),const SizedBox(height:8),const Text('اختر ما يناسبك (اختياري)',textAlign:TextAlign.center),const SizedBox(height:18),
      ...p.addons.map((r){final a=Store.instance.products.where((x)=>x.id==r.productId&&x.enabled).firstOrNull;if(a==null)return const SizedBox.shrink();final q=picked[a.id]??0;return Card(child:ListTile(title:Text(a.nameAr,style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),subtitle:Text('+ ${a.price.toStringAsFixed(0)} ريال • الحد الأقصى ${r.maxQty}'),trailing:Row(mainAxisSize:MainAxisSize.min,children:[IconButton(onPressed:q>0?()=>setSheet(()=>picked[a.id]=q-1):null,icon:const Icon(Icons.remove_circle_outline)),Text('$q',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),IconButton(onPressed:q<r.maxQty?()=>setSheet(()=>picked[a.id]=q+1):null,icon:const Icon(Icons.add_circle_outline))])));}),
      const SizedBox(height:12),
      Row(children:[
        Expanded(child:SizedBox(height:58,child:OutlinedButton(onPressed:()=>Navigator.pop(ctx),child:const Text('تخطي',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold))))),
        const SizedBox(width:12),
        Expanded(child:SizedBox(height:58,child:FilledButton(onPressed:(){setState((){for(final e in picked.entries){if(e.value>0)cart[e.key]=(cart[e.key]??0)+e.value;}});Navigator.pop(ctx);},child:const Text('إضافة للطلب',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)))))
      ])
    ])))));
  }

  void _openCart(BuildContext context) async {
    final done = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => CartScreen(cart: cart,loungePrecleared:widget.loungePrecleared)));
    if (done == true) {
      setState(() => cart.clear());
      if (mounted) Navigator.pop(context);
    }
  }
}

class ProductVisual extends StatelessWidget {
  final Product product;
  const ProductVisual({super.key, required this.product});
  @override
  Widget build(BuildContext context) {
    if (product.imagePath != null && File(product.imagePath!).existsSync()) {
      return ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.file(File(product.imagePath!), fit: BoxFit.cover, width: double.infinity));
    }
    final icon = switch (product.iconName) {
      'shower' => Icons.shower_outlined,
      'timer' => Icons.timer_outlined,
      'infinity' => Icons.all_inclusive,
      'mug' => Icons.local_cafe_outlined,
      'camera' => Icons.camera_alt_outlined,
      'treat' => Icons.pets,
      'person' => Icons.person_outline,
      'scissors' => Icons.content_cut,
      'sticker' => Icons.auto_awesome_outlined,
      _ => Icons.star_outline,
    };
    return Container(
      decoration: BoxDecoration(color: const Color(0xFFFFEEF5), borderRadius: BorderRadius.circular(16)),
      alignment: Alignment.center,
      child: Icon(icon, size: 64, color: deepPink),
    );
  }
}

class CartScreen extends StatefulWidget {
  final Map<String, int> cart;
  final bool loungePrecleared;
  const CartScreen({super.key, required this.cart,this.loungePrecleared=false});
  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  double get total {
    double t = 0;
    for (final e in widget.cart.entries) {
      final p = Store.instance.products.where((x) => x.id == e.key).firstOrNull;
      if (p != null) t += p.price * e.value;
    }
    return t;
  }

  @override
  Widget build(BuildContext context) {
    final items = widget.cart.entries.where((e) => e.value > 0).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('سلة الطلب')),
      body: Column(
        children: [
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.all(20),
              itemCount: items.length,
              separatorBuilder: (_, __) => const Divider(),
              itemBuilder: (_, i) {
                final e = items[i];
                final p = Store.instance.products.where((x) => x.id == e.key).first;
                return ListTile(
                  leading: SizedBox(width: 70, height: 70, child: ProductVisual(product: p)),
                  title: Text(p.nameAr, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('${p.price.toStringAsFixed(0)} ريال'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(onPressed: () => setState(() => widget.cart[p.id] = (widget.cart[p.id]! - 1).clamp(0, 99)), icon: const Icon(Icons.remove_circle_outline)),
                      Text('${widget.cart[p.id]}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      IconButton(onPressed: () => setState(() => widget.cart[p.id] = (widget.cart[p.id]! + 1).clamp(0, 99)), icon: const Icon(Icons.add_circle_outline)),
                    ],
                  ),
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.all(22),
            decoration: const BoxDecoration(color: Colors.white, boxShadow: [BoxShadow(blurRadius: 12, color: Color(0x22000000))]),
            child: Row(
              children: [
                Expanded(child: Text('الإجمالي  ${total.toStringAsFixed(2)} ريال', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900))),
                SizedBox(
                  width: 260,
                  height: 62,
                  child: FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: deepPink),
                    onPressed: items.isEmpty ? null : () {
                      final needsLounge=items.any((e){final p=Store.instance.products.where((x)=>x.id==e.key).firstOrNull;return p?.requiresLounge==true;});
                      Navigator.push(context,MaterialPageRoute(builder:(_)=>(needsLounge&&!widget.loungePrecleared)?RulesScreen(checkoutCart:widget.cart,checkoutTotal:total):CheckoutScreen(cart:widget.cart,total:total)));
                    },
                    child: const Text('إتمام الطلب والدفع', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}

class CheckoutScreen extends StatefulWidget {
  final Map<String, int> cart;
  final double total;
  const CheckoutScreen({super.key, required this.cart, required this.total});
  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  bool busy = false;
  String status = '';
  final phone = TextEditingController();
  Sale? repeatCandidate;

  String normalizedPhone() {
    var v = phone.text.replaceAll(RegExp(r'[^0-9]'), '');
    if (v.startsWith('966')) v = '0${v.substring(3)}';
    return v;
  }

  double get checkoutTotal => widget.cart.entries.fold(0.0,(sum,e){
    final p=Store.instance.products.where((x)=>x.id==e.key).firstOrNull;
    return sum + (p?.price ?? 0) * e.value;
  });

  void findRepeatOrder() {
    final mobile=normalizedPhone();
    if(!RegExp(r'^05[0-9]{8}$').hasMatch(mobile)){if(repeatCandidate!=null)setState(()=>repeatCandidate=null);return;}
    final matches=Store.instance.sales.where((x)=>x.customerPhone==mobile && (x.paymentStatus=='APPROVED'||x.paymentStatus=='MANUAL')).toList()
      ..sort((a,b)=>b.createdAt.compareTo(a.createdAt));
    final next=matches.isEmpty?null:matches.first;
    if(next?.id!=repeatCandidate?.id)setState(()=>repeatCandidate=next);
  }

  void repeatLastOrder() {
    final sale=repeatCandidate;if(sale==null)return;
    setState((){
      widget.cart.clear();
      for(final i in sale.items){
        final p=Store.instance.products.where((x)=>x.id==i.productId&&x.enabled&&!isSoldOut(x)).firstOrNull;
        if(p!=null)widget.cart[p.id]=i.qty;
      }
      status='تم تجهيز آخر طلب لك — راجعه ثم اضغط ادفع';
    });
  }

  Future<void> pay() async {
    final mobile = normalizedPhone();
    if (!RegExp(r'^05[0-9]{8}$').hasMatch(mobile)) {
      setState(() => status = 'فضلاً أدخل رقم جوال سعودي صحيح يبدأ بـ 05');
      return;
    }

    final frozenItems = <SaleItem>[];
    for (final e in widget.cart.entries) {
      if (e.value <= 0) continue;
      final p = Store.instance.products.where((x) => x.id == e.key).firstOrNull;
      if (p == null) {
        setState(() => status = 'تعذر تجهيز الطلب لأن أحد المنتجات تغير. ارجع للسلة وأعد اختيار المنتج.');
        return;
      }
      frozenItems.add(SaleItem(p.id, p.nameAr, e.value, p.price));
    }
    if (frozenItems.isEmpty) {
      setState(() => status = 'السلة فارغة');
      return;
    }
    final frozenTotal = frozenItems.fold<double>(0, (a,b)=>a + b.qty*b.unitPrice);
    final settings = Store.instance.settings;
    final ecrRef = PendingPaymentJournal.createEcrRef(settings);

    // Save the exact order snapshot BEFORE the financial request is sent.
    await PendingPaymentJournal.save(
      ecrRef: ecrRef,
      customerPhone: mobile,
      total: frozenTotal,
      items: frozenItems,
    );

    setState(() {
      busy = true;
      status = 'جاري إرسال ${frozenTotal.toStringAsFixed(2)} ريال إلى جهاز مدى...';
    });

    final result = await NamiOfficialSdk.purchase(settings, frozenTotal, ecrRef: ecrRef);

    if (result['ok'] == true) {
      await completeSale(
        paymentRef: ecrRef,
        frozenItems: frozenItems,
        frozenTotal: frozenTotal,
        frozenPhone: mobile,
      );
      return;
    }

    if (result['declined'] == true || result['stage'] == 'DECLINED') {
      await PendingPaymentJournal.clear();
      if (!mounted) return;
      setState(() {
        busy = false;
        status = 'تم رفض العملية من جهاز مدى. يمكنك المحاولة من جديد.';
      });
      return;
    }

    final safeRetryStages = {'VALIDATION','WAKE_RETRY','REGISTER','SESSION'};
    if (safeRetryStages.contains('${result['stage']}')) {
      await PendingPaymentJournal.clear();
      if (!mounted) return;
      setState(() {
        busy = false;
        status = 'تعذر تجهيز جهاز مدى قبل إرسال عملية الدفع: ${result['message'] ?? ''}';
      });
      return;
    }

    // Anything else is UNKNOWN/PENDING. Never allow a second debit.
    if (mounted) {
      setState(() {
        busy = true;
        status = '⏳ بانتظار النتيجة النهائية من جهاز مدى...\n'
                 'لا تعيد الدفع ولا تغلق الصفحة.\n'
                 'المرجع: $ecrRef';
      });
    }

    int attempt = 0;
    while (mounted && busy) {
      attempt++;
      await Future.delayed(Duration(seconds: attempt <= 3 ? 5 : 3));
      final check = await NamiOfficialSdk.checkStatus(settings, ecrRef);

      if (check['ok'] == true) {
        await completeSale(
          paymentRef: ecrRef,
          frozenItems: frozenItems,
          frozenTotal: frozenTotal,
          frozenPhone: mobile,
        );
        return;
      }

      if (check['declined'] == true || check['stage'] == 'DECLINED') {
        await PendingPaymentJournal.clear();
        if (!mounted) return;
        setState(() {
          busy = false;
          status = 'تم رفض العملية من جهاز مدى. يمكنك المحاولة من جديد.';
        });
        return;
      }

      if (mounted) {
        setState(() {
          final terminalBusy = check['stage'] == 'TERMINAL_BUSY';
          status = '${terminalBusy ? "⏳ جهاز مدى ما زال مشغولًا بإكمال العملية..." : "⏳ لم يصل الرد النهائي بعد..."}\n'
                   'النظام يتحقق من نفس العملية تلقائيًا — لا تعيد الدفع.\n'
                   'المرجع: $ecrRef';
        });
      }
    }
  }

  Future<void> completeSale({
    required String paymentRef,
    required List<SaleItem> frozenItems,
    required double frozenTotal,
    required String frozenPhone,
  }) async {
    final existing = Store.instance.sales.where((x) => x.paymentRef == paymentRef).firstOrNull;
    if (existing != null) {
      await PendingPaymentJournal.clear();
      if (!mounted) return;
      setState(() { busy = false; status = 'تم تسجيل عملية الدفع مسبقًا.'; });
      await Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => SuccessScreen(sale: existing)));
      return;
    }

    final sale = Sale(
      id: nextSaleId(),
      createdAt: DateTime.now(),
      items: frozenItems.map((x)=>SaleItem(x.productId,x.name,x.qty,x.unitPrice)).toList(),
      total: frozenTotal,
      paymentStatus: 'APPROVED',
      paymentRef: paymentRef,
      paymentMethod: 'mada',
      source: 'kiosk',
      customerPhone: frozenPhone,
    );

    // Critical ordering: persist locally BEFORE printing/cloud work.
    await Store.instance.addSale(sale);

    bool printed = false;
    for (int i=0; i<3 && !printed; i++) {
      printed = await UsbPrinter.printReceipt(
        ReceiptBuilder.build(sale),
        logoPath: Store.instance.settings.receiptLogoPath,
      );
      if (!printed) await Future.delayed(const Duration(seconds: 1));
    }
    sale.printed = printed;
    await Store.instance.save();
    await PendingPaymentJournal.clear();

    if (!mounted) return;
    setState(() {
      busy = false;
      status = printed ? 'تم الدفع وتسجيل الفاتورة والطباعة بنجاح' : 'تم الدفع وتسجيل الفاتورة. تعذرت الطباعة ويمكن إعادة طباعتها من المبيعات.';
    });
    await Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => SuccessScreen(sale: sale)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تأكيد الدفع')),
      body: GridPaper(
        child: Center(
          child: SizedBox(
            width: 620,
            child: Card(
              elevation: 0,
              color: Colors.white.withOpacity(.95),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28), side: BorderSide(color: gridPink)),
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Image.asset('assets/kitty_mascot.jpg', height: 180),
                    Text('${checkoutTotal.toStringAsFixed(2)} ريال', style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w900, color: deepPink)),
                    const SizedBox(height: 8),
                    const Text('اضغط ادفع لإرسال المبلغ إلى جهاز مدى', style: TextStyle(fontSize: 20)),
                    const SizedBox(height: 22),
                    TextField(
                      controller: phone,
                      onChanged: (_)=>findRepeatOrder(),
                      enabled: !busy,
                      keyboardType: TextInputType.phone,
                      maxLength: 10,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                      decoration: const InputDecoration(
                        labelText: 'رقم الجوال (إجباري قبل الدفع)',
                        hintText: '05XXXXXXXX',
                        prefixIcon: Icon(Icons.phone_iphone),
                        border: OutlineInputBorder(),
                        counterText: '',
                      ),
                    ),
                    if(repeatCandidate!=null && !busy) Padding(
                      padding: const EdgeInsets.only(bottom:12),
                      child: SizedBox(width:double.infinity,child:OutlinedButton.icon(
                        onPressed: repeatLastOrder,
                        icon: const Icon(Icons.replay),
                        label: const Text('🔁 إعادة آخر طلب',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
                      )),
                    ),
                    const SizedBox(height: 12),
                    if (busy) const CircularProgressIndicator(),
                    if (status.isNotEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(status, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold))),
                    SizedBox(
                      width: double.infinity,
                      height: 62,
                      child: FilledButton.icon(
                        onPressed: busy ? null : pay,
                        icon: const Icon(Icons.credit_card),
                        label: Text(Store.instance.settings.demoPayment ? 'ادفع - وضع تجريبي' : 'ادفع الآن', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class SuccessScreen extends StatefulWidget {
  final Sale sale;
  const SuccessScreen({super.key, required this.sale});
  @override
  State<SuccessScreen> createState() => _SuccessScreenState();
}

class _SuccessScreenState extends State<SuccessScreen> {
  int left = 30;
  Timer? timer;
  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (left <= 1) {
        t.cancel();
        Navigator.popUntil(context, (r) => r.isFirst);
      } else {
        setState(() => left--);
      }
    });
  }
  @override
  void dispose() { timer?.cancel(); super.dispose(); }

  Widget rule(IconData icon, String title, String body) => Card(
    child: ListTile(leading: Icon(icon, color: deepPink, size: 34), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)), subtitle: Text(body, style: const TextStyle(fontSize: 15))),
  );

  @override
  Widget build(BuildContext context) {
    final qr = Store.instance.settings.loyaltyQrPath;
    return Scaffold(
      body: SafeArea(child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(children: [
          Row(children: [
            const Icon(Icons.check_circle, color: deepPink, size: 52),
            const SizedBox(width: 12),
            const Expanded(child: Text('تم الدفع بنجاح — قبل الدخول اقرأ التعليمات', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900, color: deepPink))),
            Text('$left ثانية', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          ]),
          const SizedBox(height: 12),
          Expanded(child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Expanded(flex: 3, child: ListView(children: [
              rule(Icons.person, 'التذكرة لشخص واحد فقط', 'لا يمكن تبديل التذكرة بين الأشخاص.'),
              rule(Icons.volume_off, 'الهدوء مهم', 'ممنوع الصراخ أو إخافة القطط أو رفع الصوت. وفي حال إلحاق الضرر بالقطط قد تُلغى التذكرة.'),
              rule(Icons.child_care, 'الأطفال', 'الطفل الصغير يجب أن يدخل مع أحد الوالدين أو مرافق. المرافق لا يمكن تبديله إلا برسوم 10 ريال.'),
              rule(Icons.pets, 'التعامل مع القطط', 'لا تشد القطط ولا تلمس القطة أثناء نومها، ولا تقرّب وجهك منها. عاملها بلطف واحترام.'),
              rule(Icons.no_photography, 'التصوير', 'لا تستخدم الفلاش عند التصوير.'),
              rule(Icons.health_and_safety, 'سلامة طفلك أولويتنا', 'إذا كان طفلك يخاف أو لديه حساسية، نفضّل التأكد قبل الدخول. يرجى غسل اليدين قبل الدخول وبعد الخروج.'),
              rule(Icons.info_outline, 'التذاكر', 'بعد شراء التذكرة لا يمكن استرجاعها.'),
            ])),
            const SizedBox(width: 18),
            Expanded(flex: 2, child: Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Text('نقاط ومكافآت 🎁', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900, color: deepPink)),
              const SizedBox(height: 8),
              const Text('امسح الرمز وسجّل الآن لتحصل على مكافآتك', textAlign: TextAlign.center, style: TextStyle(fontSize: 17)),
              const SizedBox(height: 18),
              Expanded(child: qr.startsWith('assets/') ? Image.asset(qr, fit: BoxFit.contain) : Image.file(File(qr), fit: BoxFit.contain)),
              const SizedBox(height: 12),
              const Text('شكراً لتفهمكم، ونتمنى لكم زيارة ممتعة 🤍🐾', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold)),
            ])))),
          ])),
        ]),
      )),
    );
  }
}

class NamiOfficialSdk {
  static const MethodChannel _channel = MethodChannel('kittyhere/nami');

  static Future<void> keepAlive(AppSettings s) async {
    try{await _channel.invokeMethod('keepAlive',{'ip':s.namiIp,'port':s.namiPort});}catch(_){}
  }

  static Future<Map<String, dynamic>> purchase(AppSettings s, double amount, {String? ecrRef}) async {
    try {
      final raw = await _channel.invokeMapMethod<String, dynamic>('purchase', {
        'ip': s.namiIp,
        'port': s.namiPort,
        'terminalId': s.terminalId,
        'crn': s.crn,
        'amountMinor': (amount * 100).round(),
        'ecrRef': ecrRef,
      });
      return Map<String, dynamic>.from(raw ?? const {'ok': false, 'stage': 'SDK', 'message': 'Empty SDK response'});
    } on PlatformException catch (e) {
      return {'ok': false, 'stage': 'SDK', 'message': '${e.code}: ${e.message ?? ''}'};
    } catch (e) {
      return {'ok': false, 'stage': 'SDK', 'message': '$e'};
    }
  }

  static Future<Map<String, dynamic>> checkStatus(AppSettings s, String ecrRef) async {
    try {
      final raw = await _channel.invokeMapMethod<String, dynamic>('checkStatus', {
        'ip': s.namiIp,
        'port': s.namiPort,
        'terminalId': s.terminalId,
        'crn': s.crn,
        'ecrRef': ecrRef,
      });
      return Map<String,dynamic>.from(raw ?? const {'ok':false,'pending':true,'stage':'PENDING'});
    } catch (e) {
      return {'ok':false,'pending':true,'stage':'PENDING','message':'$e','ecrRef':ecrRef};
    }
  }

  static Future<Map<String, dynamic>> reconciliation(AppSettings s) async {
    try {
      final raw = await _channel.invokeMapMethod<String, dynamic>('reconciliation', {
        'ip': s.namiIp, 'port': s.namiPort, 'terminalId': s.terminalId, 'crn': s.crn,
      });
      return Map<String, dynamic>.from(raw ?? const {'ok': false, 'stage': 'SDK', 'message': 'Empty response'});
    } catch (e) { return {'ok': false, 'stage': 'SDK', 'message': '$e'}; }
  }
}

class NamiService {
  final AppSettings s;
  NamiService(this.s);

  Future<bool> testConnection() async {
    try {
      final socket = await Socket.connect(s.namiIp, s.namiPort, timeout: const Duration(seconds: 4));
      socket.destroy();
      return true;
    } catch (_) {
      return false;
    }
  }

  String nextEcrRef() {
    final n = (DateTime.now().millisecondsSinceEpoch ~/ 1000) % 1000000;
    return n.toString().padLeft(6, '0');
  }

  String signature(String ecrRef) => sha256.convert(utf8.encode('$ecrRef${s.terminalId}')).toString();

  String purchasePayload(double amount) {
    final now = DateTime.now();
    String two(int n) => n.toString().padLeft(2, '0');
    final stamp = '${two(now.day)}${two(now.month)}${two(now.year % 100)}${two(now.hour)}${two(now.minute)}${two(now.second)}';
    final minor = (amount * 100).round();
    final ref = nextEcrRef();
    return '$stamp;$minor;0;${s.terminalId}$ref!';
  }
}


class RawEcrResult {
  final bool ok;
  final String message;
  final List<int> response;
  RawEcrResult(this.ok, this.message, this.response);

  String get responseHex => response.map((b) => b.toRadixString(16).padLeft(2, '0')).join(' ');
  String get responseAscii {
    try {
      return latin1.decode(response, allowInvalid: true);
    } catch (_) {
      return '';
    }
  }
}

/// Experimental adapter based on:
/// - Nami's documented request bodies / transaction type codes
/// - the public Pine Labs wired socket packet envelope (0x1000 / 0x0997 / length / 0xFF)
/// This is intentionally isolated behind an explicit test toggle.

class ExperimentalEcrPage extends StatefulWidget {
  const ExperimentalEcrPage({super.key});

  @override
  State<ExperimentalEcrPage> createState() => _ExperimentalEcrPageState();
}

class _ExperimentalEcrPageState extends State<ExperimentalEcrPage> {
  bool busy = false;
  String output = 'ابدأ بـ REGISTER فقط. إذا رد الجهاز بدون Busy، جرّب 1 ريال.';

  Future<void> runRegister() async {
    setState(() { busy = true; output = 'جاري REGISTER على نفس بروتوكول الاختبار الذي رد عليه الجهاز سابقاً...'; });
    final r = await DirectNamiTcp(Store.instance.settings).registerOnly();
    if (!mounted) return;
    setState(() {
      busy = false;
      output = '${r['message']}\n\nHEX:\n${r['rawHex'] ?? ''}';
    });
  }


  Future<void> runDiscoverFraming() async {
    setState(() { busy = true; output = 'جاري اكتشاف framing باستخدام REGISTER فقط — بدون أي مبلغ...'; });
    final r = await DirectNamiTcp(Store.instance.settings).discoverFraming();
    if (!mounted) return;
    setState(() {
      busy = false;
      output = 'FRAMING: ${r['frame'] ?? 'غير مكتشف'}\n'
          'PAYLOAD: ${r['payload'] ?? ''}\n'
          'MESSAGE: ${r['message'] ?? ''}\n\n'
          'ASCII:\n${r['rawAscii'] ?? ''}\n\n'
          'HEX:\n${r['rawHex'] ?? ''}';
    });
  }

  Future<void> runDiscoverCrn() async {
    setState(() { busy = true; output = 'جاري استخراج CRN من ردود REGISTER فقط — بدون brute force وبدون مبلغ...'; });
    final r = await DirectNamiTcp(Store.instance.settings).discoverCrn();
    if (!mounted) return;
    final found = (r['crn'] ?? '').toString();
    if (found.isNotEmpty) {
      final s = Store.instance.settings;
      s.crn = found;
      await Store.instance.save();
    }
    if (!mounted) return;
    setState(() {
      busy = false;
      output = 'CRN: ${found.isEmpty ? 'لم يظهر في رد الجهاز' : found}\n'
          'FRAMING: ${r['frame'] ?? ''}\n'
          'MESSAGE: ${r['message'] ?? ''}\n\n'
          'ASCII:\n${r['rawAscii'] ?? ''}\n\n'
          'HEX:\n${r['rawHex'] ?? ''}';
    });
  }

  Future<void> runOneRiyal() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('اختبار 1 ريال'),
        content: const Text('هذا الزر قد يرسل عملية شراء فعلية بقيمة 1.00 ريال إلى جهاز مدى إذا تقبّل الجهاز البروتوكول التجريبي.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('ابدأ اختبار 1 ريال')),
        ],
      ),
    );
    if (ok != true) return;

    setState(() { busy = true; output = 'جاري REGISTER → SESSION → PURCHASE 1 SAR على اتصال واحد...'; });
    final r = await DirectNamiTcp(Store.instance.settings).sendPurchase(1.0);
    if (!mounted) return;
    setState(() {
      busy = false;
      output = 'STAGE: ${r['stage'] ?? ''}\n'
          'AMOUNT MINOR: ${r['amountMinor'] ?? 100} (100 = 1.00 SAR)\n'
          'CRN: ${r['crn'] ?? Store.instance.settings.crn}\n'
          'PURCHASE DATA: ${r['purchaseData'] ?? ''}\n'
          'REGISTER: ${r['registerMessage'] ?? ''}\n'
          'SESSION: ${r['sessionMessage'] ?? ''}\n'
          'MESSAGE: ${r['message'] ?? ''}\n\n'
          'HEX:\n${r['rawHex'] ?? ''}';
    });
  }


  Future<void> runFlutterWireProbe() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('اختبار صيغة Flutter الرسمية - 1 ريال'),
        content: const Text(
          'اختبار تشخيصي فقط. يستخدم صيغة الطلب الموثقة في Nami Flutter '
          'ويحاول تمريرها عبر نفس TCP framing الذي ثبت أن جهازك يرد عليه. '
          'قد يفتح عملية دفع فعلية بقيمة 1.00 ريال.'
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('ابدأ'),
          ),
        ],
      ),
    );
    if (ok != true) return;

    setState(() {
      busy = true;
      output = 'جاري اختبار صيغة Nami Flutter: txnType 6 + HEX request + signature...';
    });

    final r = await DirectNamiTcp(Store.instance.settings)
        .sendPurchaseFlutterWireProbe(1.0);

    if (!mounted) return;
    setState(() {
      busy = false;
      output = 'STAGE: ${r['stage'] ?? ''}\n'
          'CRN: ${r['crn'] ?? ''}\n'
          'ECR REF: ${r['ecrRef'] ?? ''}\n'
          'REQUEST: ${r['reqData'] ?? ''}\n'
          'HEX REQUEST: ${r['hexReqData'] ?? ''}\n'
          'WIRE CSV: ${r['wireCsv'] ?? ''}\n'
          'MESSAGE: ${r['message'] ?? ''}\n\n'
          'RAW HEX:\n${r['rawHex'] ?? ''}';
    });
  }


  Future<void> runV20DirectType6() async {
    final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(
      title:const Text('V20 — Type 6 مباشر'),
      content:Text('بيرسل طلب دفع واحد فقط بقيمة 1.00 ريال إلى ${Store.instance.settings.namiIp}:${Store.instance.settings.namiPort}. ما راح يرسل REGISTER أو SESSION، وما راح يغيّر Terminal ID.'),
      actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('إلغاء')),
      FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('إرسال 1 ريال'))],));
    if(ok!=true)return;
    setState((){busy=true;output='V20: إرسال txnType 6 مباشرة...';});
    final r=await DirectNamiTcp(Store.instance.settings).sendDirectType6Traced(1.0);
    if(!mounted)return;
    setState((){busy=false;output='V20 DIRECT TYPE 6\n'
      'STAGE: ${r['stage'] ?? ''}\n'
      'MESSAGE: ${r['message'] ?? ''}\n'
      'IP: ${r['ip'] ?? Store.instance.settings.namiIp}:${r['port'] ?? Store.instance.settings.namiPort}\n'
      'TERMINAL ID: ${r['terminalId'] ?? Store.instance.settings.terminalId}\n'
      'CRN: ${r['crn'] ?? Store.instance.settings.crn}\n'
      'AMOUNT MINOR: ${r['amountMinor'] ?? 100}\n'
      'REF6: ${r['ref6'] ?? ''}\nECR REF: ${r['ecrRef'] ?? ''}\n\n'
      'REQ DATA:\n${r['reqData'] ?? ''}\n\nHEX REQ DATA:\n${r['hexReqData'] ?? ''}\n\n'
      'WIRE CSV:\n${r['wireCsv'] ?? ''}\n\nTX HEX:\n${r['txHex'] ?? ''}\n\n'
      'RX ASCII:\n${r['rxAscii'] ?? ''}\n\nRX HEX:\n${r['rxHex'] ?? ''}\n\nRX CHUNKS:\n${r['rxChunks'] ?? ''}';});
  }

  Future<void> runNetExactOneRiyal() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('V19 — اختبار 1 ريال'),
        content: const Text(
          'هذه النسخة لا تغيّر Terminal ID. '
          'تستخدم صيغة Nami .NET المنشورة حرفياً داخل REGISTER / SESSION / PURCHASE. '
          'قد تبدأ عملية دفع فعلية بقيمة 1.00 ريال.'
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('ابدأ'),
          ),
        ],
      ),
    );
    if (ok != true) return;

    setState(() {
      busy = true;
      output = 'V19: REGISTER → SESSION → PURCHASE بصيغة Nami .NET الدقيقة...';
    });

    final r = await DirectNamiTcp(Store.instance.settings)
        .sendPurchaseNetExact(1.0);

    if (!mounted) return;
    setState(() {
      busy = false;
      output = 'V19 NET EXACT\n'
          'STAGE: ${r['stage'] ?? ''}\n'
          'MESSAGE: ${r['message'] ?? ''}\n'
          'TERMINAL ID: ${r['terminalId'] ?? Store.instance.settings.terminalId}\n'
          'CONFIRMED CRN: ${r['confirmedCrn'] ?? Store.instance.settings.crn}\n'
          'AMOUNT MINOR: ${r['amountMinor'] ?? 100}\n'
          'REF6: ${r['ref6'] ?? ''}\n\n'
          'REGISTER DATA: ${r['registerData'] ?? ''}\n'
          'REGISTER RESPONSE: ${r['registerMessage'] ?? ''}\n\n'
          'SESSION DATA: ${r['sessionData'] ?? ''}\n'
          'SESSION RESPONSE: ${r['sessionMessage'] ?? ''}\n\n'
          'PURCHASE DATA: ${r['purchaseData'] ?? ''}\n'
          'SIGNATURE: ${r['signature'] ?? ''}\n\n'
          'RAW HEX:\n${r['rawHex'] ?? ''}';
    });
  }

  Future<void> runOfficialSdkOneRiyal() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Nami SDK الرسمي — 1 ريال'),
        content: const Text('سيتم استخدام مكتبة Nami Android الرسمية SkyBandSDK مباشرة لإرسال REGISTER ثم SESSION ثم PURCHASE بقيمة 1.00 ريال.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('إرسال 1 ريال')),
        ],
      ),
    );
    if (ok != true) return;
    setState(() { busy = true; output = 'جاري الاتصال عبر SkyBandSDK الرسمي...'; });
    final r = await NamiOfficialSdk.purchase(Store.instance.settings, 1.0);
    if (!mounted) return;
    setState(() {
      busy = false;
      output = 'NAMI OFFICIAL SDK\n'
          'STAGE: ${r['stage'] ?? ''}\n'
          'MESSAGE: ${r['message'] ?? ''}\n'
          'REGISTER: ${r['registerResponse'] ?? ''}\n'
          'SESSION: ${r['sessionResponse'] ?? ''}\n'
          'PURCHASE: ${r['purchaseResponse'] ?? ''}\n'
          'ECR REF: ${r['ecrRef'] ?? ''}\n'
          'REQUEST: ${r['requestData'] ?? ''}';
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = Store.instance.settings;
    return Scaffold(
      appBar: AppBar(title: const Text('Nami ECR - اختبار تجريبي')),
      body: ListView(
        padding: const EdgeInsets.all(22),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.lan, color: deepPink),
              title: Text('${s.namiIp}:${s.namiPort}'),
              subtitle: Text('Terminal ID: ${s.terminalId}'),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 68,
            child: FilledButton.icon(
              onPressed: busy ? null : runOfficialSdkOneRiyal,
              icon: const Icon(Icons.payment),
              label: const Text('Nami SDK الرسمي — إرسال 1 ريال'),
            ),
          ),
          if (busy) const Padding(padding: EdgeInsets.all(18), child: LinearProgressIndicator()),
          const SizedBox(height: 18),
          SelectableText(output, style: const TextStyle(fontFamily: 'monospace')),
        ],
      ),
    );
  }
}



class DirectNamiTcp {
  final AppSettings s;
  DirectNamiTcp(this.s);

  String _stamp() {
    final d = DateTime.now();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(d.day)}${two(d.month)}${two(d.year % 100)}${two(d.hour)}${two(d.minute)}${two(d.second)}';
  }

  String _ref6() {
    final n = (DateTime.now().millisecondsSinceEpoch ~/ 1000) % 1000000;
    return n.toString().padLeft(6, '0');
  }

  String _signature(String ref6) =>
      sha256.convert(utf8.encode('$ref6${s.terminalId}')).toString();

  List<int> _frame(String csv) {
    final data = latin1.encode(csv);
    final len = data.length;
    return <int>[0x10,0x00,0x09,0x97,(len>>8)&0xff,len&0xff,...data,0xff];
  }


  List<int> _wrapProbe(String kind, String payload) {
    final data = latin1.encode(payload);
    switch (kind) {
      case 'nami_current':
        return _frame(payload);
      case 'nami_current_eot':
        final len = data.length;
        return <int>[0x10,0x00,0x09,0x97,(len>>8)&0xff,len&0xff,...data,0x04];
      case 'raw':
        return data;
      case 'lf':
        return <int>[...data,0x0a];
      case 'crlf':
        return <int>[...data,0x0d,0x0a];
      case 'nul':
        return <int>[...data,0x00];
      case 'stx_etx':
        return <int>[0x02,...data,0x03];
      case 'stx_etx_lrc':
        final body = <int>[...data,0x03];
        var lrc = 0;
        for (final b in body) { lrc ^= b; }
        return <int>[0x02,...body,lrc & 0xff];
      case 'len2_be':
        return <int>[(data.length>>8)&0xff,data.length&0xff,...data];
      case 'len2_le':
        return <int>[data.length&0xff,(data.length>>8)&0xff,...data];
      case 'len4_ascii':
        final h = data.length.toString().padLeft(4,'0');
        return <int>[...latin1.encode(h),...data];
      default:
        return data;
    }
  }

  String _rawAscii(List<int> raw) {
    try { return latin1.decode(raw, allowInvalid:true); }
    catch (_) { return ''; }
  }

  String _rawHex(List<int> raw) =>
      raw.map((b)=>b.toRadixString(16).padLeft(2,'0')).join(' ');

  Future<List<int>> _probeExchange(List<int> tx,
      {Duration timeout = const Duration(seconds: 3)}) async {
    Socket? socket;
    StreamSubscription<List<int>>? sub;
    Timer? quietTimer;
    Timer? hardTimer;
    final bytes = <int>[];
    final c = Completer<List<int>>();
    try {
      socket = await Socket.connect(s.namiIp, s.namiPort,
          timeout: const Duration(seconds: 4));
      void finish() {
        if (!c.isCompleted) c.complete(List<int>.from(bytes));
      }
      sub = socket.listen((data) {
        bytes.addAll(data);
        quietTimer?.cancel();
        quietTimer = Timer(const Duration(milliseconds: 500), finish);
      }, onError: (_) => finish(), onDone: finish);
      socket.add(tx);
      await socket.flush();
      hardTimer = Timer(timeout, finish);
      return await c.future;
    } finally {
      quietTimer?.cancel();
      hardTimer?.cancel();
      try { await sub?.cancel(); } catch (_) {}
      try { socket?.destroy(); } catch (_) {}
    }
  }

  List<String> _registerProbePayloads() => <String>[
    '17,${_stamp()};${s.terminalId}!',
    'REGISTER',
    'REGISTER|${s.terminalId}',
    'REGISTER,${s.terminalId}',
    'REGISTER:${s.terminalId}',
  ];

  List<String> _frameKinds() => const <String>[
    'nami_current','nami_current_eot','raw','lf','crlf','nul',
    'stx_etx','stx_etx_lrc','len2_be','len2_le','len4_ascii'
  ];

  Set<String> _extractCrnCandidates(List<int> raw) {
    final out = <String>{};
    final text = _rawAscii(raw);
    final re = RegExp(r'(?<!\d)\d{8}(?!\d)');
    for (final m in re.allMatches(text)) {
      final v = m.group(0)!;
      if (v != s.terminalId) out.add(v);
    }
    return out;
  }

  Future<Map<String,dynamic>> discoverFraming() async {
    final attempts = <String>[];
    for (final payload in _registerProbePayloads()) {
      for (final kind in _frameKinds()) {
        try {
          final tx = _wrapProbe(kind, payload);
          final rx = await _probeExchange(tx);
          attempts.add('$kind / $payload => ${rx.length} bytes');
          if (rx.isNotEmpty) {
            return <String,dynamic>{
              'ok': true,
              'frame': kind,
              'payload': payload,
              'message': _ascii(rx),
              'rawAscii': _rawAscii(rx),
              'rawHex': _rawHex(rx),
              'crnCandidates': _extractCrnCandidates(rx).toList(),
            };
          }
        } catch (e) {
          attempts.add('$kind / $payload => $e');
        }
      }
    }
    return <String,dynamic>{
      'ok': false,
      'frame': '',
      'payload': '',
      'message': 'No response from safe REGISTER probes',
      'rawAscii': attempts.join('\n'),
      'rawHex': '',
    };
  }

  Future<Map<String,dynamic>> discoverCrn() async {
    final first = await discoverFraming();
    final candidates = <String>{};
    final list = first['crnCandidates'];
    if (list is List) {
      for (final x in list) {
        final v = x.toString();
        if (RegExp(r'^\d{8}$').hasMatch(v) && v != s.terminalId) {
          candidates.add(v);
        }
      }
    }
    return <String,dynamic>{
      ...first,
      'crn': candidates.isEmpty ? '' : candidates.first,
      'crnCandidates': candidates.toList(),
    };
  }

  Future<List<int>> _exchange(Socket socket, String csv,
      {Duration timeout = const Duration(seconds: 12)}) async {
    final bytes = <int>[];
    final c = Completer<List<int>>();
    late StreamSubscription<List<int>> sub;
    Timer? timer;

    sub = socket.listen((data) {
      bytes.addAll(data);
      if ((data.contains(0xff) || data.contains(0x04)) && !c.isCompleted) {
        c.complete(List<int>.from(bytes));
      }
    }, onError: (e) {
      if (!c.isCompleted) c.completeError(e);
    }, onDone: () {
      if (!c.isCompleted) c.complete(List<int>.from(bytes));
    });

    socket.add(_frame(csv));
    await socket.flush();

    timer = Timer(timeout, () {
      if (!c.isCompleted) c.complete(List<int>.from(bytes));
    });

    final result = await c.future;
    timer?.cancel();
    await sub.cancel();
    return result;
  }

  String _ascii(List<int> raw) {
    if (raw.isEmpty) return '';
    var body = List<int>.from(raw);
    if (body.length >= 7 && body[0] == 0x10 && body[1] == 0x00) {
      body = body.sublist(6);
    }
    while (body.isNotEmpty && (body.last == 0xff || body.last == 0x04)) {
      body.removeLast();
    }
    try { return latin1.decode(body, allowInvalid: true).trim(); }
    catch (_) { return ''; }
  }

  bool _busy(String m) {
    final x = m.toLowerCase();
    return x.contains('busy') || x.contains('try later');
  }

  bool _approved(String m) {
    final u = m.toUpperCase();
    return u.contains('APPROVED') || u.startsWith('00') || u.contains(',00,') || u.contains('|00|');
  }

  Future<List<int>> _retry(Socket socket, String csv,
      {int retries = 3, Duration timeout = const Duration(seconds: 12)}) async {
    List<int> last = const [];
    for (int i=0; i<retries; i++) {
      last = await _exchange(socket, csv, timeout: timeout);
      if (!_busy(_ascii(last))) return last;
      await Future.delayed(Duration(milliseconds: 1800 + i*700));
    }
    return last;
  }

  Future<Map<String,dynamic>> registerOnly() async {
    Socket? socket;
    try {
      socket = await Socket.connect(s.namiIp, s.namiPort, timeout: const Duration(seconds: 5));
      final raw = await _exchange(socket, '17,${_stamp()};${s.terminalId}!');
      final msg = _ascii(raw);
      return {
        'ok': raw.isNotEmpty && !_busy(msg),
        'stage': 'REGISTER',
        'message': msg.isEmpty ? 'No response' : msg,
        'rawHex': raw.map((b)=>b.toRadixString(16).padLeft(2,'0')).join(' ')
      };
    } catch(e) {
      return {'ok':false,'stage':'REGISTER','message':'$e'};
    } finally {
      try { socket?.destroy(); } catch(_) {}
    }
  }

  Future<Map<String,dynamic>> sendPurchase(double amountSar) async {
    final amountMinor = (amountSar * 100).round();
    final ref6 = _ref6();
    final crn = RegExp(r'^\d{8}$').hasMatch(s.crn.trim()) ? s.crn.trim() : '73154354';
    final ecrRef = '$crn$ref6';
    // Nami documented purchase body: DDMMYYHHMMSS;AmountMinor;0;CRN+Ref6!
    final purchaseData = '${_stamp()};$amountMinor;0;$ecrRef!';
    final sig = _signature(ref6);

    String registerMsg = '';
    String sessionMsg = '';
    List<int> lastRaw = const <int>[];

    // Important: never run two socket readers at once. Each attempt owns exactly
    // one socket and one listener, and a BUSY registration is fully disconnected
    // before retrying. We only advance REGISTER -> SESSION -> PURCHASE after the
    // previous stage has returned a non-BUSY response.
    for (int attempt = 1; attempt <= 3; attempt++) {
      Socket? socket;
      StreamSubscription<List<int>>? sub;
      Completer<List<int>>? pending;
      final rx = <int>[];

      Future<List<int>> sendAndWait(String payload,
          {Duration timeout = const Duration(seconds: 15)}) async {
        rx.clear();
        final c = Completer<List<int>>();
        pending = c;
        socket!.add(_frame(payload));
        await socket!.flush();
        try {
          return await c.future.timeout(timeout,
              onTimeout: () => List<int>.from(rx));
        } finally {
          if (identical(pending, c)) pending = null;
        }
      }

      try {
        socket = await Socket.connect(s.namiIp, s.namiPort,
            timeout: const Duration(seconds: 5));
        sub = socket.listen((data) {
          if (pending == null) return;
          rx.addAll(data);
          if ((data.contains(0x03) || data.contains(0xff) || data.contains(0x04)) &&
              !(pending?.isCompleted ?? true)) {
            pending!.complete(List<int>.from(rx));
          }
        }, onError: (Object e) {
          if (!(pending?.isCompleted ?? true)) pending!.completeError(e);
        }, onDone: () {
          if (!(pending?.isCompleted ?? true)) pending!.complete(List<int>.from(rx));
        });

        // 17 = REGISTER. This terminal may report BUSY while still accepting the next ECR stage.
        lastRaw = await sendAndWait('17,${_stamp()};${s.terminalId}!');
        registerMsg = _ascii(lastRaw);
        // V16 compatibility mode: BUSY is recorded but does not stop the flow.
        // Earlier testing showed this terminal can open the mada payment screen
        // even when REGISTER/SESSION return "Terminal Is Busy".
        if (lastRaw.isEmpty) {
          return <String,dynamic>{'ok':false,'stage':'REGISTER','message':'No REGISTER response','rawHex':''};
        }

        await Future.delayed(const Duration(milliseconds: 500));

        // 18 = SESSION. Again, never advance on BUSY.
        lastRaw = await sendAndWait('18,${_stamp()};${s.terminalId}!');
        sessionMsg = _ascii(lastRaw);
        // Same compatibility behavior for SESSION: continue to PURCHASE on BUSY.
        if (lastRaw.isEmpty) {
          return <String,dynamic>{'ok':false,'stage':'SESSION','message':'No SESSION response','registerMessage':registerMsg,'rawHex':''};
        }

        await Future.delayed(const Duration(milliseconds: 500));

        // 0 = PURCHASE. Signature = SHA256(ref6 + TerminalID).
        // Keep the same proven outer envelope; only one reader is active.
        lastRaw = await sendAndWait('0,$purchaseData,$sig',
            timeout: const Duration(seconds: 90));
        final msg = _ascii(lastRaw);
        return <String,dynamic>{
          'ok': _approved(msg),
          'stage': 'PURCHASE',
          'message': msg.isEmpty ? 'Purchase sent; no final response yet' : msg,
          'amountMinor': amountMinor,
          'purchaseData': purchaseData,
          'ecrRef': ecrRef,
          'crn': crn,
          'registerMessage': registerMsg,
          'sessionMessage': sessionMsg,
          'rawHex': _rawHex(lastRaw),
        };
      } catch (e) {
        if (attempt == 3) {
          return <String,dynamic>{'ok':false,'stage':'TCP','message':'$e','registerMessage':registerMsg,'sessionMessage':sessionMsg};
        }
        await Future.delayed(Duration(seconds: 2 + attempt));
      } finally {
        try { await sub?.cancel(); } catch (_) {}
        try { socket?.destroy(); } catch (_) {}
      }
    }
    return <String,dynamic>{'ok':false,'stage':'TCP','message':'Unexpected end'};
  }


  /// Diagnostic compatibility probe based on Nami's public Flutter documentation:
  /// - CRN is 8 digits
  /// - ECR ref = CRN + six-digit unique number
  /// - request = DDMMYYHHMMSS;amountMinor;print!;ecrRef!;
  /// - request is converted to HEX
  /// - txnType 6 is the documented end-to-end Flutter payment flow
  /// - signature = SHA256(ref6 + TerminalID)
  ///
  /// IMPORTANT: the official ecrlib package owns the real transport envelope.
  /// This method deliberately keeps the already-working outer TCP envelope only
  /// as a diagnostic compatibility test; it is not a replacement for ecrlib.
  Future<Map<String,dynamic>> sendPurchaseFlutterWireProbe(double amountSar) async {
    final crn = s.crn.trim();
    if (!RegExp(r'^\d{8}$').hasMatch(crn)) {
      return <String,dynamic>{
        'ok': false,
        'stage': 'CRN',
        'message': 'CRN must be exactly 8 digits',
        'crn': crn,
      };
    }

    final amountMinor = (amountSar * 100).round();
    final ref6 = _ref6();
    final ecrRef = '$crn$ref6';
    final reqData = '${_stamp()};$amountMinor;0!;$ecrRef!;';
    final hexReqData = latin1
        .encode(reqData)
        .map((b) => b.toRadixString(16).padLeft(2, '0'))
        .join()
        .toUpperCase();
    final sig = _signature(ref6);

    // Nami Flutter docs pass txnType separately to doTransaction().
    // The public raw TCP framing is not documented, so this CSV is only a probe.
    final wireCsv = '6,$hexReqData,$sig';

    Socket? socket;
    try {
      socket = await Socket.connect(
        s.namiIp,
        s.namiPort,
        timeout: const Duration(seconds: 5),
      );
      socket.setOption(SocketOption.tcpNoDelay, true);

      final raw = await _exchange(
        socket,
        wireCsv,
        timeout: const Duration(seconds: 90),
      );
      final msg = _ascii(raw);

      return <String,dynamic>{
        'ok': _approved(msg),
        'stage': 'FLUTTER_WIRE_PROBE',
        'message': msg.isEmpty ? 'No response' : msg,
        'crn': crn,
        'amountMinor': amountMinor,
        'ecrRef': ecrRef,
        'reqData': reqData,
        'hexReqData': hexReqData,
        'wireCsv': wireCsv,
        'rawHex': _rawHex(raw),
      };
    } catch (e) {
      return <String,dynamic>{
        'ok': false,
        'stage': 'TCP',
        'message': '$e',
        'crn': crn,
        'ecrRef': ecrRef,
        'reqData': reqData,
        'hexReqData': hexReqData,
        'wireCsv': wireCsv,
      };
    } finally {
      try { socket?.destroy(); } catch (_) {}
    }
  }


  /// V20 direct Flutter-style transaction probe.
  /// NO manual REGISTER/SESSION. Sends one txnType 6 request only.
  Future<Map<String,dynamic>> sendDirectType6Traced(double amountSar) async {
    final crn = s.crn.trim();
    final terminalId = s.terminalId.trim();
    if (!RegExp(r'^\d{8}$').hasMatch(crn)) {
      return {'ok':false,'stage':'VALIDATION','message':'CRN must be exactly 8 digits'};
    }
    if (!RegExp(r'^\d{8}$').hasMatch(terminalId)) {
      return {'ok':false,'stage':'VALIDATION','message':'Terminal ID must be exactly 8 digits'};
    }
    final amountMinor=(amountSar*100).round();
    final ref6=_ref6();
    final ecrRef='$crn$ref6';
    final reqData='${_stamp()};$amountMinor;0!;$ecrRef!;';
    final hexReqData=latin1.encode(reqData).map((b)=>b.toRadixString(16).padLeft(2,'0')).join().toUpperCase();
    final signature=_signature(ref6);
    final wireCsv='6,$hexReqData,$signature';
    Socket? socket; StreamSubscription<List<int>>? sub; Timer? hardTimer; Timer? quietTimer;
    final all=<int>[]; final chunks=<String>[]; final done=Completer<List<int>>();
    void finish(){ if(!done.isCompleted) done.complete(List<int>.from(all)); }
    try {
      socket=await Socket.connect(s.namiIp,s.namiPort,timeout:const Duration(seconds:5));
      socket.setOption(SocketOption.tcpNoDelay,true);
      sub=socket.listen((data){
        all.addAll(data);
        chunks.add('${DateTime.now().toIso8601String()}  ${data.map((b)=>b.toRadixString(16).padLeft(2,'0')).join(' ')}');
        quietTimer?.cancel(); quietTimer=Timer(const Duration(milliseconds:900),finish);
        if(data.contains(0x03)||data.contains(0xff)||data.contains(0x04)){
          quietTimer?.cancel(); quietTimer=Timer(const Duration(milliseconds:200),finish);
        }
      },onError:(Object e){if(!done.isCompleted)done.completeError(e);},onDone:finish);
      final tx=_frame(wireCsv); socket.add(tx); await socket.flush();
      hardTimer=Timer(const Duration(seconds:90),finish);
      final raw=await done.future; final msg=_ascii(raw);
      return {'ok':_approved(msg),'stage':'TYPE6_DIRECT','message':msg.isEmpty?'No response':msg,
        'ip':s.namiIp,'port':s.namiPort,'terminalId':terminalId,'crn':crn,'amountMinor':amountMinor,
        'ref6':ref6,'ecrRef':ecrRef,'reqData':reqData,'hexReqData':hexReqData,'signature':signature,
        'wireCsv':wireCsv,'txHex':_rawHex(tx),'rxHex':_rawHex(raw),'rxAscii':_rawAscii(raw),'rxChunks':chunks.join('\n')};
    } catch(e) {
      return {'ok':false,'stage':'TCP','message':'$e','ip':s.namiIp,'port':s.namiPort,'terminalId':terminalId,'crn':crn,
        'amountMinor':amountMinor,'reqData':reqData,'hexReqData':hexReqData,'wireCsv':wireCsv,'rxChunks':chunks.join('\n')};
    } finally {
      hardTimer?.cancel(); quietTimer?.cancel(); try{await sub?.cancel();}catch(_){} try{socket?.destroy();}catch(_){}
    }
  }


  /// V19 evidence-based TCP test.
  ///
  /// Source-derived decisions:
  /// - Keep the user's current Terminal ID unchanged.
  /// - terminal.dat confirms CRN 73154354, but the public Nami .NET TCP
  ///   protocol uses TerminalID (not CRN) inside REGISTER/SESSION and
  ///   TerminalID + 6-digit ECR ref inside PURCHASE.
  /// - Amount uses minor units: 1 SAR -> 100.
  ///
  /// The outer socket envelope is retained because it is the only framing
  /// already proven to reach this terminal and receive a Nami response.
  Future<Map<String,dynamic>> sendPurchaseNetExact(double amountSar) async {
    final amountMinor = (amountSar * 100).round();
    final terminalId = s.terminalId.trim(); // DO NOT auto-change.
    if (!RegExp(r'^\d{8}$').hasMatch(terminalId)) {
      return <String,dynamic>{
        'ok': false,
        'stage': 'VALIDATION',
        'message': 'Terminal ID must be exactly 8 digits',
      };
    }

    final ref6 = _ref6();
    final timestampReg = _stamp();
    final registerData = '$timestampReg;$terminalId!';
    final sessionData = '${_stamp()};$terminalId!';
    final purchaseData = '${_stamp()};$amountMinor;0;$terminalId$ref6!';
    final signature = _signature(ref6);

    Socket? socket;
    StreamSubscription<List<int>>? sub;
    Completer<List<int>>? pending;
    final rx = <int>[];

    Future<List<int>> sendAndWait(String csv,
        {Duration timeout = const Duration(seconds: 20)}) async {
      rx.clear();
      final c = Completer<List<int>>();
      pending = c;
      socket!.add(_frame(csv));
      await socket!.flush();
      try {
        return await c.future.timeout(
          timeout,
          onTimeout: () => List<int>.from(rx),
        );
      } finally {
        if (identical(pending, c)) pending = null;
      }
    }

    try {
      socket = await Socket.connect(
        s.namiIp,
        s.namiPort,
        timeout: const Duration(seconds: 5),
      );
      socket.setOption(SocketOption.tcpNoDelay, true);

      sub = socket.listen((data) {
        if (pending == null) return;
        rx.addAll(data);
        if ((data.contains(0x03) ||
                data.contains(0x04) ||
                data.contains(0xff)) &&
            !(pending?.isCompleted ?? true)) {
          pending!.complete(List<int>.from(rx));
        }
      }, onError: (Object e) {
        if (!(pending?.isCompleted ?? true)) pending!.completeError(e);
      }, onDone: () {
        if (!(pending?.isCompleted ?? true)) {
          pending!.complete(List<int>.from(rx));
        }
      });

      // Native SDK takes an empty signature for 17/18.
      // Preserve that empty field on the wire with the trailing comma.
      final regRaw = await sendAndWait('17,$registerData,');
      final regMsg = _ascii(regRaw);

      if (regRaw.isEmpty) {
        return <String,dynamic>{
          'ok': false,
          'stage': 'REGISTER',
          'message': 'No REGISTER response',
          'registerData': registerData,
        };
      }

      // Do not execute a financial request if terminal explicitly rejects
      // registration as Invalid Transaction. BUSY is retained as diagnostic
      // because earlier terminal tests showed it can be transient.
      if (regMsg.toLowerCase().contains('invalid transaction')) {
        return <String,dynamic>{
          'ok': false,
          'stage': 'REGISTER',
          'message': regMsg,
          'registerData': registerData,
          'registerWire': '17,$registerData,',
          'rawHex': _rawHex(regRaw),
        };
      }

      await Future.delayed(const Duration(milliseconds: 700));

      final sesRaw = await sendAndWait('18,$sessionData,');
      final sesMsg = _ascii(sesRaw);
      if (sesRaw.isEmpty) {
        return <String,dynamic>{
          'ok': false,
          'stage': 'SESSION',
          'message': 'No SESSION response',
          'registerMessage': regMsg,
          'sessionData': sessionData,
        };
      }
      if (sesMsg.toLowerCase().contains('invalid transaction')) {
        return <String,dynamic>{
          'ok': false,
          'stage': 'SESSION',
          'message': sesMsg,
          'registerMessage': regMsg,
          'sessionData': sessionData,
          'sessionWire': '18,$sessionData,',
          'rawHex': _rawHex(sesRaw),
        };
      }

      await Future.delayed(const Duration(milliseconds: 700));

      final purRaw = await sendAndWait(
        '0,$purchaseData,$signature',
        timeout: const Duration(seconds: 90),
      );
      final purMsg = _ascii(purRaw);

      return <String,dynamic>{
        'ok': _approved(purMsg),
        'stage': 'PURCHASE',
        'message': purMsg.isEmpty ? 'Purchase sent; no final response yet' : purMsg,
        'terminalId': terminalId,
        'confirmedCrn': s.crn.trim(),
        'amountMinor': amountMinor,
        'ref6': ref6,
        'registerData': registerData,
        'sessionData': sessionData,
        'purchaseData': purchaseData,
        'signature': signature,
        'registerMessage': regMsg,
        'sessionMessage': sesMsg,
        'rawHex': _rawHex(purRaw),
      };
    } catch (e) {
      return <String,dynamic>{
        'ok': false,
        'stage': 'TCP',
        'message': '$e',
      };
    } finally {
      try { await sub?.cancel(); } catch (_) {}
      try { socket?.destroy(); } catch (_) {}
    }
  }

}

class ReceiptBuilder {
  static String build(Sale sale) {
    final cfg = Store.instance.settings;
    final b = StringBuffer();
    // Structured thermal receipt payload. Native renderer turns these rows into
    // the Kitty Here 80mm invoice design while keeping Arabic crisp.
    b.writeln('KH_RECEIPT_V2');
    b.writeln('TITLE|${cfg.receiptTitle.trim().isEmpty ? 'KITTY HERE' : cfg.receiptTitle.trim()}');
    b.writeln('INVOICE|${sale.id}');
    b.writeln('DATE|${sale.createdAt.toString()}');
    b.writeln('PHONE|${sale.customerPhone}');
    for (final i in sale.items) {
      b.writeln('ITEM|${i.name.replaceAll('|', ' ')}|${i.qty}|${i.unitPrice.toStringAsFixed(2)}|${(i.qty * i.unitPrice).toStringAsFixed(2)}');
    }
    b.writeln('TOTAL|${sale.total.toStringAsFixed(2)}');
    b.writeln('PAYMENT|مدى - تمت العملية بنجاح');
    b.writeln('REF|${sale.paymentRef}');
    final footer = cfg.receiptFooter.trim().isEmpty
        ? 'شكراً لزيارتكم ♥|نتمنى لكم وقتاً سعيداً مع قططنا|@kitty_ksa1'
        : cfg.receiptFooter.replaceAll('\n', '|');
    b.writeln('FOOTER|$footer');
    b.writeln('SOCIAL|@kitty_ksa1');
    return b.toString();
  }
}

class UsbPrinter {
  static const channel = MethodChannel('kittyhere/printer');

  static Future<bool> printReceipt(String text, {String logoPath = ''}) async {
    try {
      final r = await channel.invokeMethod<String>('printReceipt', {'text': text, 'logoPath': logoPath});
      return r == 'printed';
    } catch (_) {
      return false;
    }
  }

  static Future<List<Map<String, dynamic>>> devices() async {
    try {
      final r = await channel.invokeMethod<List<dynamic>>('listUsbDevices') ?? [];
      return r.map((e) => Map<String, dynamic>.from(e)).toList();
    } catch (_) {
      return [];
    }
  }
}

class AdminHome extends StatefulWidget {
  const AdminHome({super.key});
  @override
  State<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  int tab = 0;
  @override
  Widget build(BuildContext context) {
    final pages = [const DashboardPage(), const CustomersPage(), const ProductsAdmin(), const SalesPage(), const ManualInvoicePage(), const SettingsPage()];
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة تحكم Kitty Here')),
      body: Row(
        children: [
          NavigationRail(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            labelType: NavigationRailLabelType.all,
            destinations: const [
              NavigationRailDestination(icon: Icon(Icons.dashboard_outlined), label: Text('الرئيسية')),
              NavigationRailDestination(icon: Icon(Icons.people_alt_outlined), label: Text('العملاء')),
              NavigationRailDestination(icon: Icon(Icons.inventory_2_outlined), label: Text('المنتجات')),
              NavigationRailDestination(icon: Icon(Icons.bar_chart), label: Text('المبيعات')),
              NavigationRailDestination(icon: Icon(Icons.receipt_long), label: Text('فاتورة')),
              NavigationRailDestination(icon: Icon(Icons.settings), label: Text('الإعدادات')),
            ],
          ),
          const VerticalDivider(width: 1),
          Expanded(child: pages[tab]),
        ],
      ),
    );
  }
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override State<DashboardPage> createState() => _DashboardPageState();
}
class _DashboardPageState extends State<DashboardPage> {
  bool busy = false;
  String msg = '';

  Future<void> reconcile() async {
    if (busy) return; setState(()=>busy=true);
    final r = await NamiOfficialSdk.reconciliation(Store.instance.settings);
    if (mounted) setState(() { busy=false; msg = r['ok']==true ? 'تمت الموازنة بنجاح' : 'فشلت الموازنة: ${r['message'] ?? ''}'; });
  }

  Future<void> closeShift() async {
    if (busy) return;
    final now=DateTime.now();
    if(Store.instance.settings.shiftStart.isEmpty){
      Store.instance.settings.shiftStart=now.toIso8601String();
      await Store.instance.save();
    }
    final start=DateTime.tryParse(Store.instance.settings.shiftStart) ?? now;
    final sales=Store.instance.sales.where((x)=>(x.paymentStatus=='APPROVED'||x.paymentStatus=='MANUAL')&&!x.createdAt.isBefore(start)&&!x.createdAt.isAfter(now)).toList();
    final total=sales.fold<double>(0,(a,b)=>a+b.total);
    double by(String m)=>sales.where((s)=>s.paymentMethod==m).fold<double>(0,(a,b)=>a+b.total);
    final report='KITTY HERE\nتقرير إقفال المناوبة\nبداية المناوبة: $start\nنهاية المناوبة: $now\n------------------------------\nعدد العمليات المدفوعة: ${sales.length}\nإجمالي المبيعات: ${total.toStringAsFixed(2)} SAR\nمدى / Nami: ${by('mada').toStringAsFixed(2)} SAR\nكاش: ${by('cash').toStringAsFixed(2)} SAR\nتابي: ${by('tabby').toStringAsFixed(2)} SAR\nتمارا: ${by('tamara').toStringAsFixed(2)} SAR\nتحويل بنكي: ${by('bank_transfer').toStringAsFixed(2)} SAR\nأخرى: ${by('other').toStringAsFixed(2)} SAR\n------------------------------\nتم إقفال المناوبة';
    if(!mounted)return;
    final go=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('معاينة الموازنة قبل الإقفال'),content:SingleChildScrollView(child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[Text('عدد العمليات: ${sales.length}',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),Text('الإجمالي: ${total.toStringAsFixed(2)} ريال',style:const TextStyle(fontSize:26,fontWeight:FontWeight.w900,color:deepPink)),const Divider(),Text('مدى / Nami: ${by('mada').toStringAsFixed(2)} ريال'),Text('كاش: ${by('cash').toStringAsFixed(2)} ريال'),Text('تابي: ${by('tabby').toStringAsFixed(2)} ريال'),Text('تمارا: ${by('tamara').toStringAsFixed(2)} ريال'),Text('تحويل بنكي: ${by('bank_transfer').toStringAsFixed(2)} ريال'),Text('أخرى: ${by('other').toStringAsFixed(2)} ريال')])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('رجوع')),FilledButton.icon(onPressed:()=>Navigator.pop(ctx,true),icon:const Icon(Icons.print),label:const Text('إقفال وطباعة'))]));
    if(go!=true)return; setState(()=>busy=true);
    final printed=await UsbPrinter.printReceipt(report);
    bool cloudClosed=false;
    if(printed){
      cloudClosed=await CloudSync.closeShift(start,now);
      if(cloudClosed){Store.instance.settings.shiftStart=now.toIso8601String();await Store.instance.save();}
    }
    if(mounted)setState((){busy=false;msg=!printed?'تعذرت الطباعة - لم يتم إقفال المناوبة':cloudClosed?'تم إقفال المناوبة وتصفيـر فواتير المناوبة الحالية':'تمت الطباعة لكن تعذر إقفال المناوبة سحابياً - حاول الإقفال مرة أخرى';});
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: Store.instance.rev,
      builder: (_, __, ___) {
        final now = DateTime.now();
        final shiftStart = DateTime.tryParse(Store.instance.settings.shiftStart);
        final currentShiftSales = Store.instance.sales.where((sale) =>
          (sale.paymentStatus=='APPROVED'||sale.paymentStatus=='MANUAL') &&
          (shiftStart == null || !sale.createdAt.isBefore(shiftStart))
        ).toList();
        final total = currentShiftSales.fold<double>(0, (a, b) => a + b.total);
        final avg = currentShiftSales.isEmpty ? 0 : total / currentShiftSales.length;
        final counts = <String, int>{};
        for (final sale in currentShiftSales) for (final i in sale.items) counts[i.name] = (counts[i.name] ?? 0) + i.qty;
        String top = '-';
        if (counts.isNotEmpty) top = counts.entries.reduce((a, b) => a.value >= b.value ? a : b).key;
        final lowStock=Store.instance.products.where((p)=>p.enabled&&p.stock>=0&&p.stock<=5).toList();
        final sevenIds=autoPopularProductIds();
        final sevenNames=Store.instance.products.where((p)=>sevenIds.contains(p.id)).map((p)=>p.nameAr).join('، ');
        return Padding(
          padding: const EdgeInsets.all(22),
          child: ListView(
            children: [
              const Text('ملخص اليوم', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              Wrap(spacing: 10, runSpacing: 10, children: [
                FilledButton.icon(onPressed: busy?null:closeShift, icon: const Icon(Icons.receipt_long), label: const Text('معاينة وإقفال المناوبة')),
                OutlinedButton.icon(onPressed: busy?null:reconcile, icon: const Icon(Icons.sync), label: const Text('موازنة Nami')),
              ]),
              if(busy) const Padding(padding: EdgeInsets.symmetric(vertical:8), child: LinearProgressIndicator()),
              if(msg.isNotEmpty) Padding(padding: const EdgeInsets.symmetric(vertical:8), child: Text(msg, style: const TextStyle(fontWeight: FontWeight.bold))),
              const SizedBox(height: 14),
              Wrap(
                spacing: 14,
                runSpacing: 14,
                children: [
                  StatCard('إجمالي المبيعات', '${total.toStringAsFixed(2)} ريال', Icons.payments_outlined),
                  StatCard('عدد الطلبات', '${today.length}', Icons.receipt_long_outlined),
                  StatCard('متوسط الطلب', '${avg.toStringAsFixed(2)} ريال', Icons.analytics_outlined),
                  StatCard('الأكثر مبيعاً بالمناوبة', top, Icons.trending_up),
                  StatCard('🔥 الأعلى خلال 7 أيام', sevenNames.isEmpty?'-':sevenNames, Icons.local_fire_department),
                  StatCard('تنبيه المخزون', lowStock.isEmpty?'المخزون سليم':'${lowStock.length} منتجات منخفضة', Icons.inventory_2_outlined),
                ],
              ),
              const SizedBox(height: 24),
              const Text('آخر الطلبات', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              ...Store.instance.sales.take(8).map((s) => ListTile(
                    leading: const CircleAvatar(backgroundColor: pink, child: Icon(Icons.check, color: Colors.white)),
                    title: Text('طلب #${s.id} - ${s.total.toStringAsFixed(2)} ريال'),
                    subtitle: Text(s.createdAt.toString()),
                    trailing: Text(s.printed ? 'مطبوعة' : 'غير مطبوعة'),
                  ))
            ],
          ),
        );
      },
    );
  }
}

class StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  const StatCard(this.title, this.value, this.icon, {super.key});
  @override
  Widget build(BuildContext context) => SizedBox(
        width: 250,
        child: Card(
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(icon, color: deepPink, size: 34),
              const SizedBox(height: 10),
              Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
              Text(title),
            ]),
          ),
        ),
      );
}

class ProductsAdmin extends StatelessWidget {
  const ProductsAdmin({super.key});
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: Store.instance.rev,
      builder: (_, __, ___) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Row(children: [
              const Expanded(child: Text('إدارة المنتجات والمخزون', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900))),
              FilledButton.icon(onPressed: () => _edit(context, null), icon: const Icon(Icons.add), label: const Text('إضافة منتج')),
            ]),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.separated(
                itemCount: Store.instance.products.length,
                separatorBuilder: (_, __) => const Divider(),
                itemBuilder: (_, i) {
                  final p = Store.instance.products[i];
                  return ListTile(
                    leading: SizedBox(width: 62, height: 62, child: ProductVisual(product: p)),
                    title: Text(p.nameAr, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('${p.category} • ${p.price.toStringAsFixed(2)} ريال • ${p.stock < 0 ? 'غير محدود' : 'المخزون ${p.stock}'}${p.stock >= 0 && p.stock <= 5 ? '  ⚠️ مخزون منخفض' : ''}',style:TextStyle(color:p.stock >= 0 && p.stock <= 5?Colors.red:null,fontWeight:p.stock >= 0 && p.stock <= 5?FontWeight.bold:null)),
                    trailing: Wrap(spacing: 4, children: [
                      IconButton(icon:const Icon(Icons.arrow_upward),onPressed:i==0?null:() async {final q=Store.instance.products.removeAt(i);Store.instance.products.insert(i-1,q);await Store.instance.save();for(int k=0;k<Store.instance.products.length;k++)await CloudSync.pushProduct(Store.instance.products[k],sortOrder:k);}),
                      IconButton(icon:const Icon(Icons.arrow_downward),onPressed:i>=Store.instance.products.length-1?null:() async {final q=Store.instance.products.removeAt(i);Store.instance.products.insert(i+1,q);await Store.instance.save();for(int k=0;k<Store.instance.products.length;k++)await CloudSync.pushProduct(Store.instance.products[k],sortOrder:k);}),
                      Switch(value: p.enabled, onChanged: (v) async { p.enabled = v; await Store.instance.save(); await CloudSync.pushProduct(p,sortOrder:i); }),
                      IconButton(icon: const Icon(Icons.edit), onPressed: () => _edit(context, p)),
                      IconButton(icon: const Icon(Icons.delete_outline, color: Colors.red), onPressed: () async {
                        await CloudSync.deleteProduct(p);
                        Store.instance.products.remove(p);
                        await Store.instance.save();
                      }),
                    ]),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _edit(BuildContext context, Product? old) async {
    final name = TextEditingController(text: old?.nameAr ?? '');
    final en = TextEditingController(text: old?.nameEn ?? '');
    final price = TextEditingController(text: old?.price.toString() ?? '');
    final stock = TextEditingController(text: old == null || old.stock < 0 ? '' : old.stock.toString());
    final description = TextEditingController(text: old?.description ?? '');
    final addonMax = <String,int>{for(final a in (old?.addons ?? const <ProductAddonRule>[])) a.productId:a.maxQty};
    String category = old?.category ?? 'منتجات';
    bool requiresLounge = old?.requiresLounge ?? (category == 'تذاكر');
    bool quickHome = old?.quickHome ?? false;
    bool popularBadge = old?.popularBadge ?? false;
    String? imagePath = old?.imagePath;
    final picker = ImagePicker();

    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text(old == null ? 'إضافة منتج' : 'تعديل المنتج'),
          content: SizedBox(
            width: 520,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم المنتج')),
                  TextField(controller: en, decoration: const InputDecoration(labelText: 'الاسم الإنجليزي')),
                  TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'السعر')),
                  TextField(controller: stock, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'المخزون (اتركه فارغ = غير محدود)')),
                  TextField(controller: description, maxLines: 3, decoration: const InputDecoration(labelText: 'الخدمة تتضمن... (يظهر للعميل بعد اختيار المنتج)')),
                  const SizedBox(height:14),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('🐱 يتطلب دخول صالة القطط',style:TextStyle(fontWeight:FontWeight.w900)),
                    subtitle: const Text('يظهر للعميل شروط وتعليمات دخول الصالة'),
                    value: requiresLounge,
                    onChanged: (v)=>setLocal((){requiresLounge=v;if(v)quickHome=false;}),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('⚡ إظهار في مشروبات ومنتجات فقط',style:TextStyle(fontWeight:FontWeight.w900)),
                    subtitle: Text(requiresLounge?'أوقف خيار دخول الصالة أولاً':'يظهر مباشرة في الطلب السريع بدون تعليمات الصالة'),
                    value: quickHome,
                    onChanged: requiresLounge?null:(v)=>setLocal(()=>quickHome=v),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('🔥 إظهار ضمن الأعلى مبيعاً',style:TextStyle(fontWeight:FontWeight.w900)),
                    subtitle: const Text('يظهر بشارة الأكثر طلباً في واجهة الشراء السريع'),
                    value: popularBadge,
                    onChanged: (v)=>setLocal(()=>popularBadge=v),
                  ),
                  const Divider(height:28),
                  const Align(alignment:Alignment.centerRight,child:Text('الإضافات التي تظهر مع هذا المنتج',style:TextStyle(fontWeight:FontWeight.w900))),
                  ...Store.instance.products.where((x)=>old==null || x.id!=old.id).map((a){final on=addonMax.containsKey(a.id);return Row(children:[Expanded(child:CheckboxListTile(contentPadding:EdgeInsets.zero,value:on,title:Text(a.nameAr),subtitle:Text('${a.price.toStringAsFixed(0)} ريال'),onChanged:(v)=>setLocal((){if(v==true){addonMax[a.id]=1;}else{addonMax.remove(a.id);}}))),if(on)SizedBox(width:110,child:TextFormField(initialValue:'${addonMax[a.id]}',keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'الحد الأقصى'),onChanged:(v)=>addonMax[a.id]=(int.tryParse(v)??1).clamp(1,99))) ]);}),
                  DropdownButtonFormField<String>(
                    value: category,
                    items: ['تذاكر', 'إضافات', 'خدمات', 'منتجات'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                    onChanged: (v) => setLocal(() => category = v ?? category),
                    decoration: const InputDecoration(labelText: 'التصنيف'),
                  ),
                  const SizedBox(height: 12),
                  if (imagePath != null && File(imagePath!).existsSync()) Image.file(File(imagePath!), height: 120),
                  OutlinedButton.icon(
                    onPressed: () async {
                      final x = await picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
                      if (x != null) setLocal(() => imagePath = x.path);
                    },
                    icon: const Icon(Icons.image_outlined),
                    label: const Text('اختيار صورة المنتج'),
                  )
                ],
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
            FilledButton(
              onPressed: () async {
                final p = old ?? Product(id: 'p${DateTime.now().millisecondsSinceEpoch}', nameAr: '', nameEn: '', price: 0, category: category);
                p.nameAr = name.text.trim();
                p.nameEn = en.text.trim();
                p.price = double.tryParse(price.text) ?? 0;
                p.stock = stock.text.trim().isEmpty ? -1 : (int.tryParse(stock.text) ?? 0);
                p.category = category;
                p.imagePath = imagePath;
                p.description = description.text.trim();
                p.requiresLounge = requiresLounge;
                p.quickHome = requiresLounge ? false : quickHome;
                p.popularBadge = popularBadge;
                p.addons = addonMax.entries.map((e)=>ProductAddonRule(productId:e.key,maxQty:e.value)).toList();
                if (old == null) Store.instance.products.add(p);
                await Store.instance.save();
                await CloudSync.pushProduct(p,sortOrder:Store.instance.products.indexOf(p));
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('حفظ'),
            )
          ],
        ),
      ),
    );
  }
}

Future<void> _exportCustomers(BuildContext context,List<MapEntry<String,List<Sale>>> entries) async {
  String q(String v)=>'"${v.replaceAll('"','""')}"';
  final b=StringBuffer(); b.writeln('رقم الجوال,التصنيف,عدد الزيارات,إجمالي المشتريات,متوسط الفاتورة,أول زيارة,آخر زيارة,المنتجات والكميات,طرق الدفع,تفاصيل الفواتير');
  for(final e in entries){final ss=[...e.value]..sort((a,b)=>a.createdAt.compareTo(b.createdAt));final spend=ss.fold<double>(0,(a,b)=>a+b.total);final counts=<String,int>{};final pays=<String,int>{};for(final x in ss){pays[x.paymentMethod]=(pays[x.paymentMethod]??0)+1;for(final i in x.items)counts[i.name]=(counts[i.name]??0)+i.qty;}final type=ss.length>=10?'VIP':ss.length>=2?'عميل متكرر':'عميل جديد';b.writeln([q(e.key),q(type),ss.length,spend.toStringAsFixed(2),(spend/ss.length).toStringAsFixed(2),q(ss.first.createdAt.toString()),q(ss.last.createdAt.toString()),q(counts.entries.map((x)=>'${x.key}: ${x.value}').join(' | ')),q(pays.entries.map((x)=>'${x.key}: ${x.value}').join(' | ')),q(ss.map((x)=>'${x.id} / ${x.createdAt} / ${x.total.toStringAsFixed(2)} ريال / ${x.paymentMethod} / ${x.items.map((i)=>"${i.name} x${i.qty}").join(" + ")}').join(' || '))].join(','));}
  try{final path=await const MethodChannel('kittyhere/files').invokeMethod<String>('saveCsv',{'filename':'kitty_here_customers_${DateTime.now().millisecondsSinceEpoch}.csv','content':'\uFEFF${b.toString()}'});if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تم تحميل بيانات العملاء في مجلد التنزيلات\n${path??''}')));}catch(e){if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر تحميل الملف: $e')));}
}

class CustomersPage extends StatelessWidget {
  const CustomersPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(valueListenable: Store.instance.rev, builder: (_, __, ___) {
      final groups = <String, List<Sale>>{};
      for (final s in Store.instance.sales.where((x) => x.customerPhone.isNotEmpty && (x.paymentStatus == 'APPROVED' || x.paymentStatus == 'MANUAL'))) {
        groups.putIfAbsent(s.customerPhone, () => []).add(s);
      }
      final entries = groups.entries.toList()..sort((a,b) => b.value.length.compareTo(a.value.length));
      return ListView(padding: const EdgeInsets.all(20), children: [
        Row(children:[const Expanded(child:Text('قاعدة العملاء', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900))),FilledButton.icon(onPressed:()=>_exportCustomers(context,entries),icon:const Icon(Icons.download),label:const Text('تحميل جميع بيانات العملاء'))]),
        Text('${entries.length} عميل مسجل • البيانات متاحة من لوحة الإدارة فقط'),
        const SizedBox(height: 12),
        ...entries.map((e) {
          final sales = e.value..sort((a,b)=>b.createdAt.compareTo(a.createdAt));
          final spend = sales.fold<double>(0, (a,b)=>a+b.total);
          final counts=<String,int>{};
          for(final s in sales) for(final i in s.items) counts[i.name]=(counts[i.name]??0)+i.qty;
          final fav = counts.entries.isEmpty ? '-' : (counts.entries.toList()..sort((a,b)=>b.value.compareTo(a.value))).first.key;
          final type = sales.length >= 10 ? 'VIP' : sales.length >= 2 ? 'عميل متكرر' : 'عميل جديد';
          return Card(child: ExpansionTile(
            leading: const CircleAvatar(child: Icon(Icons.person)),
            title: Text(e.key, style: const TextStyle(fontWeight: FontWeight.w900)),
            subtitle: Text('$type • ${sales.length} زيارة • ${spend.toStringAsFixed(2)} ريال'),
            children: [
              ListTile(title: const Text('أكثر شيء يشتريه'), trailing: Text(fav)),
              ListTile(title: const Text('متوسط الفاتورة'), trailing: Text('${(spend/sales.length).toStringAsFixed(2)} ريال')),
              ListTile(title: const Text('آخر زيارة'), trailing: Text('${sales.first.createdAt}')),
              ListTile(title: const Text('أول زيارة'), trailing: Text('${sales.last.createdAt}')),
              const Divider(),
              ...counts.entries.map((x)=>ListTile(dense:true,title:Text(x.key),trailing:Text('${x.value} مرة'))),
            ],
          ));
        }),
      ]);
    });
  }
}

class SalesPage extends StatefulWidget {
  const SalesPage({super.key});
  @override State<SalesPage> createState()=>_SalesPageState();
}
class _SalesPageState extends State<SalesPage>{
  String period='today'; DateTime? from; DateTime? to;
  bool inPeriod(Sale s){final n=DateTime.now(),d=s.createdAt;if(period=='all')return true;if(period=='today')return d.year==n.year&&d.month==n.month&&d.day==n.day;if(period=='yesterday'){final y=DateTime(n.year,n.month,n.day).subtract(const Duration(days:1));return d.year==y.year&&d.month==y.month&&d.day==y.day;}if(period=='week'){final a=DateTime(n.year,n.month,n.day).subtract(Duration(days:n.weekday-1));return !d.isBefore(a);}if(period=='month')return d.year==n.year&&d.month==n.month;if(period=='year')return d.year==n.year;if(period=='custom'&&from!=null&&to!=null){final a=DateTime(from!.year,from!.month,from!.day),z=DateTime(to!.year,to!.month,to!.day,23,59,59);return !d.isBefore(a)&&!d.isAfter(z);}return true;}
  Future<void> pickRange()async{final r=await showDateRangePicker(context:context,firstDate:DateTime(2020),lastDate:DateTime.now().add(const Duration(days:365)),initialDateRange:from!=null&&to!=null?DateTimeRange(start:from!,end:to!):null);if(r!=null)setState((){from=r.start;to=r.end;period='custom';});}
  @override Widget build(BuildContext context)=>ValueListenableBuilder<int>(valueListenable:Store.instance.rev,builder:(_,__,___){final sales=Store.instance.sales.where((s)=>(s.paymentStatus=='APPROVED'||s.paymentStatus=='MANUAL')&&inPeriod(s)).toList();final total=sales.fold<double>(0,(a,b)=>a+b.total);final avg=sales.isEmpty?0:total/sales.length;return Column(children:[Padding(padding:const EdgeInsets.all(16),child:Column(children:[Row(children:[Expanded(child:DropdownButtonFormField<String>(value:period,decoration:const InputDecoration(labelText:'الفترة',border:OutlineInputBorder()),items:const [DropdownMenuItem(value:'today',child:Text('اليوم')),DropdownMenuItem(value:'yesterday',child:Text('أمس')),DropdownMenuItem(value:'week',child:Text('هذا الأسبوع')),DropdownMenuItem(value:'month',child:Text('هذا الشهر')),DropdownMenuItem(value:'year',child:Text('هذه السنة')),DropdownMenuItem(value:'all',child:Text('كل المبيعات')),DropdownMenuItem(value:'custom',child:Text('فترة مخصصة'))],onChanged:(v){setState(()=>period=v!);if(v=='custom')pickRange();})),const SizedBox(width:12),OutlinedButton.icon(onPressed:pickRange,icon:const Icon(Icons.date_range),label:Text(from==null?'من تاريخ — إلى تاريخ':'${from!.year}/${from!.month}/${from!.day} — ${to!.year}/${to!.month}/${to!.day}'))]),const SizedBox(height:12),Row(children:[Expanded(child:_stat('عدد الفواتير','${sales.length}')),Expanded(child:_stat('صافي المبيعات','${total.toStringAsFixed(2)} ريال')),Expanded(child:_stat('متوسط البيع','${avg.toStringAsFixed(2)} ريال'))])])),Expanded(child:ListView.builder(padding:const EdgeInsets.all(20),itemCount:sales.length,itemBuilder:(_,i){final s=sales[i];return Card(child:ExpansionTile(title:Text('طلب #${s.id} — ${s.total.toStringAsFixed(2)} ريال'),subtitle:Text('${s.createdAt} • ${s.paymentMethod} • ${s.source}'),children:[...s.items.map((x)=>ListTile(title:Text(x.name),trailing:Text('${x.qty} × ${x.unitPrice.toStringAsFixed(2)}'))),Padding(padding:const EdgeInsets.all(12),child:Row(children:[Expanded(child:OutlinedButton.icon(onPressed:() async {final ok=await UsbPrinter.printReceipt(ReceiptBuilder.build(s));s.printed=ok;await Store.instance.save();if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(ok?'تمت إعادة الطباعة':'تعذرت الطباعة')));},icon:const Icon(Icons.print),label:const Text('إعادة طباعة الفاتورة'))),const SizedBox(width:10),Expanded(child:OutlinedButton.icon(onPressed:() async {final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('إلغاء الفاتورة؟'),content:const Text('ستُستبعد محلياً من المبيعات. عملية Nami لا يتم استرجاع مبلغها تلقائياً.'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('رجوع')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('إلغاء الفاتورة'))]));if(ok==true){s.paymentStatus='CANCELLED';await Store.instance.save();}},icon:const Icon(Icons.delete_outline),label:const Text('إلغاء الفاتورة')))]))]));}))]);});
  Widget _stat(String a,String b)=>Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(children:[Text(a),Text(b,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900,color:deepPink))])));
}

class ManualInvoicePage extends StatefulWidget {
  const ManualInvoicePage({super.key});
  @override
  State<ManualInvoicePage> createState() => _ManualInvoicePageState();
}

class _ManualInvoicePageState extends State<ManualInvoicePage> {
  final Map<String, int> invoice = {};
  String paymentMethod = 'cash';
  double get total {
    double t = 0;
    for (final e in invoice.entries) {
      final p = Store.instance.products.where((x) => x.id == e.key).firstOrNull;
      if (p != null) t += p.price * e.value;
    }
    return t;
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          const Align(alignment: Alignment.centerRight, child: Text('إصدار فاتورة يدوية', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900))),
          Padding(padding: const EdgeInsets.symmetric(vertical:12), child: DropdownButtonFormField<String>(value: paymentMethod, decoration: const InputDecoration(labelText:'طريقة الدفع', border:OutlineInputBorder()), items: const [DropdownMenuItem(value:'cash',child:Text('كاش')),DropdownMenuItem(value:'bank_transfer',child:Text('تحويل بنكي')),DropdownMenuItem(value:'tabby',child:Text('تابي')),DropdownMenuItem(value:'tamara',child:Text('تمارا')),DropdownMenuItem(value:'other',child:Text('أخرى'))], onChanged:(v)=>setState(()=>paymentMethod=v!))),
          Expanded(
            child: ListView(
              children: Store.instance.products.where((p) => p.enabled).map((p) => CheckboxListTile(
                value: (invoice[p.id] ?? 0) > 0,
                title: Text('${p.nameAr} — ${p.price.toStringAsFixed(2)} ريال'),
                secondary: SizedBox(width: 50, height: 50, child: ProductVisual(product: p)),
                onChanged: (v) => setState(() => invoice[p.id] = v == true ? 1 : 0),
              )).toList(),
            ),
          ),
          Row(
            children: [
              Expanded(child: Text('الإجمالي: ${total.toStringAsFixed(2)} ريال', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900))),
              FilledButton.icon(
                onPressed: total <= 0 ? null : () async {
                  final items = <SaleItem>[];
                  for (final e in invoice.entries.where((e) => e.value > 0)) {
                    final p = Store.instance.products.where((x) => x.id == e.key).first;
                    items.add(SaleItem(p.id, p.nameAr, e.value, p.price));
                  }
                  final s = Sale(id: 'M${DateTime.now().millisecondsSinceEpoch}', createdAt: DateTime.now(), items: items, total: total, paymentStatus: 'MANUAL', paymentRef: 'MANUAL', paymentMethod: paymentMethod, source: 'tablet_manual');
                  await Store.instance.addSale(s);
                  final ok = await UsbPrinter.printReceipt(ReceiptBuilder.build(s));
                  s.printed = ok;
                  await Store.instance.save();
                  if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? 'تم إصدار وطباعة الفاتورة' : 'تم إصدار الفاتورة، والطابعة تحتاج إعداد')));
                },
                icon: const Icon(Icons.receipt_long),
                label: const Text('إصدار وطباعة'),
              )
            ],
          )
        ],
      ),
    );
  }
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late TextEditingController ip;
  late TextEditingController port;
  late TextEditingController terminal;
  late TextEditingController crn;
  late TextEditingController remoteApi;
  late TextEditingController remoteToken;
  late TextEditingController receiptTitle;
  late TextEditingController receiptFooter;
  bool discovering = false;
  String msg = '';

  @override
  void initState() {
    super.initState();
    final s = Store.instance.settings;
    ip = TextEditingController(text: s.namiIp);
    port = TextEditingController(text: '${s.namiPort}');
    terminal = TextEditingController(text: s.terminalId);
    crn = TextEditingController(text: s.crn);
    remoteApi = TextEditingController(text: s.remoteApi);
    remoteToken = TextEditingController(text: s.remoteToken);
    receiptTitle = TextEditingController(text: s.receiptTitle);
    receiptFooter = TextEditingController(text: s.receiptFooter);
  }

  Future<void> discover() async {
    final parts = ip.text.trim().split('.');
    if (parts.length != 4) return;
    setState(() { discovering = true; msg = 'جاري البحث على المنفذ ${port.text}...'; });
    final prefix = '${parts[0]}.${parts[1]}.${parts[2]}';
    final p = int.tryParse(port.text) ?? 1024;
    for (int start = 1; start <= 254; start += 24) {
      final f = <Future<String?>>[];
      for (int i = start; i < start + 24 && i <= 254; i++) {
        final h = '$prefix.$i';
        f.add(() async {
          try {
            final s = await Socket.connect(h, p, timeout: const Duration(milliseconds: 450));
            s.destroy();
            return h;
          } catch (_) { return null; }
        }());
      }
      final r = (await Future.wait(f)).whereType<String>().toList();
      if (r.isNotEmpty) {
        setState(() { ip.text = r.first; msg = 'تم العثور: ${r.first}:$p'; discovering = false; });
        return;
      }
    }
    setState(() { msg = 'لم يتم العثور على جهاز على نفس الشبكة'; discovering = false; });
  }

  Future<void> syncRemote() async {
    if (remoteApi.text.trim().isEmpty) {
      setState(() => msg = 'أدخل رابط السيرفر أولاً');
      return;
    }
    try {
      final u = Uri.parse('${remoteApi.text.trim().replaceAll(RegExp(r'/$'), '')}/health');
      final r = await http.get(u, headers: remoteToken.text.isEmpty ? {} : {'Authorization': 'Bearer ${remoteToken.text.trim()}'}).timeout(const Duration(seconds: 6));
      setState(() => msg = 'السيرفر: ${r.statusCode}');
    } catch (e) {
      setState(() => msg = 'تعذر الاتصال بالسيرفر: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = Store.instance.settings;
    return ListView(
      padding: const EdgeInsets.all(22),
      children: [
        const Text('إعدادات نقاط البيع', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
        TextField(controller: ip, decoration: const InputDecoration(labelText: 'IP جهاز Nami')),
        TextField(controller: port, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'ECR Port')),
        TextField(controller: terminal, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Terminal ID')),
        TextField(controller: crn, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Cash Register Number (8 digits)')),
        SwitchListTile(
          title: const Text('وضع الدفع التجريبي'),
          subtitle: const Text('أوقفه عند إضافة Nami ecrlib الرسمية'),
          value: s.demoPayment,
          onChanged: (v) => setState(() => s.demoPayment = v),
        ),
        SwitchListTile(
          title: const Text('وضع الخدمة الذاتية (Kiosk)'),
          subtitle: const Text('يخفي أزرار النظام ويثبت التطبيق على تجربة الطلب'),
          value: s.kioskMode,
          onChanged: (v) async {
            setState(() => s.kioskMode = v);
            if (v) {
              await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
            } else {
              await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
            }
          },
        ),
        TextField(
          controller: TextEditingController(text: s.adminPin),
          keyboardType: TextInputType.number,
          obscureText: true,
          onChanged: (v) => s.adminPin = v.trim(),
          decoration: const InputDecoration(labelText: 'رمز دخول الإدارة'),
        ),
        Wrap(spacing: 10, children: [
          FilledButton.icon(onPressed: discovering ? null : discover, icon: const Icon(Icons.radar), label: const Text('اكتشاف Nami تلقائياً')),
          OutlinedButton.icon(
            onPressed: () async {
              final temp = AppSettings(namiIp: ip.text.trim(), namiPort: int.tryParse(port.text) ?? 1024);
              final ok = await NamiService(temp).testConnection();
              setState(() => msg = ok ? 'الاتصال بجهاز Nami ناجح' : 'فشل الاتصال');
            },
            icon: const Icon(Icons.wifi_tethering),
            label: const Text('اختبار الاتصال'),
          ),
          OutlinedButton.icon(
            onPressed: () {
              final s = Store.instance.settings;
              s.namiIp = ip.text.trim();
              s.namiPort = int.tryParse(port.text) ?? 1024;
              s.terminalId = terminal.text.trim();
              s.crn = crn.text.trim();
              Navigator.push(context, MaterialPageRoute(builder: (_) => const ExperimentalEcrPage()));
            },
            icon: const Icon(Icons.science_outlined),
            label: const Text('اختبار بروتوكول ECR التجريبي'),
          ),
        ]),
        const Divider(height: 38),
        const Text('الطابعة USB', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const Text('CITyPOS CP-P850N • 80mm • ESC/POS • USB'),
        OutlinedButton.icon(
          onPressed: () async {
            final d = await UsbPrinter.devices();
            setState(() => msg = d.isEmpty ? 'لم يتم اكتشاف طابعة USB' : 'تم اكتشاف ${d.length} جهاز USB');
          },
          icon: const Icon(Icons.print),
          label: const Text('اكتشاف الطابعة'),
        ),
        const Divider(height: 38),
        const Text('تخصيص الفاتورة', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        TextField(controller: receiptTitle, decoration: const InputDecoration(labelText: 'اسم / عنوان أعلى الفاتورة')),
        TextField(controller: receiptFooter, maxLines: 2, decoration: const InputDecoration(labelText: 'جملة نهاية الفاتورة')),
        Row(children: [
          Expanded(child: Text(s.receiptLogoPath.isEmpty ? 'لا يوجد شعار مخصص' : 'تم اختيار شعار الفاتورة')),
          OutlinedButton.icon(onPressed: () async {
            final x = await ImagePicker().pickImage(source: ImageSource.gallery);
            if (x != null) setState(() => s.receiptLogoPath = x.path);
          }, icon: const Icon(Icons.image_outlined), label: const Text('اختيار شعار الفاتورة')),
          if (s.receiptLogoPath.isNotEmpty) IconButton(onPressed: ()=>setState(()=>s.receiptLogoPath=''), icon: const Icon(Icons.delete_outline)),
        ]),
        const Divider(height: 38),
        const Text('التحكم عن بعد', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const Text('البنية جاهزة للمزامنة. تحتاج رابط Backend آمن حتى تعدل المنتجات والمخزون والمبيعات من خارج المحل.'),
        TextField(controller: remoteApi, decoration: const InputDecoration(labelText: 'Remote API URL')),
        TextField(controller: remoteToken, obscureText: true, decoration: const InputDecoration(labelText: 'API Token')),
        OutlinedButton(onPressed: syncRemote, child: const Text('اختبار السيرفر')),
        const SizedBox(height: 18),
        FilledButton(
          onPressed: () async {
            s.namiIp = ip.text.trim();
            s.namiPort = int.tryParse(port.text) ?? 1024;
            s.terminalId = terminal.text.trim();
            s.crn = crn.text.trim();
            s.remoteApi = remoteApi.text.trim();
            s.remoteToken = remoteToken.text.trim();
            s.receiptTitle = receiptTitle.text.trim();
            s.receiptFooter = receiptFooter.text.trim();
            await Store.instance.save();
            setState(() => msg = 'تم حفظ الإعدادات');
          },
          child: const Text('حفظ جميع الإعدادات'),
        ),
        if (discovering) const Padding(padding: EdgeInsets.all(12), child: LinearProgressIndicator()),
        if (msg.isNotEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(msg, style: const TextStyle(fontWeight: FontWeight.bold))),
      ],
    );
  }
}
