import 'dart:io';
import 'package:flutter/material.dart';
void main()=>runApp(const App());
class App extends StatelessWidget{const App({super.key});@override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,home:const Home());}
class Home extends StatefulWidget{const Home({super.key});@override State<Home> createState()=>_Home();}
class _Home extends State<Home>{final amount=TextEditingController();String status='جاهز';
Future<void> test() async{setState(()=>status='جاري الاتصال...');try{final s=await Socket.connect('172.20.10.3',16535,timeout:const Duration(seconds:5));s.destroy();setState(()=>status='تم الاتصال بجهاز مدى ✓');}catch(e){setState(()=>status='تعذر الاتصال');}}
@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Nami Kiosk')),body:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[TextField(controller:amount,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'المبلغ',border:OutlineInputBorder())),const SizedBox(height:16),SizedBox(width:double.infinity,height:55,child:ElevatedButton(onPressed:test,child:const Text('اختبار الاتصال بجهاز مدى'))),const SizedBox(height:20),Text(status)])));}
}
