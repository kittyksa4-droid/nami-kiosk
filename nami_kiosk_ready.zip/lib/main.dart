import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:bluetooth_classic/bluetooth_classic.dart';
import 'package:bluetooth_classic/models/device.dart';

void main() => runApp(const NamiBtApp());

class NamiBtApp extends StatelessWidget {
  const NamiBtApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const BtHome(),
    );
  }
}

class BtHome extends StatefulWidget {
  const BtHome({super.key});

  @override
  State<BtHome> createState() => _BtHomeState();
}

class _BtHomeState extends State<BtHome> {
  final BluetoothClassic bt = BluetoothClassic();
  List<Device> devices = [];
  String status = 'جاهز';
  Uint8List received = Uint8List(0);

  @override
  void initState() {
    super.initState();
    bt.onDeviceDataReceived().listen((event) {
      if (!mounted) return;
      setState(() {
        received = Uint8List.fromList([...received, ...event]);
        status = '✅ استلمنا ${event.length} بايت';
      });
    });
  }

  Future<void> loadPaired() async {
    try {
      setState(() => status = 'جاري طلب صلاحية البلوتوث...');
      await bt.initPermissions();
      final list = await bt.getPairedDevices();
      if (!mounted) return;
      setState(() {
        devices = list;
        status = list.isEmpty
            ? '❌ ما لقيت أجهزة مقترنة'
            : '✅ لقيت ${list.length} جهاز/أجهزة';
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => status = '❌ خطأ: $e');
    }
  }

  Future<void> connect(Device d) async {
    try {
      setState(() => status = 'جاري الاتصال بـ ${d.name ?? d.address}...');
      await bt.connect(
        d.address,
        '00001101-0000-1000-8000-00805f9b34fb',
      );
      if (!mounted) return;
      setState(() => status = '✅ متصل بـ ${d.name ?? d.address}');
    } catch (e) {
      if (!mounted) return;
      setState(() => status = '❌ فشل الاتصال: $e');
    }
  }

  Future<void> sendPing() async {
    try {
      await bt.write('ping');
      if (!mounted) return;
      setState(() => status = '📤 تم إرسال ping');
    } catch (e) {
      if (!mounted) return;
      setState(() => status = '❌ فشل الإرسال: $e');
    }
  }

  Future<void> disconnect() async {
    try {
      await bt.disconnect();
      if (!mounted) return;
      setState(() => status = 'تم قطع الاتصال');
    } catch (e) {
      if (!mounted) return;
      setState(() => status = '❌ $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final rxText = received.isEmpty
        ? 'لا توجد بيانات مستلمة'
        : String.fromCharCodes(received);

    return Scaffold(
      appBar: AppBar(title: const Text('Nami Bluetooth Test')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: loadPaired,
                child: const Text('عرض الأجهزة المقترنة'),
              ),
            ),
            const SizedBox(height: 12),
            Text(status, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                itemCount: devices.length,
                itemBuilder: (context, i) {
                  final d = devices[i];
                  return Card(
                    child: ListTile(
                      leading: const Icon(Icons.bluetooth),
                      title: Text(d.name ?? 'بدون اسم'),
                      subtitle: Text(d.address),
                      onTap: () => connect(d),
                    ),
                  );
                },
              ),
            ),
            Text(
              'RX: $rxText',
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: sendPing,
                    child: const Text('إرسال اختبار'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton(
                    onPressed: disconnect,
                    child: const Text('قطع الاتصال'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
