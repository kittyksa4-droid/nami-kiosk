import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

const pink = Color(0xFFE66AA0);
const deepPink = Color(0xFFD94B84);
const cream = Color(0xFFFFFBF6);
const gridPink = Color(0xFFF5C3D6);
const ink = Color(0xFF4C353C);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Store.instance.load();
  runApp(const KittyHereApp());
}

class KittyHereApp extends StatelessWidget {
  const KittyHereApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kitty Here',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: pink),
        scaffoldBackgroundColor: cream,
        fontFamily: 'sans',
        useMaterial3: true,
      ),
      home: const WelcomeScreen(),
    );
  }
}

class Product {
  String id;
  String nameAr;
  String nameEn;
  double price;
  String category;
  int stock; // -1 = unlimited
  bool enabled;
  String? imagePath;
  String iconName;

  Product({
    required this.id,
    required this.nameAr,
    required this.nameEn,
    required this.price,
    required this.category,
    this.stock = -1,
    this.enabled = true,
    this.imagePath,
    this.iconName = 'star',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'nameAr': nameAr,
        'nameEn': nameEn,
        'price': price,
        'category': category,
        'stock': stock,
        'enabled': enabled,
        'imagePath': imagePath,
        'iconName': iconName,
      };

  factory Product.fromJson(Map<String, dynamic> j) => Product(
        id: j['id'],
        nameAr: j['nameAr'],
        nameEn: j['nameEn'] ?? '',
        price: (j['price'] as num).toDouble(),
        category: j['category'] ?? 'منتجات',
        stock: j['stock'] ?? -1,
        enabled: j['enabled'] ?? true,
        imagePath: j['imagePath'],
        iconName: j['iconName'] ?? 'star',
      );
}

class SaleItem {
  String productId;
  String name;
  int qty;
  double unitPrice;

  SaleItem(this.productId, this.name, this.qty, this.unitPrice);

  Map<String, dynamic> toJson() => {
        'productId': productId,
        'name': name,
        'qty': qty,
        'unitPrice': unitPrice,
      };

  factory SaleItem.fromJson(Map<String, dynamic> j) => SaleItem(
        j['productId'],
        j['name'],
        j['qty'],
        (j['unitPrice'] as num).toDouble(),
      );
}

class Sale {
  String id;
  DateTime createdAt;
  List<SaleItem> items;
  double total;
  String paymentStatus;
  String paymentRef;
  bool printed;

  Sale({
    required this.id,
    required this.createdAt,
    required this.items,
    required this.total,
    required this.paymentStatus,
    required this.paymentRef,
    this.printed = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'createdAt': createdAt.toIso8601String(),
        'items': items.map((e) => e.toJson()).toList(),
        'total': total,
        'paymentStatus': paymentStatus,
        'paymentRef': paymentRef,
        'printed': printed,
      };

  factory Sale.fromJson(Map<String, dynamic> j) => Sale(
        id: j['id'],
        createdAt: DateTime.parse(j['createdAt']),
        items: (j['items'] as List).map((e) => SaleItem.fromJson(Map<String, dynamic>.from(e))).toList(),
        total: (j['total'] as num).toDouble(),
        paymentStatus: j['paymentStatus'] ?? 'APPROVED',
        paymentRef: j['paymentRef'] ?? '',
        printed: j['printed'] ?? false,
      );
}

class AppSettings {
  String namiIp;
  int namiPort;
  String terminalId;
  String crn;
  bool demoPayment;
  String remoteApi;
  String remoteToken;
  bool kioskMode;
  String adminPin;

  AppSettings({
    this.namiIp = '172.20.10.2',
    this.namiPort = 1024,
    this.terminalId = '11232541',
    this.crn = '73154354',
    this.demoPayment = true,
    this.remoteApi = '',
    this.remoteToken = '',
    this.kioskMode = true,
    this.adminPin = '2468',
  });

  Map<String, dynamic> toJson() => {
        'namiIp': namiIp,
        'namiPort': namiPort,
        'terminalId': terminalId,
        'crn': crn,
        'demoPayment': demoPayment,
        'remoteApi': remoteApi,
        'remoteToken': remoteToken,
        'kioskMode': kioskMode,
        'adminPin': adminPin,
      };

  factory AppSettings.fromJson(Map<String, dynamic> j) => AppSettings(
        namiIp: j['namiIp'] ?? '172.20.10.2',
        namiPort: j['namiPort'] ?? 1024,
        terminalId: j['terminalId'] ?? '11232541',
        crn: (j['crn'] ?? '').toString().trim().isEmpty ? '73154354' : j['crn'],
        demoPayment: j['demoPayment'] ?? true,
        remoteApi: j['remoteApi'] ?? '',
        remoteToken: j['remoteToken'] ?? '',
        kioskMode: j['kioskMode'] ?? true,
        adminPin: j['adminPin'] ?? '2468',
      );
}

class Store {
  Store._();
  static final instance = Store._();

  final ValueNotifier<int> rev = ValueNotifier(0);
  List<Product> products = [];
  List<Sale> sales = [];
  AppSettings settings = AppSettings();

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final productsJson = p.getString('products');
    final salesJson = p.getString('sales');
    final settingsJson = p.getString('settings');

    if (productsJson == null) {
      products = _defaults();
      await save();
    } else {
      products = (jsonDecode(productsJson) as List)
          .map((e) => Product.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    }

    if (salesJson != null) {
      sales = (jsonDecode(salesJson) as List)
          .map((e) => Sale.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    }

    if (settingsJson != null) {
      settings = AppSettings.fromJson(Map<String, dynamic>.from(jsonDecode(settingsJson)));
    }
  }

  List<Product> _defaults() => [
        Product(id: 'shower', nameAr: 'الشاور - عرض حالياً', nameEn: 'Shower', price: 49, category: 'خدمات', iconName: 'shower'),
        Product(id: 'ticket30', nameAr: 'Ticket نص ساعة + تريت', nameEn: '30 min Ticket + Treat', price: 35, category: 'تذاكر', iconName: 'timer'),
        Product(id: 'ticketOpen', nameAr: 'Ticket وقت مفتوح', nameEn: 'Open Time Ticket', price: 65, category: 'تذاكر', iconName: 'infinity'),
        Product(id: 'mug', nameAr: 'Mug', nameEn: 'Mug', price: 25, category: 'منتجات', iconName: 'mug'),
        Product(id: 'photo', nameAr: 'فوتو بوث Photo Booth', nameEn: 'Photo Booth', price: 10, category: 'إضافات', iconName: 'camera'),
        Product(id: 'extra15', nameAr: 'وقت إضافي 15 دقيقة', nameEn: 'Extra 15 Minutes', price: 15, category: 'إضافات', iconName: 'timer'),
        Product(id: 'treat', nameAr: 'تريت إضافي', nameEn: 'Extra Treat', price: 5, category: 'إضافات', iconName: 'treat'),
        Product(id: 'companion', nameAr: 'مرافق', nameEn: 'Companion', price: 10, category: 'إضافات', iconName: 'person'),
        Product(id: 'nails', nameAr: 'قص أظافر', nameEn: 'Nail Trim', price: 25, category: 'خدمات', iconName: 'scissors'),
        Product(id: 'stickers', nameAr: 'ملصقات', nameEn: 'Stickers', price: 15, category: 'منتجات', iconName: 'sticker'),
      ];

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('products', jsonEncode(products.map((e) => e.toJson()).toList()));
    await p.setString('sales', jsonEncode(sales.map((e) => e.toJson()).toList()));
    await p.setString('settings', jsonEncode(settings.toJson()));
    rev.value++;
  }

  Future<void> addSale(Sale sale) async {
    sales.insert(0, sale);
    for (final item in sale.items) {
      final p = products.where((x) => x.id == item.productId).firstOrNull;
      if (p != null && p.stock >= 0) p.stock = (p.stock - item.qty).clamp(0, 999999);
    }
    await save();
  }
}

extension FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}

class GridPaper extends StatelessWidget {
  final Widget child;
  const GridPaper({super.key, required this.child});
  @override
  Widget build(BuildContext context) => CustomPaint(
        painter: GridPainter(),
        child: child,
      );
}

class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = gridPink.withOpacity(.45)
      ..strokeWidth = 1;
    for (double x = 0; x < size.width; x += 38) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += 38) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});
  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  @override
  void initState() {
    super.initState();
    _applyKiosk();
  }

  Future<void> _applyKiosk() async {
    if (Store.instance.settings.kioskMode) {
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
      await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
    } else {
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GridPaper(
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  const Text('kitty here', style: TextStyle(fontSize: 44, fontWeight: FontWeight.w900, color: deepPink)),
                  const Text('CAT LOUNGE', style: TextStyle(letterSpacing: 4, color: pink)),
                  const SizedBox(height: 20),
                  Image.asset('assets/kitty_mascot.jpg', height: 330, fit: BoxFit.contain),
                  const SizedBox(height: 10),
                  const Text('ابدأ', style: TextStyle(fontSize: 64, color: deepPink, fontWeight: FontWeight.w900)),
                  const Text('تجربتك المميزة\nفي عالم كيتي هير', textAlign: TextAlign.center, style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800, color: ink)),
                  const SizedBox(height: 26),
                  SizedBox(
                    width: 430,
                    height: 72,
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(backgroundColor: deepPink),
                      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MenuScreen())),
                      icon: const Icon(Icons.pets, size: 30),
                      label: const Text('ابدأ الطلب', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextButton(
                    onPressed: () => _showAdminPin(context),
                    child: const Text('خروج الإدارة', style: TextStyle(color: Colors.black26, fontSize: 12)),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showAdminPin(BuildContext context) {
    final c = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('دخول الإدارة'),
        content: TextField(controller: c, obscureText: true, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'الرمز')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () {
              if (c.text == Store.instance.settings.adminPin) {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminHome()));
              }
            },
            child: const Text('دخول'),
          )
        ],
      ),
    );
  }
}

class MenuScreen extends StatefulWidget {
  const MenuScreen({super.key});
  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  final Map<String, int> cart = {};
  String category = 'الكل';

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: Store.instance.rev,
      builder: (_, __, ___) {
        final all = Store.instance.products.where((p) => p.enabled).toList();
        final visible = category == 'الكل' ? all : all.where((p) => p.category == category).toList();
        final categories = ['الكل', 'تذاكر', 'إضافات', 'خدمات', 'منتجات'];
        final count = cart.values.fold<int>(0, (a, b) => a + b);
        return Scaffold(
          appBar: AppBar(
            title: const Text('kitty here', style: TextStyle(color: deepPink, fontWeight: FontWeight.w900)),
            centerTitle: true,
            actions: [
              Badge(label: Text('$count'), child: IconButton(icon: const Icon(Icons.shopping_cart_outlined), onPressed: () => _openCart(context))),
              const SizedBox(width: 12),
            ],
          ),
          body: Row(
            children: [
              Container(
                width: 190,
                color: const Color(0xFFFFF3F7),
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    for (final c in categories)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 5),
                        child: ListTile(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          tileColor: category == c ? pink : Colors.transparent,
                          textColor: category == c ? Colors.white : ink,
                          leading: Icon(_categoryIcon(c)),
                          title: Text(c),
                          onTap: () => setState(() => category = c),
                        ),
                      ),
                    const Spacer(),
                    Image.asset('assets/kitty_mascot.jpg', height: 145),
                  ],
                ),
              ),
              Expanded(
                child: GridPaper(
                  child: GridView.builder(
                    padding: const EdgeInsets.all(18),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, childAspectRatio: 1.05, crossAxisSpacing: 14, mainAxisSpacing: 14),
                    itemCount: visible.length,
                    itemBuilder: (_, i) {
                      final p = visible[i];
                      final soldOut = p.stock == 0;
                      return InkWell(
                        onTap: soldOut ? null : () => setState(() => cart[p.id] = (cart[p.id] ?? 0) + 1),
                        child: Card(
                          elevation: 0,
                          color: Colors.white.withOpacity(.93),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: BorderSide(color: gridPink)),
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Expanded(child: ProductVisual(product: p)),
                                const SizedBox(height: 8),
                                Text(p.nameAr, textAlign: TextAlign.center, maxLines: 2, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                                Text('${p.price.toStringAsFixed(0)} ريال', style: const TextStyle(color: deepPink, fontSize: 20, fontWeight: FontWeight.w900)),
                                if (soldOut) const Text('نفد المخزون', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              )
            ],
          ),
          floatingActionButton: count == 0
              ? null
              : FloatingActionButton.extended(
                  backgroundColor: deepPink,
                  foregroundColor: Colors.white,
                  onPressed: () => _openCart(context),
                  icon: const Icon(Icons.shopping_cart_checkout),
                  label: Text('السلة ($count)'),
                ),
        );
      },
    );
  }

  IconData _categoryIcon(String c) => switch (c) {
        'تذاكر' => Icons.confirmation_num_outlined,
        'إضافات' => Icons.add_circle_outline,
        'خدمات' => Icons.content_cut,
        'منتجات' => Icons.local_mall_outlined,
        _ => Icons.grid_view_rounded,
      };

  void _openCart(BuildContext context) async {
    final done = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => CartScreen(cart: cart)));
    if (done == true) {
      setState(() => cart.clear());
      if (mounted) Navigator.pop(context);
    }
  }
}

class ProductVisual extends StatelessWidget {
  final Product product;
  const ProductVisual({super.key, required this.product});
  @override
  Widget build(BuildContext context) {
    if (product.imagePath != null && File(product.imagePath!).existsSync()) {
      return ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.file(File(product.imagePath!), fit: BoxFit.cover, width: double.infinity));
    }
    final icon = switch (product.iconName) {
      'shower' => Icons.shower_outlined,
      'timer' => Icons.timer_outlined,
      'infinity' => Icons.all_inclusive,
      'mug' => Icons.local_cafe_outlined,
      'camera' => Icons.camera_alt_outlined,
      'treat' => Icons.pets,
      'person' => Icons.person_outline,
      'scissors' => Icons.content_cut,
      'sticker' => Icons.auto_awesome_outlined,
      _ => Icons.star_outline,
    };
    return Container(
      decoration: BoxDecoration(color: const Color(0xFFFFEEF5), borderRadius: BorderRadius.circular(16)),
      alignment: Alignment.center,
      child: Icon(icon, size: 64, color: deepPink),
    );
  }
}

class CartScreen extends StatefulWidget {
  final Map<String, int> cart;
  const CartScreen({super.key, required this.cart});
  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  double get total {
    double t = 0;
    for (final e in widget.cart.entries) {
      final p = Store.instance.products.where((x) => x.id == e.key).firstOrNull;
      if (p != null) t += p.price * e.value;
    }
    return t;
  }

  @override
  Widget build(BuildContext context) {
    final items = widget.cart.entries.where((e) => e.value > 0).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('سلة الطلب')),
      body: Column(
        children: [
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.all(20),
              itemCount: items.length,
              separatorBuilder: (_, __) => const Divider(),
              itemBuilder: (_, i) {
                final e = items[i];
                final p = Store.instance.products.where((x) => x.id == e.key).first;
                return ListTile(
                  leading: SizedBox(width: 70, height: 70, child: ProductVisual(product: p)),
                  title: Text(p.nameAr, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('${p.price.toStringAsFixed(0)} ريال'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(onPressed: () => setState(() => widget.cart[p.id] = (widget.cart[p.id]! - 1).clamp(0, 99)), icon: const Icon(Icons.remove_circle_outline)),
                      Text('${widget.cart[p.id]}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      IconButton(onPressed: () => setState(() => widget.cart[p.id] = (widget.cart[p.id]! + 1).clamp(0, 99)), icon: const Icon(Icons.add_circle_outline)),
                    ],
                  ),
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.all(22),
            decoration: const BoxDecoration(color: Colors.white, boxShadow: [BoxShadow(blurRadius: 12, color: Color(0x22000000))]),
            child: Row(
              children: [
                Expanded(child: Text('الإجمالي  ${total.toStringAsFixed(2)} ريال', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900))),
                SizedBox(
                  width: 260,
                  height: 62,
                  child: FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: deepPink),
                    onPressed: items.isEmpty ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => CheckoutScreen(cart: widget.cart, total: total))),
                    child: const Text('إتمام الطلب والدفع', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}

class CheckoutScreen extends StatefulWidget {
  final Map<String, int> cart;
  final double total;
  const CheckoutScreen({super.key, required this.cart, required this.total});
  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  bool busy = false;
  String status = '';

  Future<void> pay() async {
    setState(() {
      busy = true;
      status = 'جاري الاتصال بجهاز مدى...';
    });

    final settings = Store.instance.settings;
    final connected = await NamiService(settings).testConnection();
    if (!connected) {
      setState(() {
        busy = false;
        status = 'تعذر الاتصال بجهاز مدى. راجع IP والمنفذ.';
      });
      return;
    }

    if (settings.demoPayment) {
      setState(() => status = 'وضع تجريبي: محاكاة نجاح الدفع...');
      await Future.delayed(const Duration(seconds: 1));
      await completeSale(paymentRef: 'DEMO-${DateTime.now().millisecondsSinceEpoch}');
      return;
    }

    setState(() => status = 'جاري إرسال ${widget.total.toStringAsFixed(2)} ريال إلى جهاز مدى...');
    final result = await DirectNamiTcp(settings).sendPurchase(widget.total);

    if (result['ok'] == true) {
      await completeSale(paymentRef: '${result['ecrRef'] ?? ''}');
      return;
    }

    setState(() {
      busy = false;
      status = 'فشل الدفع (${result['stage']}): ${result['message']}';
    });
  }

  Future<void> completeSale({required String paymentRef}) async {
    final saleItems = <SaleItem>[];
    for (final e in widget.cart.entries) {
      if (e.value <= 0) continue;
      final p = Store.instance.products.where((x) => x.id == e.key).first;
      saleItems.add(SaleItem(p.id, p.nameAr, e.value, p.price));
    }
    final sale = Sale(
      id: (Store.instance.sales.length + 1).toString().padLeft(6, '0'),
      createdAt: DateTime.now(),
      items: saleItems,
      total: widget.total,
      paymentStatus: 'APPROVED',
      paymentRef: paymentRef,
    );
    await Store.instance.addSale(sale);

    final receipt = ReceiptBuilder.build(sale);
    final printed = await UsbPrinter.printReceipt(receipt);
    sale.printed = printed;
    await Store.instance.save();

    if (!mounted) return;
    setState(() { busy = false; status = printed ? 'تم الدفع والطباعة بنجاح' : 'تم الدفع. لم تتم الطباعة بعد.'; });
    await Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => SuccessScreen(sale: sale)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تأكيد الدفع')),
      body: GridPaper(
        child: Center(
          child: SizedBox(
            width: 620,
            child: Card(
              elevation: 0,
              color: Colors.white.withOpacity(.95),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28), side: BorderSide(color: gridPink)),
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Image.asset('assets/kitty_mascot.jpg', height: 180),
                    Text('${widget.total.toStringAsFixed(2)} ريال', style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w900, color: deepPink)),
                    const SizedBox(height: 8),
                    const Text('اضغط ادفع لإرسال المبلغ إلى جهاز مدى', style: TextStyle(fontSize: 20)),
                    const SizedBox(height: 22),
                    if (busy) const CircularProgressIndicator(),
                    if (status.isNotEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(status, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold))),
                    SizedBox(
                      width: double.infinity,
                      height: 62,
                      child: FilledButton.icon(
                        onPressed: busy ? null : pay,
                        icon: const Icon(Icons.credit_card),
                        label: Text(Store.instance.settings.demoPayment ? 'ادفع - وضع تجريبي' : 'ادفع الآن', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class SuccessScreen extends StatelessWidget {
  final Sale sale;
  const SuccessScreen({super.key, required this.sale});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GridPaper(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.check_circle, color: deepPink, size: 130),
              const Text('تمت العملية بنجاح!', style: TextStyle(fontSize: 42, color: deepPink, fontWeight: FontWeight.w900)),
              Image.asset('assets/kitty_mascot.jpg', height: 250),
              Text('شكراً لك ♥\n${sale.printed ? 'تمت طباعة الفاتورة' : 'يمكن طباعة الفاتورة من الإدارة'}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 22)),
              const SizedBox(height: 20),
              FilledButton(onPressed: () => Navigator.popUntil(context, (r) => r.isFirst), child: const Text('العودة للبداية')),
            ],
          ),
        ),
      ),
    );
  }
}

class NamiService {
  final AppSettings s;
  NamiService(this.s);

  Future<bool> testConnection() async {
    try {
      final socket = await Socket.connect(s.namiIp, s.namiPort, timeout: const Duration(seconds: 4));
      socket.destroy();
      return true;
    } catch (_) {
      return false;
    }
  }

  String nextEcrRef() {
    final n = (DateTime.now().millisecondsSinceEpoch ~/ 1000) % 1000000;
    return n.toString().padLeft(6, '0');
  }

  String signature(String ecrRef) => sha256.convert(utf8.encode('$ecrRef${s.terminalId}')).toString();

  String purchasePayload(double amount) {
    final now = DateTime.now();
    String two(int n) => n.toString().padLeft(2, '0');
    final stamp = '${two(now.day)}${two(now.month)}${two(now.year % 100)}${two(now.hour)}${two(now.minute)}${two(now.second)}';
    final minor = (amount * 100).round();
    final ref = nextEcrRef();
    return '$stamp;$minor;0;${s.terminalId}$ref!';
  }
}


class RawEcrResult {
  final bool ok;
  final String message;
  final List<int> response;
  RawEcrResult(this.ok, this.message, this.response);

  String get responseHex => response.map((b) => b.toRadixString(16).padLeft(2, '0')).join(' ');
  String get responseAscii {
    try {
      return latin1.decode(response, allowInvalid: true);
    } catch (_) {
      return '';
    }
  }
}

/// Experimental adapter based on:
/// - Nami's documented request bodies / transaction type codes
/// - the public Pine Labs wired socket packet envelope (0x1000 / 0x0997 / length / 0xFF)
/// This is intentionally isolated behind an explicit test toggle.

class ExperimentalEcrPage extends StatefulWidget {
  const ExperimentalEcrPage({super.key});

  @override
  State<ExperimentalEcrPage> createState() => _ExperimentalEcrPageState();
}

class _ExperimentalEcrPageState extends State<ExperimentalEcrPage> {
  bool busy = false;
  String output = 'ابدأ بـ REGISTER فقط. إذا رد الجهاز بدون Busy، جرّب 1 ريال.';

  Future<void> runRegister() async {
    setState(() { busy = true; output = 'جاري REGISTER على نفس بروتوكول الاختبار الذي رد عليه الجهاز سابقاً...'; });
    final r = await DirectNamiTcp(Store.instance.settings).registerOnly();
    if (!mounted) return;
    setState(() {
      busy = false;
      output = '${r['message']}\n\nHEX:\n${r['rawHex'] ?? ''}';
    });
  }


  Future<void> runDiscoverFraming() async {
    setState(() { busy = true; output = 'جاري اكتشاف framing باستخدام REGISTER فقط — بدون أي مبلغ...'; });
    final r = await DirectNamiTcp(Store.instance.settings).discoverFraming();
    if (!mounted) return;
    setState(() {
      busy = false;
      output = 'FRAMING: ${r['frame'] ?? 'غير مكتشف'}\n'
          'PAYLOAD: ${r['payload'] ?? ''}\n'
          'MESSAGE: ${r['message'] ?? ''}\n\n'
          'ASCII:\n${r['rawAscii'] ?? ''}\n\n'
          'HEX:\n${r['rawHex'] ?? ''}';
    });
  }

  Future<void> runDiscoverCrn() async {
    setState(() { busy = true; output = 'جاري استخراج CRN من ردود REGISTER فقط — بدون brute force وبدون مبلغ...'; });
    final r = await DirectNamiTcp(Store.instance.settings).discoverCrn();
    if (!mounted) return;
    final found = (r['crn'] ?? '').toString();
    if (found.isNotEmpty) {
      final s = Store.instance.settings;
      s.crn = found;
      await Store.instance.save();
    }
    if (!mounted) return;
    setState(() {
      busy = false;
      output = 'CRN: ${found.isEmpty ? 'لم يظهر في رد الجهاز' : found}\n'
          'FRAMING: ${r['frame'] ?? ''}\n'
          'MESSAGE: ${r['message'] ?? ''}\n\n'
          'ASCII:\n${r['rawAscii'] ?? ''}\n\n'
          'HEX:\n${r['rawHex'] ?? ''}';
    });
  }

  Future<void> runOneRiyal() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('اختبار 1 ريال'),
        content: const Text('هذا الزر قد يرسل عملية شراء فعلية بقيمة 1.00 ريال إلى جهاز مدى إذا تقبّل الجهاز البروتوكول التجريبي.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('ابدأ اختبار 1 ريال')),
        ],
      ),
    );
    if (ok != true) return;

    setState(() { busy = true; output = 'جاري REGISTER → SESSION → PURCHASE 1 SAR على اتصال واحد...'; });
    final r = await DirectNamiTcp(Store.instance.settings).sendPurchase(1.0);
    if (!mounted) return;
    setState(() {
      busy = false;
      output = 'STAGE: ${r['stage'] ?? ''}\n'
          'AMOUNT MINOR: ${r['amountMinor'] ?? 100} (100 = 1.00 SAR)\n'
          'CRN: ${r['crn'] ?? Store.instance.settings.crn}\n'
          'PURCHASE DATA: ${r['purchaseData'] ?? ''}\n'
          'REGISTER: ${r['registerMessage'] ?? ''}\n'
          'SESSION: ${r['sessionMessage'] ?? ''}\n'
          'MESSAGE: ${r['message'] ?? ''}\n\n'
          'HEX:\n${r['rawHex'] ?? ''}';
    });
  }


  Future<void> runFlutterWireProbe() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('اختبار صيغة Flutter الرسمية - 1 ريال'),
        content: const Text(
          'اختبار تشخيصي فقط. يستخدم صيغة الطلب الموثقة في Nami Flutter '
          'ويحاول تمريرها عبر نفس TCP framing الذي ثبت أن جهازك يرد عليه. '
          'قد يفتح عملية دفع فعلية بقيمة 1.00 ريال.'
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('ابدأ'),
          ),
        ],
      ),
    );
    if (ok != true) return;

    setState(() {
      busy = true;
      output = 'جاري اختبار صيغة Nami Flutter: txnType 6 + HEX request + signature...';
    });

    final r = await DirectNamiTcp(Store.instance.settings)
        .sendPurchaseFlutterWireProbe(1.0);

    if (!mounted) return;
    setState(() {
      busy = false;
      output = 'STAGE: ${r['stage'] ?? ''}\n'
          'CRN: ${r['crn'] ?? ''}\n'
          'ECR REF: ${r['ecrRef'] ?? ''}\n'
          'REQUEST: ${r['reqData'] ?? ''}\n'
          'HEX REQUEST: ${r['hexReqData'] ?? ''}\n'
          'WIRE CSV: ${r['wireCsv'] ?? ''}\n'
          'MESSAGE: ${r['message'] ?? ''}\n\n'
          'RAW HEX:\n${r['rawHex'] ?? ''}';
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = Store.instance.settings;
    return Scaffold(
      appBar: AppBar(title: const Text('Nami ECR - اختبار تجريبي')),
      body: ListView(
        padding: const EdgeInsets.all(22),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.lan, color: deepPink),
              title: Text('${s.namiIp}:${s.namiPort}'),
              subtitle: Text('Terminal ID: ${s.terminalId}'),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 56,
            child: FilledButton.icon(
              onPressed: busy ? null : runDiscoverFraming,
              icon: const Icon(Icons.radar),
              label: const Text('0) اكتشاف framing تلقائياً - REGISTER فقط'),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 56,
            child: OutlinedButton.icon(
              onPressed: busy ? null : runDiscoverCrn,
              icon: const Icon(Icons.manage_search),
              label: const Text('اكتشاف CRN من رد جهاز Nami'),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 56,
            child: FilledButton.icon(
              onPressed: busy ? null : runRegister,
              icon: const Icon(Icons.link),
              label: const Text('1) اختبار REGISTER فقط - بدون مبلغ'),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 56,
            child: OutlinedButton.icon(
              onPressed: busy ? null : runOneRiyal,
              icon: const Icon(Icons.credit_card),
              label: const Text('2) اختبار دفع 1 ريال - اتصال واحد'),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 56,
            child: FilledButton.icon(
              onPressed: busy ? null : runFlutterWireProbe,
              icon: const Icon(Icons.science_outlined),
              label: const Text('3) اختبار Nami Flutter الرسمي - 1 ريال'),
            ),
          ),
          if (busy) const Padding(padding: EdgeInsets.all(18), child: LinearProgressIndicator()),
          const SizedBox(height: 18),
          SelectableText(output, style: const TextStyle(fontFamily: 'monospace')),
        ],
      ),
    );
  }
}



class DirectNamiTcp {
  final AppSettings s;
  DirectNamiTcp(this.s);

  String _stamp() {
    final d = DateTime.now();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(d.day)}${two(d.month)}${two(d.year % 100)}${two(d.hour)}${two(d.minute)}${two(d.second)}';
  }

  String _ref6() {
    final n = (DateTime.now().millisecondsSinceEpoch ~/ 1000) % 1000000;
    return n.toString().padLeft(6, '0');
  }

  String _signature(String ref6) =>
      sha256.convert(utf8.encode('$ref6${s.terminalId}')).toString();

  List<int> _frame(String csv) {
    final data = latin1.encode(csv);
    final len = data.length;
    return <int>[0x10,0x00,0x09,0x97,(len>>8)&0xff,len&0xff,...data,0xff];
  }


  List<int> _wrapProbe(String kind, String payload) {
    final data = latin1.encode(payload);
    switch (kind) {
      case 'nami_current':
        return _frame(payload);
      case 'nami_current_eot':
        final len = data.length;
        return <int>[0x10,0x00,0x09,0x97,(len>>8)&0xff,len&0xff,...data,0x04];
      case 'raw':
        return data;
      case 'lf':
        return <int>[...data,0x0a];
      case 'crlf':
        return <int>[...data,0x0d,0x0a];
      case 'nul':
        return <int>[...data,0x00];
      case 'stx_etx':
        return <int>[0x02,...data,0x03];
      case 'stx_etx_lrc':
        final body = <int>[...data,0x03];
        var lrc = 0;
        for (final b in body) { lrc ^= b; }
        return <int>[0x02,...body,lrc & 0xff];
      case 'len2_be':
        return <int>[(data.length>>8)&0xff,data.length&0xff,...data];
      case 'len2_le':
        return <int>[data.length&0xff,(data.length>>8)&0xff,...data];
      case 'len4_ascii':
        final h = data.length.toString().padLeft(4,'0');
        return <int>[...latin1.encode(h),...data];
      default:
        return data;
    }
  }

  String _rawAscii(List<int> raw) {
    try { return latin1.decode(raw, allowInvalid:true); }
    catch (_) { return ''; }
  }

  String _rawHex(List<int> raw) =>
      raw.map((b)=>b.toRadixString(16).padLeft(2,'0')).join(' ');

  Future<List<int>> _probeExchange(List<int> tx,
      {Duration timeout = const Duration(seconds: 3)}) async {
    Socket? socket;
    StreamSubscription<List<int>>? sub;
    Timer? quietTimer;
    Timer? hardTimer;
    final bytes = <int>[];
    final c = Completer<List<int>>();
    try {
      socket = await Socket.connect(s.namiIp, s.namiPort,
          timeout: const Duration(seconds: 4));
      void finish() {
        if (!c.isCompleted) c.complete(List<int>.from(bytes));
      }
      sub = socket.listen((data) {
        bytes.addAll(data);
        quietTimer?.cancel();
        quietTimer = Timer(const Duration(milliseconds: 500), finish);
      }, onError: (_) => finish(), onDone: finish);
      socket.add(tx);
      await socket.flush();
      hardTimer = Timer(timeout, finish);
      return await c.future;
    } finally {
      quietTimer?.cancel();
      hardTimer?.cancel();
      try { await sub?.cancel(); } catch (_) {}
      try { socket?.destroy(); } catch (_) {}
    }
  }

  List<String> _registerProbePayloads() => <String>[
    '17,${_stamp()};${s.terminalId}!',
    'REGISTER',
    'REGISTER|${s.terminalId}',
    'REGISTER,${s.terminalId}',
    'REGISTER:${s.terminalId}',
  ];

  List<String> _frameKinds() => const <String>[
    'nami_current','nami_current_eot','raw','lf','crlf','nul',
    'stx_etx','stx_etx_lrc','len2_be','len2_le','len4_ascii'
  ];

  Set<String> _extractCrnCandidates(List<int> raw) {
    final out = <String>{};
    final text = _rawAscii(raw);
    final re = RegExp(r'(?<!\d)\d{8}(?!\d)');
    for (final m in re.allMatches(text)) {
      final v = m.group(0)!;
      if (v != s.terminalId) out.add(v);
    }
    return out;
  }

  Future<Map<String,dynamic>> discoverFraming() async {
    final attempts = <String>[];
    for (final payload in _registerProbePayloads()) {
      for (final kind in _frameKinds()) {
        try {
          final tx = _wrapProbe(kind, payload);
          final rx = await _probeExchange(tx);
          attempts.add('$kind / $payload => ${rx.length} bytes');
          if (rx.isNotEmpty) {
            return <String,dynamic>{
              'ok': true,
              'frame': kind,
              'payload': payload,
              'message': _ascii(rx),
              'rawAscii': _rawAscii(rx),
              'rawHex': _rawHex(rx),
              'crnCandidates': _extractCrnCandidates(rx).toList(),
            };
          }
        } catch (e) {
          attempts.add('$kind / $payload => $e');
        }
      }
    }
    return <String,dynamic>{
      'ok': false,
      'frame': '',
      'payload': '',
      'message': 'No response from safe REGISTER probes',
      'rawAscii': attempts.join('\n'),
      'rawHex': '',
    };
  }

  Future<Map<String,dynamic>> discoverCrn() async {
    final first = await discoverFraming();
    final candidates = <String>{};
    final list = first['crnCandidates'];
    if (list is List) {
      for (final x in list) {
        final v = x.toString();
        if (RegExp(r'^\d{8}$').hasMatch(v) && v != s.terminalId) {
          candidates.add(v);
        }
      }
    }
    return <String,dynamic>{
      ...first,
      'crn': candidates.isEmpty ? '' : candidates.first,
      'crnCandidates': candidates.toList(),
    };
  }

  Future<List<int>> _exchange(Socket socket, String csv,
      {Duration timeout = const Duration(seconds: 12)}) async {
    final bytes = <int>[];
    final c = Completer<List<int>>();
    late StreamSubscription<List<int>> sub;
    Timer? timer;

    sub = socket.listen((data) {
      bytes.addAll(data);
      if ((data.contains(0xff) || data.contains(0x04)) && !c.isCompleted) {
        c.complete(List<int>.from(bytes));
      }
    }, onError: (e) {
      if (!c.isCompleted) c.completeError(e);
    }, onDone: () {
      if (!c.isCompleted) c.complete(List<int>.from(bytes));
    });

    socket.add(_frame(csv));
    await socket.flush();

    timer = Timer(timeout, () {
      if (!c.isCompleted) c.complete(List<int>.from(bytes));
    });

    final result = await c.future;
    timer?.cancel();
    await sub.cancel();
    return result;
  }

  String _ascii(List<int> raw) {
    if (raw.isEmpty) return '';
    var body = List<int>.from(raw);
    if (body.length >= 7 && body[0] == 0x10 && body[1] == 0x00) {
      body = body.sublist(6);
    }
    while (body.isNotEmpty && (body.last == 0xff || body.last == 0x04)) {
      body.removeLast();
    }
    try { return latin1.decode(body, allowInvalid: true).trim(); }
    catch (_) { return ''; }
  }

  bool _busy(String m) {
    final x = m.toLowerCase();
    return x.contains('busy') || x.contains('try later');
  }

  bool _approved(String m) {
    final u = m.toUpperCase();
    return u.contains('APPROVED') || u.startsWith('00') || u.contains(',00,') || u.contains('|00|');
  }

  Future<List<int>> _retry(Socket socket, String csv,
      {int retries = 3, Duration timeout = const Duration(seconds: 12)}) async {
    List<int> last = const [];
    for (int i=0; i<retries; i++) {
      last = await _exchange(socket, csv, timeout: timeout);
      if (!_busy(_ascii(last))) return last;
      await Future.delayed(Duration(milliseconds: 1800 + i*700));
    }
    return last;
  }

  Future<Map<String,dynamic>> registerOnly() async {
    Socket? socket;
    try {
      socket = await Socket.connect(s.namiIp, s.namiPort, timeout: const Duration(seconds: 5));
      final raw = await _exchange(socket, '17,${_stamp()};${s.terminalId}!');
      final msg = _ascii(raw);
      return {
        'ok': raw.isNotEmpty && !_busy(msg),
        'stage': 'REGISTER',
        'message': msg.isEmpty ? 'No response' : msg,
        'rawHex': raw.map((b)=>b.toRadixString(16).padLeft(2,'0')).join(' ')
      };
    } catch(e) {
      return {'ok':false,'stage':'REGISTER','message':'$e'};
    } finally {
      try { socket?.destroy(); } catch(_) {}
    }
  }

  Future<Map<String,dynamic>> sendPurchase(double amountSar) async {
    final amountMinor = (amountSar * 100).round();
    final ref6 = _ref6();
    final crn = RegExp(r'^\d{8}$').hasMatch(s.crn.trim()) ? s.crn.trim() : '73154354';
    final ecrRef = '$crn$ref6';
    // Nami documented purchase body: DDMMYYHHMMSS;AmountMinor;0;CRN+Ref6!
    final purchaseData = '${_stamp()};$amountMinor;0;$ecrRef!';
    final sig = _signature(ref6);

    String registerMsg = '';
    String sessionMsg = '';
    List<int> lastRaw = const <int>[];

    // Important: never run two socket readers at once. Each attempt owns exactly
    // one socket and one listener, and a BUSY registration is fully disconnected
    // before retrying. We only advance REGISTER -> SESSION -> PURCHASE after the
    // previous stage has returned a non-BUSY response.
    for (int attempt = 1; attempt <= 3; attempt++) {
      Socket? socket;
      StreamSubscription<List<int>>? sub;
      Completer<List<int>>? pending;
      final rx = <int>[];

      Future<List<int>> sendAndWait(String payload,
          {Duration timeout = const Duration(seconds: 15)}) async {
        rx.clear();
        final c = Completer<List<int>>();
        pending = c;
        socket!.add(_frame(payload));
        await socket!.flush();
        try {
          return await c.future.timeout(timeout,
              onTimeout: () => List<int>.from(rx));
        } finally {
          if (identical(pending, c)) pending = null;
        }
      }

      try {
        socket = await Socket.connect(s.namiIp, s.namiPort,
            timeout: const Duration(seconds: 5));
        sub = socket.listen((data) {
          if (pending == null) return;
          rx.addAll(data);
          if ((data.contains(0x03) || data.contains(0xff) || data.contains(0x04)) &&
              !(pending?.isCompleted ?? true)) {
            pending!.complete(List<int>.from(rx));
          }
        }, onError: (Object e) {
          if (!(pending?.isCompleted ?? true)) pending!.completeError(e);
        }, onDone: () {
          if (!(pending?.isCompleted ?? true)) pending!.complete(List<int>.from(rx));
        });

        // 17 = REGISTER. This terminal may report BUSY while still accepting the next ECR stage.
        lastRaw = await sendAndWait('17,${_stamp()};${s.terminalId}!');
        registerMsg = _ascii(lastRaw);
        // V16 compatibility mode: BUSY is recorded but does not stop the flow.
        // Earlier testing showed this terminal can open the mada payment screen
        // even when REGISTER/SESSION return "Terminal Is Busy".
        if (lastRaw.isEmpty) {
          return <String,dynamic>{'ok':false,'stage':'REGISTER','message':'No REGISTER response','rawHex':''};
        }

        await Future.delayed(const Duration(milliseconds: 500));

        // 18 = SESSION. Again, never advance on BUSY.
        lastRaw = await sendAndWait('18,${_stamp()};${s.terminalId}!');
        sessionMsg = _ascii(lastRaw);
        // Same compatibility behavior for SESSION: continue to PURCHASE on BUSY.
        if (lastRaw.isEmpty) {
          return <String,dynamic>{'ok':false,'stage':'SESSION','message':'No SESSION response','registerMessage':registerMsg,'rawHex':''};
        }

        await Future.delayed(const Duration(milliseconds: 500));

        // 0 = PURCHASE. Signature = SHA256(ref6 + TerminalID).
        // Keep the same proven outer envelope; only one reader is active.
        lastRaw = await sendAndWait('0,$purchaseData,$sig',
            timeout: const Duration(seconds: 90));
        final msg = _ascii(lastRaw);
        return <String,dynamic>{
          'ok': _approved(msg),
          'stage': 'PURCHASE',
          'message': msg.isEmpty ? 'Purchase sent; no final response yet' : msg,
          'amountMinor': amountMinor,
          'purchaseData': purchaseData,
          'ecrRef': ecrRef,
          'crn': crn,
          'registerMessage': registerMsg,
          'sessionMessage': sessionMsg,
          'rawHex': _rawHex(lastRaw),
        };
      } catch (e) {
        if (attempt == 3) {
          return <String,dynamic>{'ok':false,'stage':'TCP','message':'$e','registerMessage':registerMsg,'sessionMessage':sessionMsg};
        }
        await Future.delayed(Duration(seconds: 2 + attempt));
      } finally {
        try { await sub?.cancel(); } catch (_) {}
        try { socket?.destroy(); } catch (_) {}
      }
    }
    return <String,dynamic>{'ok':false,'stage':'TCP','message':'Unexpected end'};
  }


  /// Diagnostic compatibility probe based on Nami's public Flutter documentation:
  /// - CRN is 8 digits
  /// - ECR ref = CRN + six-digit unique number
  /// - request = DDMMYYHHMMSS;amountMinor;print!;ecrRef!;
  /// - request is converted to HEX
  /// - txnType 6 is the documented end-to-end Flutter payment flow
  /// - signature = SHA256(ref6 + TerminalID)
  ///
  /// IMPORTANT: the official ecrlib package owns the real transport envelope.
  /// This method deliberately keeps the already-working outer TCP envelope only
  /// as a diagnostic compatibility test; it is not a replacement for ecrlib.
  Future<Map<String,dynamic>> sendPurchaseFlutterWireProbe(double amountSar) async {
    final crn = s.crn.trim();
    if (!RegExp(r'^\d{8}$').hasMatch(crn)) {
      return <String,dynamic>{
        'ok': false,
        'stage': 'CRN',
        'message': 'CRN must be exactly 8 digits',
        'crn': crn,
      };
    }

    final amountMinor = (amountSar * 100).round();
    final ref6 = _ref6();
    final ecrRef = '$crn$ref6';
    final reqData = '${_stamp()};$amountMinor;0!;$ecrRef!;';
    final hexReqData = latin1
        .encode(reqData)
        .map((b) => b.toRadixString(16).padLeft(2, '0'))
        .join()
        .toUpperCase();
    final sig = _signature(ref6);

    // Nami Flutter docs pass txnType separately to doTransaction().
    // The public raw TCP framing is not documented, so this CSV is only a probe.
    final wireCsv = '6,$hexReqData,$sig';

    Socket? socket;
    try {
      socket = await Socket.connect(
        s.namiIp,
        s.namiPort,
        timeout: const Duration(seconds: 5),
      );
      socket.setOption(SocketOption.tcpNoDelay, true);

      final raw = await _exchange(
        socket,
        wireCsv,
        timeout: const Duration(seconds: 90),
      );
      final msg = _ascii(raw);

      return <String,dynamic>{
        'ok': _approved(msg),
        'stage': 'FLUTTER_WIRE_PROBE',
        'message': msg.isEmpty ? 'No response' : msg,
        'crn': crn,
        'amountMinor': amountMinor,
        'ecrRef': ecrRef,
        'reqData': reqData,
        'hexReqData': hexReqData,
        'wireCsv': wireCsv,
        'rawHex': _rawHex(raw),
      };
    } catch (e) {
      return <String,dynamic>{
        'ok': false,
        'stage': 'TCP',
        'message': '$e',
        'crn': crn,
        'ecrRef': ecrRef,
        'reqData': reqData,
        'hexReqData': hexReqData,
        'wireCsv': wireCsv,
      };
    } finally {
      try { socket?.destroy(); } catch (_) {}
    }
  }

}

class ReceiptBuilder {
  static String build(Sale sale) {
    final b = StringBuffer();
    b.writeln('KITTY HERE');
    b.writeln('شكراً لزيارتكم');
    b.writeln('------------------------------');
    b.writeln('رقم الطلب: ${sale.id}');
    b.writeln('التاريخ: ${sale.createdAt}');
    b.writeln('------------------------------');
    for (final i in sale.items) {
      b.writeln('${i.name}  x${i.qty}   ${(i.qty * i.unitPrice).toStringAsFixed(2)}');
    }
    b.writeln('------------------------------');
    b.writeln('الإجمالي: ${sale.total.toStringAsFixed(2)} ريال');
    b.writeln('الدفع: ${sale.paymentStatus}');
    b.writeln('المرجع: ${sale.paymentRef}');
    b.writeln('');
    b.writeln('نتمنى لكم يوماً سعيداً ♥');
    return b.toString();
  }
}

class UsbPrinter {
  static const channel = MethodChannel('kittyhere/printer');

  static Future<bool> printReceipt(String text) async {
    try {
      final r = await channel.invokeMethod<String>('printReceipt', {'text': text});
      return r == 'printed';
    } catch (_) {
      return false;
    }
  }

  static Future<List<Map<String, dynamic>>> devices() async {
    try {
      final r = await channel.invokeMethod<List<dynamic>>('listUsbDevices') ?? [];
      return r.map((e) => Map<String, dynamic>.from(e)).toList();
    } catch (_) {
      return [];
    }
  }
}

class AdminHome extends StatefulWidget {
  const AdminHome({super.key});
  @override
  State<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  int tab = 0;
  @override
  Widget build(BuildContext context) {
    final pages = [const DashboardPage(), const ProductsAdmin(), const SalesPage(), const ManualInvoicePage(), const SettingsPage()];
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة تحكم Kitty Here')),
      body: Row(
        children: [
          NavigationRail(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            labelType: NavigationRailLabelType.all,
            destinations: const [
              NavigationRailDestination(icon: Icon(Icons.dashboard_outlined), label: Text('الرئيسية')),
              NavigationRailDestination(icon: Icon(Icons.inventory_2_outlined), label: Text('المنتجات')),
              NavigationRailDestination(icon: Icon(Icons.bar_chart), label: Text('المبيعات')),
              NavigationRailDestination(icon: Icon(Icons.receipt_long), label: Text('فاتورة')),
              NavigationRailDestination(icon: Icon(Icons.settings), label: Text('الإعدادات')),
            ],
          ),
          const VerticalDivider(width: 1),
          Expanded(child: pages[tab]),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: Store.instance.rev,
      builder: (_, __, ___) {
        final now = DateTime.now();
        final today = Store.instance.sales.where((s) => s.createdAt.year == now.year && s.createdAt.month == now.month && s.createdAt.day == now.day).toList();
        final total = today.fold<double>(0, (a, b) => a + b.total);
        final avg = today.isEmpty ? 0 : total / today.length;
        final counts = <String, int>{};
        for (final s in today) for (final i in s.items) counts[i.name] = (counts[i.name] ?? 0) + i.qty;
        String top = '-';
        if (counts.isNotEmpty) top = counts.entries.reduce((a, b) => a.value >= b.value ? a : b).key;
        return Padding(
          padding: const EdgeInsets.all(22),
          child: ListView(
            children: [
              const Text('ملخص اليوم', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
              const SizedBox(height: 14),
              Wrap(
                spacing: 14,
                runSpacing: 14,
                children: [
                  StatCard('إجمالي المبيعات', '${total.toStringAsFixed(2)} ريال', Icons.payments_outlined),
                  StatCard('عدد الطلبات', '${today.length}', Icons.receipt_long_outlined),
                  StatCard('متوسط الطلب', '${avg.toStringAsFixed(2)} ريال', Icons.analytics_outlined),
                  StatCard('الأكثر مبيعاً', top, Icons.trending_up),
                ],
              ),
              const SizedBox(height: 24),
              const Text('آخر الطلبات', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              ...Store.instance.sales.take(8).map((s) => ListTile(
                    leading: const CircleAvatar(backgroundColor: pink, child: Icon(Icons.check, color: Colors.white)),
                    title: Text('طلب #${s.id} - ${s.total.toStringAsFixed(2)} ريال'),
                    subtitle: Text(s.createdAt.toString()),
                    trailing: Text(s.printed ? 'مطبوعة' : 'غير مطبوعة'),
                  ))
            ],
          ),
        );
      },
    );
  }
}

class StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  const StatCard(this.title, this.value, this.icon, {super.key});
  @override
  Widget build(BuildContext context) => SizedBox(
        width: 250,
        child: Card(
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(icon, color: deepPink, size: 34),
              const SizedBox(height: 10),
              Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
              Text(title),
            ]),
          ),
        ),
      );
}

class ProductsAdmin extends StatelessWidget {
  const ProductsAdmin({super.key});
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: Store.instance.rev,
      builder: (_, __, ___) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Row(children: [
              const Expanded(child: Text('إدارة المنتجات والمخزون', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900))),
              FilledButton.icon(onPressed: () => _edit(context, null), icon: const Icon(Icons.add), label: const Text('إضافة منتج')),
            ]),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.separated(
                itemCount: Store.instance.products.length,
                separatorBuilder: (_, __) => const Divider(),
                itemBuilder: (_, i) {
                  final p = Store.instance.products[i];
                  return ListTile(
                    leading: SizedBox(width: 62, height: 62, child: ProductVisual(product: p)),
                    title: Text(p.nameAr, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('${p.category} • ${p.price.toStringAsFixed(2)} ريال • ${p.stock < 0 ? 'غير محدود' : 'المخزون ${p.stock}'}'),
                    trailing: Wrap(spacing: 4, children: [
                      Switch(value: p.enabled, onChanged: (v) async { p.enabled = v; await Store.instance.save(); }),
                      IconButton(icon: const Icon(Icons.edit), onPressed: () => _edit(context, p)),
                      IconButton(icon: const Icon(Icons.delete_outline, color: Colors.red), onPressed: () async {
                        Store.instance.products.remove(p);
                        await Store.instance.save();
                      }),
                    ]),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _edit(BuildContext context, Product? old) async {
    final name = TextEditingController(text: old?.nameAr ?? '');
    final en = TextEditingController(text: old?.nameEn ?? '');
    final price = TextEditingController(text: old?.price.toString() ?? '');
    final stock = TextEditingController(text: old == null || old.stock < 0 ? '' : old.stock.toString());
    String category = old?.category ?? 'منتجات';
    String? imagePath = old?.imagePath;
    final picker = ImagePicker();

    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text(old == null ? 'إضافة منتج' : 'تعديل المنتج'),
          content: SizedBox(
            width: 520,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم المنتج')),
                  TextField(controller: en, decoration: const InputDecoration(labelText: 'الاسم الإنجليزي')),
                  TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'السعر')),
                  TextField(controller: stock, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'المخزون (اتركه فارغ = غير محدود)')),
                  DropdownButtonFormField<String>(
                    value: category,
                    items: ['تذاكر', 'إضافات', 'خدمات', 'منتجات'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                    onChanged: (v) => setLocal(() => category = v ?? category),
                    decoration: const InputDecoration(labelText: 'التصنيف'),
                  ),
                  const SizedBox(height: 12),
                  if (imagePath != null && File(imagePath!).existsSync()) Image.file(File(imagePath!), height: 120),
                  OutlinedButton.icon(
                    onPressed: () async {
                      final x = await picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
                      if (x != null) setLocal(() => imagePath = x.path);
                    },
                    icon: const Icon(Icons.image_outlined),
                    label: const Text('اختيار صورة المنتج'),
                  )
                ],
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
            FilledButton(
              onPressed: () async {
                final p = old ?? Product(id: 'p${DateTime.now().millisecondsSinceEpoch}', nameAr: '', nameEn: '', price: 0, category: category);
                p.nameAr = name.text.trim();
                p.nameEn = en.text.trim();
                p.price = double.tryParse(price.text) ?? 0;
                p.stock = stock.text.trim().isEmpty ? -1 : (int.tryParse(stock.text) ?? 0);
                p.category = category;
                p.imagePath = imagePath;
                if (old == null) Store.instance.products.add(p);
                await Store.instance.save();
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('حفظ'),
            )
          ],
        ),
      ),
    );
  }
}

class SalesPage extends StatelessWidget {
  const SalesPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: Store.instance.rev,
      builder: (_, __, ___) => ListView.builder(
        padding: const EdgeInsets.all(20),
        itemCount: Store.instance.sales.length,
        itemBuilder: (_, i) {
          final s = Store.instance.sales[i];
          return Card(
            child: ExpansionTile(
              title: Text('طلب #${s.id} — ${s.total.toStringAsFixed(2)} ريال'),
              subtitle: Text('${s.createdAt} • ${s.paymentStatus}'),
              trailing: IconButton(
                icon: const Icon(Icons.print),
                onPressed: () async {
                  final ok = await UsbPrinter.printReceipt(ReceiptBuilder.build(s));
                  s.printed = ok;
                  await Store.instance.save();
                },
              ),
              children: s.items.map((x) => ListTile(title: Text(x.name), trailing: Text('${x.qty} × ${x.unitPrice.toStringAsFixed(2)}'))).toList(),
            ),
          );
        },
      ),
    );
  }
}

class ManualInvoicePage extends StatefulWidget {
  const ManualInvoicePage({super.key});
  @override
  State<ManualInvoicePage> createState() => _ManualInvoicePageState();
}

class _ManualInvoicePageState extends State<ManualInvoicePage> {
  final Map<String, int> invoice = {};
  double get total {
    double t = 0;
    for (final e in invoice.entries) {
      final p = Store.instance.products.where((x) => x.id == e.key).firstOrNull;
      if (p != null) t += p.price * e.value;
    }
    return t;
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          const Align(alignment: Alignment.centerRight, child: Text('إصدار فاتورة يدوية', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900))),
          Expanded(
            child: ListView(
              children: Store.instance.products.where((p) => p.enabled).map((p) => CheckboxListTile(
                value: (invoice[p.id] ?? 0) > 0,
                title: Text('${p.nameAr} — ${p.price.toStringAsFixed(2)} ريال'),
                secondary: SizedBox(width: 50, height: 50, child: ProductVisual(product: p)),
                onChanged: (v) => setState(() => invoice[p.id] = v == true ? 1 : 0),
              )).toList(),
            ),
          ),
          Row(
            children: [
              Expanded(child: Text('الإجمالي: ${total.toStringAsFixed(2)} ريال', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900))),
              FilledButton.icon(
                onPressed: total <= 0 ? null : () async {
                  final items = <SaleItem>[];
                  for (final e in invoice.entries.where((e) => e.value > 0)) {
                    final p = Store.instance.products.where((x) => x.id == e.key).first;
                    items.add(SaleItem(p.id, p.nameAr, e.value, p.price));
                  }
                  final s = Sale(id: 'M${DateTime.now().millisecondsSinceEpoch}', createdAt: DateTime.now(), items: items, total: total, paymentStatus: 'MANUAL', paymentRef: 'MANUAL');
                  await Store.instance.addSale(s);
                  final ok = await UsbPrinter.printReceipt(ReceiptBuilder.build(s));
                  s.printed = ok;
                  await Store.instance.save();
                  if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? 'تم إصدار وطباعة الفاتورة' : 'تم إصدار الفاتورة، والطابعة تحتاج إعداد')));
                },
                icon: const Icon(Icons.receipt_long),
                label: const Text('إصدار وطباعة'),
              )
            ],
          )
        ],
      ),
    );
  }
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late TextEditingController ip;
  late TextEditingController port;
  late TextEditingController terminal;
  late TextEditingController crn;
  late TextEditingController remoteApi;
  late TextEditingController remoteToken;
  bool discovering = false;
  String msg = '';

  @override
  void initState() {
    super.initState();
    final s = Store.instance.settings;
    ip = TextEditingController(text: s.namiIp);
    port = TextEditingController(text: '${s.namiPort}');
    terminal = TextEditingController(text: s.terminalId);
    crn = TextEditingController(text: s.crn);
    remoteApi = TextEditingController(text: s.remoteApi);
    remoteToken = TextEditingController(text: s.remoteToken);
  }

  Future<void> discover() async {
    final parts = ip.text.trim().split('.');
    if (parts.length != 4) return;
    setState(() { discovering = true; msg = 'جاري البحث على المنفذ ${port.text}...'; });
    final prefix = '${parts[0]}.${parts[1]}.${parts[2]}';
    final p = int.tryParse(port.text) ?? 1024;
    for (int start = 1; start <= 254; start += 24) {
      final f = <Future<String?>>[];
      for (int i = start; i < start + 24 && i <= 254; i++) {
        final h = '$prefix.$i';
        f.add(() async {
          try {
            final s = await Socket.connect(h, p, timeout: const Duration(milliseconds: 450));
            s.destroy();
            return h;
          } catch (_) { return null; }
        }());
      }
      final r = (await Future.wait(f)).whereType<String>().toList();
      if (r.isNotEmpty) {
        setState(() { ip.text = r.first; msg = 'تم العثور: ${r.first}:$p'; discovering = false; });
        return;
      }
    }
    setState(() { msg = 'لم يتم العثور على جهاز على نفس الشبكة'; discovering = false; });
  }

  Future<void> syncRemote() async {
    if (remoteApi.text.trim().isEmpty) {
      setState(() => msg = 'أدخل رابط السيرفر أولاً');
      return;
    }
    try {
      final u = Uri.parse('${remoteApi.text.trim().replaceAll(RegExp(r'/$'), '')}/health');
      final r = await http.get(u, headers: remoteToken.text.isEmpty ? {} : {'Authorization': 'Bearer ${remoteToken.text.trim()}'}).timeout(const Duration(seconds: 6));
      setState(() => msg = 'السيرفر: ${r.statusCode}');
    } catch (e) {
      setState(() => msg = 'تعذر الاتصال بالسيرفر: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = Store.instance.settings;
    return ListView(
      padding: const EdgeInsets.all(22),
      children: [
        const Text('إعدادات نقاط البيع', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
        TextField(controller: ip, decoration: const InputDecoration(labelText: 'IP جهاز Nami')),
        TextField(controller: port, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'ECR Port')),
        TextField(controller: terminal, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Terminal ID')),
        TextField(controller: crn, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Cash Register Number (8 digits)')),
        SwitchListTile(
          title: const Text('وضع الدفع التجريبي'),
          subtitle: const Text('أوقفه عند إضافة Nami ecrlib الرسمية'),
          value: s.demoPayment,
          onChanged: (v) => setState(() => s.demoPayment = v),
        ),
        SwitchListTile(
          title: const Text('وضع الخدمة الذاتية (Kiosk)'),
          subtitle: const Text('يخفي أزرار النظام ويثبت التطبيق على تجربة الطلب'),
          value: s.kioskMode,
          onChanged: (v) async {
            setState(() => s.kioskMode = v);
            if (v) {
              await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
            } else {
              await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
            }
          },
        ),
        TextField(
          controller: TextEditingController(text: s.adminPin),
          keyboardType: TextInputType.number,
          obscureText: true,
          onChanged: (v) => s.adminPin = v.trim(),
          decoration: const InputDecoration(labelText: 'رمز دخول الإدارة'),
        ),
        Wrap(spacing: 10, children: [
          FilledButton.icon(onPressed: discovering ? null : discover, icon: const Icon(Icons.radar), label: const Text('اكتشاف Nami تلقائياً')),
          OutlinedButton.icon(
            onPressed: () async {
              final temp = AppSettings(namiIp: ip.text.trim(), namiPort: int.tryParse(port.text) ?? 1024);
              final ok = await NamiService(temp).testConnection();
              setState(() => msg = ok ? 'الاتصال بجهاز Nami ناجح' : 'فشل الاتصال');
            },
            icon: const Icon(Icons.wifi_tethering),
            label: const Text('اختبار الاتصال'),
          ),
          OutlinedButton.icon(
            onPressed: () {
              final s = Store.instance.settings;
              s.namiIp = ip.text.trim();
              s.namiPort = int.tryParse(port.text) ?? 1024;
              s.terminalId = terminal.text.trim();
              s.crn = crn.text.trim();
              Navigator.push(context, MaterialPageRoute(builder: (_) => const ExperimentalEcrPage()));
            },
            icon: const Icon(Icons.science_outlined),
            label: const Text('اختبار بروتوكول ECR التجريبي'),
          ),
        ]),
        const Divider(height: 38),
        const Text('الطابعة USB', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const Text('CITyPOS CP-P850N • 80mm • ESC/POS • USB'),
        OutlinedButton.icon(
          onPressed: () async {
            final d = await UsbPrinter.devices();
            setState(() => msg = d.isEmpty ? 'لم يتم اكتشاف طابعة USB' : 'تم اكتشاف ${d.length} جهاز USB');
          },
          icon: const Icon(Icons.print),
          label: const Text('اكتشاف الطابعة'),
        ),
        const Divider(height: 38),
        const Text('التحكم عن بعد', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const Text('البنية جاهزة للمزامنة. تحتاج رابط Backend آمن حتى تعدل المنتجات والمخزون والمبيعات من خارج المحل.'),
        TextField(controller: remoteApi, decoration: const InputDecoration(labelText: 'Remote API URL')),
        TextField(controller: remoteToken, obscureText: true, decoration: const InputDecoration(labelText: 'API Token')),
        OutlinedButton(onPressed: syncRemote, child: const Text('اختبار السيرفر')),
        const SizedBox(height: 18),
        FilledButton(
          onPressed: () async {
            s.namiIp = ip.text.trim();
            s.namiPort = int.tryParse(port.text) ?? 1024;
            s.terminalId = terminal.text.trim();
            s.crn = crn.text.trim();
            s.remoteApi = remoteApi.text.trim();
            s.remoteToken = remoteToken.text.trim();
            await Store.instance.save();
            setState(() => msg = 'تم حفظ الإعدادات');
          },
          child: const Text('حفظ جميع الإعدادات'),
        ),
        if (discovering) const Padding(padding: EdgeInsets.all(12), child: LinearProgressIndicator()),
        if (msg.isNotEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(msg, style: const TextStyle(fontWeight: FontWeight.bold))),
      ],
    );
  }
}
