V5 - LAN permission fix

Changes:
- Version 1.0.2
- Declares android.permission.NEARBY_WIFI_DEVICES
- Requests Nearby devices permission at runtime on Android 13+
- Keeps INTERNET, ACCESS_NETWORK_STATE, ACCESS_WIFI_STATE
- GitHub build verifies final APK contains INTERNET + NETWORK_STATE + NEARBY_WIFI_DEVICES

After install: allow Nearby devices if Android asks, then test REGISTER.
