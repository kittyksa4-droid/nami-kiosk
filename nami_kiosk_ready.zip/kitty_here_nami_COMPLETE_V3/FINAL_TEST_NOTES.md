# Final test profile V3

This build is configured for the CURRENT P1000 shown on 21/08/2026:

- Local terminal IP: `172.20.10.2`
- ECR port profile: `8888`
- Terminal ID: `11232541`
- CRN: `73154355`
- Demo payment: OFF

The receipt values `10.123.90.3` and `0100` are the terminal's upstream payment-host communication values. They are not used as the kiosk's local ECR socket destination.

Payment flow in the built-in TCP fallback now uses:
- REGISTER 17
- SESSION 18
- end-to-end PAYMENT transaction type 6
- Flutter-style purchase body
- SHA-256 signature based on six-digit unique ref + Terminal ID
- CRN + six-digit ECR reference
- 12-digit minor-unit amount

Test only with SAR 1.00 first.
