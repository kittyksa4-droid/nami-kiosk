# Kitty Here + Nami P1000 — Complete V3

Current device profile is embedded:
- IP `172.20.10.2`
- Port `8888`
- Terminal ID `11232541`
- CRN `73154355`

The GitHub workflow recreates the Android shell safely, restores the real Kitty Here source, verifies that the Flutter demo template is NOT present, then builds the release APK.

Important: `10.123.90.3 : 0100` shown on the terminal Communication Data receipt is the terminal's upstream payment-host configuration, not the kiosk-to-terminal LAN ECR address.

The bundled TCP fallback follows Nami's documented transaction ordering and updated Flutter transaction type/body. For production-grade payment transport, Nami's official `ecrlib` wrapper remains the authoritative implementation of the private transport framing.
