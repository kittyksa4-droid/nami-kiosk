KITTY HERE POS — full kiosk/admin foundation

Included:
- Welcome screen matching Kitty Here pink identity and mascot
- Customer menu, cart, checkout and success flow
- All supplied products/prices preloaded
- Product add/edit/delete, custom image picker, stock management
- Sales dashboard, sales history, manual invoice creation
- Nami IP + ECR port settings, auto-discovery and connection test
- Default Nami: 172.20.10.3:8888, Terminal ID 11232540
- USB ESC/POS printer bridge for CITyPOS CP-P850N style printers, 80mm
- Remote backend URL/token fields and health check wiring

Important:
- Payment UI is fully wired, but REAL Nami transaction execution is intentionally disabled unless the official Nami ecrlib SDK is added. Demo mode can test the complete order/receipt flow safely.
- Admin PIN default: 2468
- Remote management from outside the store needs a secure backend; the app has the client-side configuration hooks ready for it.

- Kiosk/self-service mode: immersive sticky UI, portrait lock, app hidden from Recents.
- Admin exit remains protected by configurable PIN (default 2468).
- Note: true Android Lock Task / device-owner mode requires provisioning the tablet as a managed/dedicated device; the app foundation is prepared for kiosk use without that provisioning.

- Experimental raw ECR probe added under Settings.
  - Step 1 is a non-financial Register probe.
  - Step 2 is an explicitly-confirmed 1 SAR purchase test.
  - It combines Nami's documented payloads/transaction codes with the publicly documented Pine Labs socket envelope.
  - This is a compatibility experiment, not a replacement for the official Nami SDK unless the terminal responds correctly and results are verified.

- Experimental ECR test updated to mirror Nami Flutter documentation:
  - txnType 6
  - request: DDMMYYHHMMSS;amount;print!;CRN+6digits!;
  - request converted to HEX
  - signature SHA-256(6-digit unique number + Terminal ID)
  - requires 8-digit CRN in Settings
  - socket framing is still experimental because Nami's Flutter SDK transport envelope is not publicly documented.
