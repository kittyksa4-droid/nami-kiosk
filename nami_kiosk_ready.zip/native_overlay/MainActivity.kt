package com.example.kitty_here_pos

import android.app.PendingIntent
import android.content.Context
import android.graphics.*
import android.hardware.usb.*
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random
import com.skyband.ecr.sdk.api.ECRImpl

class MainActivity: FlutterActivity() {
    private val PRINTER_CHANNEL = "kittyhere/printer"
    private val NAMI_CHANNEL = "kittyhere/nami"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, NAMI_CHANNEL).setMethodCallHandler { call, result ->
            if (call.method != "purchase") { result.notImplemented(); return@setMethodCallHandler }
            val ip = call.argument<String>("ip") ?: "172.20.10.4"
            val port = call.argument<Int>("port") ?: 1024
            val tid = call.argument<String>("terminalId") ?: "11232541"
            val crn = call.argument<String>("crn") ?: "73154354"
            val amount = call.argument<Int>("amountMinor") ?: 100
            if (tid.length != 8 || crn.length != 8 || amount <= 0) {
                result.success(mapOf("ok" to false, "stage" to "VALIDATION", "message" to "TID/CRN must be 8 digits and amount > 0")); return@setMethodCallHandler
            }
            Thread {
                try {
                    val ecr = ECRImpl.getConnectInstance()
                    val stamp = SimpleDateFormat("ddMMyyhhmmss", Locale.US).format(Date())
                    val zeros = "0".repeat(64)
                    // Official SDK transaction types: REGISTER=17, START_SESSION=18, PURCHASE=0.
                    val register = ecr.doTCPIPTransaction(ip, port, "$stamp;$crn!", 17, zeros)
                    // Nami Android sample stores REGISTER response field #3 as TerminalID.
                    // On this terminal that field is the full 16-digit value (TID + CRN),
                    // and the sample hashes the last 6 ECR-ref digits + that exact returned field.
                    val registerFields = register.split(';')
                    val registeredTerminalId = registerFields.getOrNull(3)?.trim().orEmpty()
                    if (registeredTerminalId.isEmpty()) {
                        runOnUiThread { result.success(mapOf(
                            "ok" to false, "stage" to "REGISTER",
                            "message" to "REGISTER response did not contain TerminalID field #3",
                            "registerResponse" to register
                        )) }
                        return@Thread
                    }
                    val session = ecr.doTCPIPTransaction(ip, port, "$stamp;$crn!", 18, zeros)
                    val ref6 = String.format(Locale.US, "%06d", Random.nextInt(0, 1_000_000))
                    val ecrRef = crn + ref6
                    val signatureInput = ref6 + registeredTerminalId
                    val signature = ecr.computeSha256Hash(signatureInput)
                    val req = "$stamp;$amount;0;$ecrRef!"
                    val purchase = ecr.doTCPIPTransaction(ip, port, req, 0, signature)
                    val fields = purchase.split(';')
                    // Nami official sample treats field #3 as the transaction result text.
                    // IMPORTANT: field #1 is the transaction type (PURCHASE = 0), NOT an approval code.
                    // The previous implementation accepted field #1 == 0, which falsely approved timeouts/declines.
                    val responseCode = fields.getOrNull(2)?.trim().orEmpty()
                    val responseMessage = fields.getOrNull(3)?.trim().orEmpty()
                    val approved = responseMessage.equals("APPROVED", ignoreCase = true) &&
                        responseCode in listOf("000", "00", "0")
                    runOnUiThread { result.success(mapOf(
                        "ok" to approved, "stage" to "PURCHASE", "message" to if (approved) "APPROVED" else (if (responseMessage.isNotEmpty()) responseMessage else purchase),
                        "ecrRef" to ecrRef, "registerResponse" to register, "sessionResponse" to session,
                        "purchaseResponse" to purchase, "requestData" to req,
                        "registeredTerminalId" to registeredTerminalId, "signatureInput" to signatureInput
                    )) }
                } catch (e: Exception) {
                    runOnUiThread { result.success(mapOf("ok" to false, "stage" to "NAMI_SDK", "message" to (e.message ?: e.javaClass.simpleName))) }
                }
            }.start()
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, PRINTER_CHANNEL).setMethodCallHandler { call, result ->
            val manager = getSystemService(Context.USB_SERVICE) as UsbManager
            when (call.method) {
                "listUsbDevices" -> result.success(manager.deviceList.values.map { d -> mapOf("name" to (d.productName ?: d.deviceName), "vendorId" to d.vendorId, "productId" to d.productId) })
                "printReceipt" -> {
                    val text = call.argument<String>("text") ?: ""; val logoPath = call.argument<String>("logoPath") ?: ""; val device = findPrinter(manager)
                    if (device == null) { result.success("no_printer"); return@setMethodCallHandler }
                    if (!manager.hasPermission(device)) {
                        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
                        manager.requestPermission(device, PendingIntent.getBroadcast(this, 0, android.content.Intent("KITTY_USB_PERMISSION"), flags)); result.success("permission_requested"); return@setMethodCallHandler
                    }
                    try { result.success(if (printBitmap(manager, device, renderReceipt(text, logoPath))) "printed" else "failed") } catch (e: Exception) { result.error("PRINT", e.message, null) }
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun findPrinter(manager: UsbManager): UsbDevice? { for (d in manager.deviceList.values) for (i in 0 until d.interfaceCount) { val intf=d.getInterface(i); if(intf.interfaceClass==UsbConstants.USB_CLASS_PRINTER)return d; for(j in 0 until intf.endpointCount){val ep=intf.getEndpoint(j);if(ep.type==UsbConstants.USB_ENDPOINT_XFER_BULK&&ep.direction==UsbConstants.USB_DIR_OUT)return d}}; return null }
    private fun renderReceipt(text:String, logoPath:String):Bitmap {
        if (!text.startsWith("KH_RECEIPT_V2")) {
            val w=576; val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;textSize=26f;typeface=Typeface.create(Typeface.DEFAULT,Typeface.NORMAL)}
            val lines=text.split("\n"); val logo=if(logoPath.isNotBlank()) BitmapFactory.decodeFile(logoPath) else null
            val logoH=if(logo!=null) 170 else 0; val h=(lines.size*42+80+logoH).coerceAtLeast(300)
            val b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); val c=Canvas(b);c.drawColor(Color.WHITE); var y=42f
            if(logo!=null){ val scale=minOf(500f/logo.width,150f/logo.height); val dw=(logo.width*scale).toInt(); val dh=(logo.height*scale).toInt(); val dst=Rect((w-dw)/2,15,(w+dw)/2,15+dh); c.drawBitmap(logo,null,dst,paint); y=(30+dh).toFloat() }
            for(line in lines){val rtl=line.any{it.code in 0x0600..0x06FF};paint.textAlign=if(rtl)Paint.Align.RIGHT else Paint.Align.LEFT;c.drawText(line,if(rtl)w-24f else 24f,y,paint);y+=42};return b
        }
        val rows=text.lines().drop(1).filter{it.isNotBlank()}.map{it.split('|')}
        fun one(k:String)=rows.firstOrNull{it.firstOrNull()==k}?.drop(1)?.joinToString("|") ?: ""
        val items=rows.filter{it.firstOrNull()=="ITEM"}
        val footer=one("FOOTER").split('|').filter{it.isNotBlank()}
        val w=576; val h=760 + items.size*64 + footer.size*34
        val bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); val c=Canvas(bmp); c.drawColor(Color.WHITE)
        val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;typeface=Typeface.create(Typeface.DEFAULT,Typeface.NORMAL)}
        fun center(t:String,y:Float,size:Float,bold:Boolean=false){p.textSize=size;p.typeface=Typeface.create(Typeface.DEFAULT,if(bold)Typeface.BOLD else Typeface.NORMAL);p.textAlign=Paint.Align.CENTER;c.drawText(t,w/2f,y,p)}
        fun right(t:String,y:Float,size:Float=23f,bold:Boolean=false){p.textSize=size;p.typeface=Typeface.create(Typeface.DEFAULT,if(bold)Typeface.BOLD else Typeface.NORMAL);p.textAlign=Paint.Align.RIGHT;c.drawText(t,w-30f,y,p)}
        fun left(t:String,y:Float,size:Float=23f,bold:Boolean=false){p.textSize=size;p.typeface=Typeface.create(Typeface.DEFAULT,if(bold)Typeface.BOLD else Typeface.NORMAL);p.textAlign=Paint.Align.LEFT;c.drawText(t,30f,y,p)}
        fun line(y:Float){p.strokeWidth=2f;c.drawLine(28f,y,w-28f,y,p)}
        var y=32f
        val logo=if(logoPath.isNotBlank()) BitmapFactory.decodeFile(logoPath) else null
        if(logo!=null){val scale=minOf(350f/logo.width,120f/logo.height);val dw=(logo.width*scale).toInt();val dh=(logo.height*scale).toInt();c.drawBitmap(logo,null,Rect((w-dw)/2,y.toInt(),(w+dw)/2,y.toInt()+dh),p);y+=dh+18}
        else { center("kitty",y+58,58f,true); center("HERE",y+92,31f,true); y+=118 }
        line(y); y+=34
        right("رقم الفاتورة: ${one("INVOICE")}",y,22f,true); y+=34
        right("التاريخ: ${one("DATE").take(19)}",y,21f); y+=34
        if(one("PHONE").isNotBlank()){right("رقم الجوال: ${one("PHONE")}",y,21f);y+=34}
        line(y); y+=38
        right("المنتج / الخدمة",y,23f,true); left("الإجمالي",y,23f,true); y+=20; line(y); y+=34
        for(r in items){val name=r.getOrNull(1)?:"";val qty=r.getOrNull(2)?:"1";val unit=r.getOrNull(3)?:"0";val total=r.getOrNull(4)?:"0";right(name,y,21f,true);left("$total ر.س",y,21f,true);y+=29;right("الكمية $qty × $unit ر.س",y,18f);y+=34;line(y);y+=25}
        val total=one("TOTAL"); right("الإجمالي",y,25f,true); left("$total ر.س",y,27f,true); y+=42
        line(y); y+=38
        center("✓ تمت العملية بنجاح - مدى",y,23f,true); y+=34
        if(one("REF").isNotBlank()){center("مرجع العملية: ${one("REF")}",y,17f);y+=30}
        line(y); y+=42
        center("شكراً لزيارتكم ♥",y,30f,true); y+=36
        for(f in footer){center(f,y,20f);y+=30}
        center("@kitty_ksa1",y+8,22f,true); y+=44
        center("KITTY HERE",y,25f,true); y+=28
        center("♥  🐾  ♥",y,20f)
        return Bitmap.createBitmap(bmp,0,0,w,(y+32).toInt().coerceAtMost(h))
    }
    private fun printBitmap(manager:UsbManager,device:UsbDevice,bmp:Bitmap):Boolean { var target:UsbInterface?=null;var out:UsbEndpoint?=null;for(i in 0 until device.interfaceCount){val intf=device.getInterface(i);for(j in 0 until intf.endpointCount){val ep=intf.getEndpoint(j);if(ep.type==UsbConstants.USB_ENDPOINT_XFER_BULK&&ep.direction==UsbConstants.USB_DIR_OUT){target=intf;out=ep;break}};if(out!=null)break};if(target==null||out==null)return false;val conn=manager.openDevice(device)?:return false;if(!conn.claimInterface(target,true)){conn.close();return false};val bytes=escPosRaster(bmp);conn.bulkTransfer(out,byteArrayOf(0x1B,0x40),2,2000);var off=0;while(off<bytes.size){val n=minOf(4096,bytes.size-off);val chunk=bytes.copyOfRange(off,off+n);val sent=conn.bulkTransfer(out,chunk,chunk.size,4000);if(sent<=0)break;off+=sent};val cut=byteArrayOf(0x1D,0x56,0x41,0x10);conn.bulkTransfer(out,cut,cut.size,2000);conn.releaseInterface(target);conn.close();return off>=bytes.size }
    private fun escPosRaster(bitmap:Bitmap):ByteArray { val w=bitmap.width;val h=bitmap.height;val wb=(w+7)/8;val out=ByteArrayOutputStream();out.write(byteArrayOf(0x1D,0x76,0x30,0x00,(wb and 0xFF).toByte(),((wb shr 8) and 0xFF).toByte(),(h and 0xFF).toByte(),((h shr 8) and 0xFF).toByte()));for(y in 0 until h)for(xb in 0 until wb){var b=0;for(bit in 0..7){val x=xb*8+bit;if(x<w){val p=bitmap.getPixel(x,y);val gray=(Color.red(p)*30+Color.green(p)*59+Color.blue(p)*11)/100;if(gray<160)b=b or(1 shl(7-bit))}};out.write(b)};return out.toByteArray() }
}
