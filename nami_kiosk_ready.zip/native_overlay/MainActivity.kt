package com.example.kitty_here_pos

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.graphics.*
import android.hardware.usb.*
import android.os.Build
import android.os.Bundle
import android.content.pm.PackageManager
import android.text.*
import android.text.style.AlignmentSpan
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream

class MainActivity: FlutterActivity() {
    private val CHANNEL = "kittyhere/printer"
    private val NETWORK_CHANNEL = "kittyhere/network"
    private val LAN_PERMISSION_REQUEST = 4201
    private var pendingLanResult: MethodChannel.Result? = null
    // Direct LAN TCP uses the normal INTERNET permission.
    // This build targets SDK 35 so Android 16 local-network opt-in restrictions do not apply.

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, NETWORK_CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "ensureLanPermission" -> ensureLanPermission(result)
                else -> result.notImplemented()
            }
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            val manager = getSystemService(Context.USB_SERVICE) as UsbManager
            when (call.method) {
                "listUsbDevices" -> {
                    val list = manager.deviceList.values.map { d ->
                        mapOf("name" to (d.productName ?: d.deviceName), "vendorId" to d.vendorId, "productId" to d.productId)
                    }
                    result.success(list)
                }
                "printReceipt" -> {
                    val text = call.argument<String>("text") ?: ""
                    val device = findPrinter(manager)
                    if (device == null) {
                        result.success("no_printer")
                        return@setMethodCallHandler
                    }
                    if (!manager.hasPermission(device)) {
                        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
                        val intent = PendingIntent.getBroadcast(this, 0, android.content.Intent("KITTY_USB_PERMISSION"), flags)
                        manager.requestPermission(device, intent)
                        result.success("permission_requested")
                        return@setMethodCallHandler
                    }
                    try {
                        val ok = printBitmap(manager, device, renderReceipt(text))
                        result.success(if (ok) "printed" else "failed")
                    } catch (e: Exception) {
                        result.error("PRINT", e.message, null)
                    }
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun ensureLanPermission(result: MethodChannel.Result) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            result.success(true)
            return
        }
        if (checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED) {
            result.success(true)
            return
        }
        pendingLanResult = result
        requestPermissions(arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES), LAN_PERMISSION_REQUEST)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LAN_PERMISSION_REQUEST) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            pendingLanResult?.success(granted)
            pendingLanResult = null
        }
    }

    private fun findPrinter(manager: UsbManager): UsbDevice? {
        for (d in manager.deviceList.values) {
            for (i in 0 until d.interfaceCount) {
                val intf = d.getInterface(i)
                if (intf.interfaceClass == UsbConstants.USB_CLASS_PRINTER) return d
                for (j in 0 until intf.endpointCount) {
                    val ep = intf.getEndpoint(j)
                    if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK && ep.direction == UsbConstants.USB_DIR_OUT) return d
                }
            }
        }
        return null
    }

    private fun renderReceipt(text: String): Bitmap {
        val width = 576
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 26f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        val lines = text.split("\n")
        val lineH = 42
        val height = (lines.size * lineH + 80).coerceAtLeast(300)
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        var y = 42f
        for (line in lines) {
            val rtl = line.any { it.code in 0x0600..0x06FF }
            paint.textAlign = if (rtl) Paint.Align.RIGHT else Paint.Align.LEFT
            c.drawText(line, if (rtl) width - 24f else 24f, y, paint)
            y += lineH
        }
        return bmp
    }

    private fun printBitmap(manager: UsbManager, device: UsbDevice, bmp: Bitmap): Boolean {
        var target: UsbInterface? = null
        var out: UsbEndpoint? = null
        for (i in 0 until device.interfaceCount) {
            val intf = device.getInterface(i)
            for (j in 0 until intf.endpointCount) {
                val ep = intf.getEndpoint(j)
                if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK && ep.direction == UsbConstants.USB_DIR_OUT) {
                    target = intf
                    out = ep
                    break
                }
            }
            if (out != null) break
        }
        if (target == null || out == null) return false
        val conn = manager.openDevice(device) ?: return false
        if (!conn.claimInterface(target, true)) {
            conn.close()
            return false
        }

        val bytes = escPosRaster(bmp)
        conn.bulkTransfer(out, byteArrayOf(0x1B, 0x40), 2, 2000)
        var offset = 0
        while (offset < bytes.size) {
            val n = minOf(4096, bytes.size - offset)
            val chunk = bytes.copyOfRange(offset, offset + n)
            val sent = conn.bulkTransfer(out, chunk, chunk.size, 4000)
            if (sent <= 0) break
            offset += sent
        }
        val cut = byteArrayOf(0x1D, 0x56, 0x41, 0x10)
        conn.bulkTransfer(out, cut, cut.size, 2000)
        conn.releaseInterface(target)
        conn.close()
        return offset >= bytes.size
    }

    private fun escPosRaster(bitmap: Bitmap): ByteArray {
        val w = bitmap.width
        val h = bitmap.height
        val widthBytes = (w + 7) / 8
        val out = ByteArrayOutputStream()
        out.write(byteArrayOf(
            0x1D, 0x76, 0x30, 0x00,
            (widthBytes and 0xFF).toByte(),
            ((widthBytes shr 8) and 0xFF).toByte(),
            (h and 0xFF).toByte(),
            ((h shr 8) and 0xFF).toByte()
        ))
        for (y in 0 until h) {
            for (xb in 0 until widthBytes) {
                var b = 0
                for (bit in 0..7) {
                    val x = xb * 8 + bit
                    if (x < w) {
                        val p = bitmap.getPixel(x, y)
                        val gray = (Color.red(p) * 30 + Color.green(p) * 59 + Color.blue(p) * 11) / 100
                        if (gray < 160) b = b or (1 shl (7 - bit))
                    }
                }
                out.write(b)
            }
        }
        return out.toByteArray()
    }
}
