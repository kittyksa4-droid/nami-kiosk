Direct Android-tablet TCP compatibility test.
Uses official Nami sequence Register 17 -> Session 18 -> Purchase 0,
minor units, SHA-256(EcrRef6 + TerminalID), and the same low-level envelope
that previously made this terminal respond 'Terminal Is Busy, Try Later'.
First test REGISTER only. Then explicitly test 1 SAR.
