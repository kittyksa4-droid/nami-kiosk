V4: version 1.0.1+11. GitHub Actions verifies INTERNET and ACCESS_NETWORK_STATE are present inside the final APK before upload.
