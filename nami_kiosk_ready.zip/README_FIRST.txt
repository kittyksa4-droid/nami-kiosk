KITTY HERE NAMI FINAL V6 FIXED

Confirmed device settings:
IP 172.20.10.2
Port 8888
Terminal ID 11232541
CRN 73154355

Main fix for the exact error shown on 21/08/2026:
SocketException: Operation not permitted (errno=1)
This is Android local-network permission blocking LAN TCP.
V6 declares and requests Nearby devices permission and pins targetSdk 35.
The build workflow verifies the permissions exist inside the final APK.

When installed, if Android asks for Nearby devices, choose ALLOW.
Then use REGISTER test before the 1 SAR real-payment test.
