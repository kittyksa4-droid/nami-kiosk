KITTY HERE NAMI PROBE V9

IP: 172.20.10.2
ECR Port: 16535
Terminal ID: 11232541
CRN candidate: 73154355

ابدأ من الإعدادات > اختبار بروتوكول ECR التجريبي > زر 0 اكتشاف framing تلقائياً.
هذا الزر يرسل REGISTER فقط بدون مبلغ.
إذا ظهر تم اكتشاف framing، بعدها جرّب REGISTER فقط. لا ترسل 1 ريال إلا بعد نجاح الاثنين.

الملف جاهز للرفع لنفس GitHub/Flutter builder المستخدم سابقاً.
