# V20 test

Use: `V20) 1 ريال — Type 6 مباشر بدون Register`

One request per press. No txnType 17/18. Saved IP/port, Terminal ID, and CRN are left unchanged.
