Nami ECR network diagnostic build.
Default target: 172.20.10.3:8888
Android INTERNET and ACCESS_NETWORK_STATE permissions are included in the project manifest.
