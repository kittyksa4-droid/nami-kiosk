# Nami Kiosk
Terminal: 172.20.10.3:16535

This build tests TCP connectivity to the Nami terminal. Nami's official ECR SDK is required before enabling live purchase transactions, registration/session/signature handling.
