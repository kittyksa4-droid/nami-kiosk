Nami Bluetooth Classic diagnostic build.
This app only lists paired Bluetooth Classic devices, attempts RFCOMM SPP connection,
sends a harmless 'ping' test message, and displays any received bytes.
It does not perform payment transactions.
