KITTY HERE POS — full kiosk/admin foundation

Included:
- Welcome screen matching Kitty Here pink identity and mascot
- Customer menu, cart, checkout and success flow
- All supplied products/prices preloaded
- Product add/edit/delete, custom image picker, stock management
- Sales dashboard, sales history, manual invoice creation
- Nami IP + ECR port settings, auto-discovery and connection test
- Default Nami: 172.20.10.3:8888, Terminal ID 11232541
- USB ESC/POS printer bridge for CITyPOS CP-P850N style printers, 80mm
- Remote backend URL/token fields and health check wiring

Important:
- Payment UI is fully wired, but REAL Nami transaction execution is intentionally disabled unless the official Nami ecrlib SDK is added. Demo mode can test the complete order/receipt flow safely.
- Admin PIN default: 2468
- Remote management from outside the store needs a secure backend; the app has the client-side configuration hooks ready for it.

- Kiosk/self-service mode: immersive sticky UI, portrait lock, app hidden from Recents.
- Admin exit remains protected by configurable PIN (default 2468).
- Note: true Android Lock Task / device-owner mode requires provisioning the tablet as a managed/dedicated device; the app foundation is prepared for kiosk use without that provisioning.
