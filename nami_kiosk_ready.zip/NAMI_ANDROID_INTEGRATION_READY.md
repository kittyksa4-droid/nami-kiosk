# Nami Android integration

This project is now wired for the official Nami Android SDK flow.

Implemented:
- Runtime IP/port from app settings
- CRN validation (8 numeric digits)
- Terminal ID setting
- Amount conversion: SAR -> halalas -> 12 digit amount string
- Purchase request: ddMMyyHHmmss;amount12;printFlag;ecrRef!
- Native Android MethodChannel bridge
- Runtime detection of SkyBandSDK-release.aar
- getPackData() / getParseData() through reflection
- TCP send/receive and response-code parsing
- Checkout completes only when Nami response code is 00
- Existing USB receipt printing remains after approval

Required proprietary file:
android/app/libs/SkyBandSDK-release.aar

The file is not bundled because it is supplied by Nami and is not part of the public documentation.
