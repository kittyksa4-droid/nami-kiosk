V21 - Nami official Android ECR SDK

This replaces checkout payment execution with SkyBandSDK-release.aar supplied by Nami.
No guessed raw TCP framing is used for checkout.

Official SDK calls used:
- REGISTER transaction type 17
- START_SESSION transaction type 18
- PURCHASE transaction type 0
- ECRImpl.doTCPIPTransaction(...)
- ECRImpl.computeSha256Hash(ref6 + TerminalID)

Defaults retained:
- Terminal ID: 11232541
- CRN: 73154354
- ECR port: 1024
- Test amount: 1.00 SAR => 100 minor units
- IP remains editable in app settings.

Build overlay:
1. Copy native_overlay/MainActivity.kt to android/app/src/main/kotlin/com/example/kitty_here_pos/MainActivity.kt
2. Copy native_overlay/libs/SkyBandSDK-release.aar to android/app/libs/
3. Add implementation(files("libs/SkyBandSDK-release.aar")) to android/app/build.gradle.kts dependencies.
4. Use native_overlay/AndroidManifest.xml as app manifest if your build workflow creates a fresh Flutter project.
