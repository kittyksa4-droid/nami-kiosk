# V19 findings

1. `terminal*.dat` is identical across all uploaded copies and decodes as TLV.
   Tag 9F01 has length 8 and value `73154354`, confirming the CRN.
2. The Skyband logs show successful Purchase transactions and that amounts are
   converted to minor units (for example 19.00 -> 1900 and 13.00 -> 1300).
3. The logs repeatedly show `Main App to App ECR >> null`; these successful
   card transactions are normal terminal transactions, not evidence of an
   App-to-App ECR request.
4. The public Nami .NET TCP documentation uses:
   REGISTER: DDMMYYHHMMSS;TerminalID!
   SESSION:  DDMMYYHHMMSS;TerminalID!
   PURCHASE: DDMMYYHHMMSS;AmountMinor;0;TerminalID+Ref6!
   Signature: SHA256(Ref6 + TerminalID)
5. Earlier probes incorrectly used CRN+Ref6 in the .NET-style raw TCP purchase
   body. V19 corrects that while keeping the user's Terminal ID unchanged.
6. The exact native SDK's outer binary transport envelope is not published.
   V19 keeps the only envelope already demonstrated to reach the terminal and
   receive terminal responses.
