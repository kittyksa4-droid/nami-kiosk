# Kitty HERE POS – Nami final test build

Defaults preloaded for the current terminal:
- IP: `172.20.10.2`
- Port: `8888`
- Terminal ID: `11232541`
- CRN: `73154354` (inferred from terminal.dat tag 9F01; verify with Nami if needed)
- Real-payment mode enabled by default.

Important protocol correction in this build:
- Purchase ECR reference now uses `CRN + 6-digit unique number`.
- Purchase payload now follows Nami documentation: `DDMMYYHHMMSS;amount;0!;ECRREF!;`
- Signature is SHA-256 of `6-digit unique number + Terminal ID`.
- Purchase is never automatically retried after send to avoid duplicate charges.

Test with 1 SAR first. If the terminal returns an error, capture the exact response shown by the app before trying again.
